package com.example

import com.example.data.Mr7Role
import com.example.data.SuperAdminConfig
import com.example.data.local.*
import org.junit.Assert.*
import org.junit.Test

class Mr7PureUnitTest {

    @Test
    fun testAdminIdAndPrimaryEmail() {
        assertEquals("ADMIN-MR7-777-SUPER", SuperAdminConfig.ADMIN_ID)
        assertEquals("mr7.mr.mor3eb@gmail.com", SuperAdminConfig.ADMIN_EMAIL_PRIMARY)
        assertEquals("mr7.mr.mor3eb@gmail.com", SuperAdminConfig.ADMIN_EMAIL_OWNER)
    }

    @Test
    fun testSaltedPasswordHashingAndVerification() {
        // Correct admin passwords
        assertTrue(SuperAdminConfig.verifyAdminLoginPassword("MR7 ON TOP 111"))
        assertTrue(SuperAdminConfig.verifyDashboardPassword("MR7 ADMIN 2013"))

        // Incorrect passwords must fail
        assertFalse(SuperAdminConfig.verifyAdminLoginPassword("wrong_pass"))
        assertFalse(SuperAdminConfig.verifyDashboardPassword("wrong_pin"))
        assertFalse(SuperAdminConfig.verifyAdminLoginPassword(""))
        assertFalse(SuperAdminConfig.verifyDashboardPassword(""))
    }

    @Test
    fun testAdminEmailRecognition() {
        assertTrue(SuperAdminConfig.isAdminEmail("admin@mr7nursing.com"))
        assertTrue(SuperAdminConfig.isAdminEmail("ADMIN@MR7NURSING.COM"))
        assertTrue(SuperAdminConfig.isAdminEmail("jffhyfvg@gmail.com"))
        assertTrue(SuperAdminConfig.isAdminEmail("mr7.mr.mor3eb@gmail.com"))

        assertFalse(SuperAdminConfig.isAdminEmail("random_user@gmail.com"))
        assertFalse(SuperAdminConfig.isAdminEmail("hacker@malicious.com"))
    }

    @Test
    fun testSuperAdminUserRecognition() {
        assertTrue(SuperAdminConfig.isSuperAdminUser("admin@mr7nursing.com", SuperAdminConfig.ADMIN_ID))
        assertTrue(SuperAdminConfig.isSuperAdminUser("jffhyfvg@gmail.com", "usr_12345"))
        assertTrue(SuperAdminConfig.isSuperAdminUser("unknown@mail.com", SuperAdminConfig.ADMIN_ID))

        // Normal user must not be super admin
        assertFalse(SuperAdminConfig.isSuperAdminUser("user@example.com", "usr_99999"))
        assertFalse(SuperAdminConfig.isSuperAdminUser("", ""))
    }

    @Test
    fun testRoleHierarchyAndSeparation() {
        assertEquals(Mr7Role.SUPER_ADMIN, Mr7Role.fromKey("SUPER_ADMIN"))
        assertEquals(Mr7Role.ADMIN, Mr7Role.fromKey("ADMIN"))
        assertEquals(Mr7Role.SUPPORT, Mr7Role.fromKey("SUPPORT"))
        assertEquals(Mr7Role.ANALYST, Mr7Role.fromKey("ANALYST"))
        assertEquals(Mr7Role.USER, Mr7Role.fromKey("USER"))
        assertEquals(Mr7Role.USER, Mr7Role.fromKey("UNKNOWN_ROLE"))
    }

    @Test
    fun testUserDataModelScoping() {
        val userAId = "usr_A_111"
        val userBId = "usr_B_222"

        val medA = MedicationEntity(
            userId = userAId,
            officialName = "Panadol",
            userNickname = "بنادول الصداع",
            concentration = "500mg",
            form = "حبة",
            instructions = "بعد الطعام",
            timesOfDay = "08:00 ص",
            stockCount = 20
        )

        val medB = MedicationEntity(
            userId = userBId,
            officialName = "Concor",
            userNickname = "كونكور الضغط",
            concentration = "5mg",
            form = "حبة",
            instructions = "قبل الإفطار",
            timesOfDay = "09:00 ص",
            stockCount = 30
        )

        assertNotEquals(medA.userId, medB.userId)
        assertEquals(userAId, medA.userId)
        assertEquals(userBId, medB.userId)
    }

    @Test
    fun testDoctorAndAppointmentScoping() {
        val userAId = "usr_A_111"
        val appointmentA = AppointmentEntity(
            userId = userAId,
            doctorName = "د. أحمد كمال",
            specialty = "أمراض باطنة",
            appointmentTimeMillis = 1750000000000L,
            dateDisplay = "اليوم",
            timeDisplay = "06:00 م"
        )

        assertEquals(userAId, appointmentA.userId)
        assertFalse(appointmentA.isCompleted)
    }

    @Test
    fun testDoseLogAndAllergyScoping() {
        val userAId = "usr_A_111"
        val doseLogA = DoseLogEntity(
            userId = userAId,
            medicationId = 1L,
            medicationName = "بنادول الصداع",
            scheduledTime = "08:00 ص",
            scheduledDate = "2026-11-02",
            timestampMillis = System.currentTimeMillis(),
            status = "PENDING"
        )
        val allergyA = AllergyEntity(
            userId = userAId,
            allergyName = "بنسلين",
            severity = "شديدة",
            notes = "حساسية مفرطة"
        )
        assertEquals(userAId, doseLogA.userId)
        assertEquals(userAId, allergyA.userId)
        assertEquals("PENDING", doseLogA.status)
    }

    @Test
    fun testFamilyMemberScopingAndPermissions() {
        val userAId = "usr_A_111"
        val familyMember = FamilyMemberEntity(
            userId = userAId,
            name = "الوالدة",
            relation = "أم",
            pairCode = "MR7-4321",
            status = "REGULAR",
            lastActive = "منذ 10 دقائق",
            allowMeds = true,
            allowAppointments = true,
            allowHistory = true,
            allowAllergies = false
        )
        assertEquals(userAId, familyMember.userId)
        assertTrue(familyMember.allowMeds)
        assertTrue(familyMember.allowAppointments)
        assertFalse(familyMember.allowAllergies)
    }
}
