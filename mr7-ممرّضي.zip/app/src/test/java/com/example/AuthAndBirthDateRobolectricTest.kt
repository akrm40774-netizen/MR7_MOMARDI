package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.UserPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class AuthAndBirthDateRobolectricTest {

    @Test
    fun testSignUpLogoutLoginRestoresProfileAndBirthDate() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = UserPreferences(context)

        // 1. Sign up new user
        val userId = "usr_test_101"
        prefs.loginSession(userId, "أحمد محمد", "ahmed@example.com", "EMAIL")
        assertTrue(prefs.isLoggedIn)
        assertFalse(prefs.isProfileSetupCompleted)

        // 2. Complete profile setup with 3-field birth date
        prefs.completeProfileSetup(
            name = "أحمد محمد",
            birthDate = "15 مارس 2012",
            hasMeds = true,
            hasAppointments = false
        )
        assertTrue(prefs.isProfileSetupCompleted)
        assertEquals("15 مارس 2012", prefs.userBirthDate)

        // 3. Logout
        prefs.logoutSession()
        assertFalse(prefs.isLoggedIn)

        // 4. Login again with same userId -> profile & birthDate must be restored automatically
        prefs.loginSession(userId, "أحمد محمد", "ahmed@example.com", "EMAIL")
        assertTrue(prefs.isLoggedIn)
        assertTrue(prefs.isProfileSetupCompleted)
        assertEquals("أحمد محمد", prefs.userName)
        assertEquals("15 مارس 2012", prefs.userBirthDate)

        // 5. Simulate app restart (new UserPreferences instance)
        val reopenedPrefs = UserPreferences(context)
        assertTrue(reopenedPrefs.isLoggedIn)
        assertTrue(reopenedPrefs.isProfileSetupCompleted)
        assertEquals("أحمد محمد", reopenedPrefs.userName)
        assertEquals("15 مارس 2012", reopenedPrefs.userBirthDate)
    }
}
