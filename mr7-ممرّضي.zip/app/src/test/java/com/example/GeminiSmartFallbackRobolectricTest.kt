package com.example

import com.example.ai.GeminiErrorType
import com.example.ai.GeminiSmartFallback
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class GeminiSmartFallbackRobolectricTest {

    @Test
    fun testSmartFallbackTransitionsAcrossAllFourModels() = runBlocking {
        val mockClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val req = chain.request()
                val url = req.url.toString()
                val (code, body) = when {
                    url.contains("/models?") -> 200 to """{"models":[]}"""
                    url.contains("gemini-3.5-flash-lite") -> 429 to """{"error":{"message":"Quota exceeded"}}"""
                    url.contains("gemini-flash-lite-latest") -> 503 to """{"error":{"message":"Service unavailable"}}"""
                    url.contains("gemini-3.1-flash-lite-preview") -> 200 to """{"candidates":[{"content":{"parts":[{"text":"أهلاً بك، تم الرد بنجاح"}]}}]}"""
                    url.contains("gemini-3.1-flash-lite") -> 404 to """{"error":{"message":"Model not found"}}"""
                    else -> 500 to "{}"
                }
                Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(code)
                    .message("Mock")
                    .body(body.toResponseBody("application/json".toMediaType()))
                    .build()
            }
            .build()

        val fallback = GeminiSmartFallback(client = mockClient)
        val reqJson = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user")))

        val result = fallback.generateWithFallback(
            apiKey = "test-key",
            requestJson = reqJson,
            maxRetriesPerModel = 0,
            initialBackoffMs = 10L
        )

        assertTrue(result.success)
        assertEquals("gemini-3.1-flash-lite-preview", result.usedModel)
        assertEquals("أهلاً بك، تم الرد بنجاح", result.text)
        assertEquals(4, result.transitions.size)
    }

    @Test
    fun testSmartFallbackStopsImmediatelyOnPermanentAuthError() = runBlocking {
        var generateCalls = 0
        val mockClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val req = chain.request()
                val url = req.url.toString()
                if (url.contains("/models?")) {
                    return@addInterceptor Response.Builder()
                        .request(req)
                        .protocol(Protocol.HTTP_1_1)
                        .code(200)
                        .message("OK")
                        .body("""{"models":[]}""".toResponseBody("application/json".toMediaType()))
                        .build()
                }
                generateCalls++
                Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(401)
                    .message("Unauthorized")
                    .body("""{"error":{"message":"Invalid API key"}}""".toResponseBody("application/json".toMediaType()))
                    .build()
            }
            .build()

        val fallback = GeminiSmartFallback(client = mockClient)
        val result = fallback.generateWithFallback(
            apiKey = "invalid-key",
            requestJson = JSONObject(),
            maxRetriesPerModel = 2,
            initialBackoffMs = 10L
        )

        assertFalse(result.success)
        assertEquals(1, generateCalls)
        assertEquals(GeminiErrorType.PERMANENT_AUTH_OR_REQUEST, result.transitions.first().errorType)
    }
}
