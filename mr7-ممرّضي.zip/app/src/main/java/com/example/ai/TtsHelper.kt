package com.example.ai

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.*

enum class RivoVoicePersona(
    val id: String,
    val displayNameAr: String,
    val descriptionAr: String,
    val pitch: Float,
    val rateMultiplier: Float
) {
    WARM_MALE("rivo_warm_male", "ريڤو الدافئ 🎙️", "صوت هادئ وودود ومريح", 0.94f, 1.0f),
    CALM_FEMALE("rivo_calm_female", "ريڤو الهادئة 🌸", "صوت ناعم وواضح", 1.12f, 0.98f),
    ENERGETIC("rivo_energetic", "ريڤو الحيوي ⚡", "صوت نشيط وسريع الاستجابة", 1.02f, 1.08f),
    SENIOR_CLEAR("rivo_senior_clear", "ريڤو الواضح 🩺", "صوت بطيء وواضح لكبار السن", 0.90f, 0.85f);

    companion object {
        fun fromId(id: String): RivoVoicePersona =
            entries.find { it.id == id } ?: WARM_MALE
    }
}

class TtsHelper(context: Context) : TextToSpeech.OnInitListener {

    var isInitialized by mutableStateOf(false)
        private set

    var isSpeaking by mutableStateOf(false)
        private set

    var speechRate by mutableFloatStateOf(0.95f)
    var speechVolume by mutableFloatStateOf(1.0f)
    var activePersona by mutableStateOf(RivoVoicePersona.WARM_MALE)

    private var tts: TextToSpeech? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Throwable) {
            tts = null
            isInitialized = false
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            try {
                setupNaturalAudioAttributes()
                setupNaturalArabicVoice()
                setupUtteranceListener()
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isInitialized = true
                }
            } catch (e: Throwable) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isInitialized = false
                }
            }
        } else {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                isInitialized = false
            }
        }
    }

    private fun setupNaturalAudioAttributes() {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            tts?.setAudioAttributes(audioAttributes)
        } catch (e: Exception) {
            // Fallback audio settings
        }
    }

    private fun setupNaturalArabicVoice() {
        try {
            val arLocale = Locale("ar", "EG")
            val langResult = tts?.setLanguage(arLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("ar"))
            }

            // Search for highest quality natural/neural human voice available in system
            val voices = try { tts?.voices } catch (e: Throwable) { null }
            if (!voices.isNullOrEmpty()) {
                val selectedVoice = voices.filter { voice ->
                    try {
                        val isArabic = voice.locale?.language?.equals("ar", ignoreCase = true) == true
                        val isNotInstalled = voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                        isArabic && !isNotInstalled
                    } catch (e: Throwable) {
                        false
                    }
                }.maxByOrNull { voice ->
                    try {
                        var score = 0
                        if (voice.quality >= Voice.QUALITY_HIGH) score += 50
                        if (voice.quality >= Voice.QUALITY_NORMAL) score += 20
                        val vName = voice.name.lowercase()
                        if (vName.contains("network") || vName.contains("natural") || vName.contains("neural")) score += 40
                        if (vName.contains("google")) score += 20
                        if (voice.locale?.country?.equals("EG", ignoreCase = true) == true) score += 15
                        if (!voice.isNetworkConnectionRequired) score += 10
                        score
                    } catch (e: Throwable) {
                        0
                    }
                }

                if (selectedVoice != null) {
                    try {
                        tts?.voice = selectedVoice
                    } catch (e: Throwable) {
                        // fallback
                    }
                }
            }

            // Warm human pitch & relaxed speech rate
            tts?.setPitch(1.0f)
            tts?.setSpeechRate(speechRate)
        } catch (e: Exception) {
            tts?.setLanguage(Locale("ar"))
        }
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isSpeaking = true
                }
            }

            override fun onDone(utteranceId: String?) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isSpeaking = false
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isSpeaking = false
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    isSpeaking = false
                }
            }
        })
    }

    fun applyRivoConfig(language: String, dialect: String, voiceId: String, rate: Float, volume: Float) {
        activePersona = RivoVoicePersona.fromId(voiceId)
        speechRate = rate
        speechVolume = volume
        if (!isInitialized) return
        try {
            val targetLocale = when {
                language == "en" -> Locale.US
                dialect == "EG" -> Locale("ar", "EG")
                dialect == "SA" -> Locale("ar", "SA")
                dialect == "AE" -> Locale("ar", "AE")
                dialect == "JO" -> Locale("ar", "JO")
                dialect == "MA" -> Locale("ar", "MA")
                else -> Locale("ar")
            }
            val res = tts?.setLanguage(targetLocale)
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("ar"))
            }
        } catch (_: Throwable) {}
    }

    fun previewVoice(persona: RivoVoicePersona, dialect: String, rate: Float) {
        if (!isInitialized) return
        stop()
        val sampleText = when (dialect) {
            "EG" -> "أهلاً بك يا فندم، أنا ريڤو مساعدك الصحي في ممرّضي، تحت أمرك في أي وقت."
            "SA" -> "حياك الله، أنا ريڤو مساعدك الصحي في ممرّضي، أبشر بالخير."
            "AE" -> "مرحباً بك، أنا ريڤو مساعدك الصحي في ممرّضي، كيف أقدر أساعدك اليوم؟"
            "JO" -> "أهلاً وسهلاً فيك، أنا ريڤو مساعدك الصحي في ممرّضي، كيف بقدر أساعدك؟"
            "MA" -> "مرحباً بك، أنا ريڤو مساعدك الصحي في ممرّضي، أنا هنا لمساعدتك."
            else -> "أهلاً بك، أنا ريڤو مساعدك الصحي في تطبيق ممرّضي، كيف يمكنني مساعدتك اليوم؟"
        }
        tts?.setPitch(persona.pitch)
        tts?.setSpeechRate((rate * persona.rateMultiplier).coerceIn(0.5f, 1.5f))
        val params = android.os.Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, speechVolume)
        }
        tts?.speak(sampleText, TextToSpeech.QUEUE_FLUSH, params, "RIVO_PREVIEW_${System.currentTimeMillis()}")
        isSpeaking = true
    }

    fun speakStreamingChunk(chunk: String, isFirstChunk: Boolean) {
        if (!isInitialized) return
        val clean = cleanTextForNaturalSpeech(chunk)
        if (clean.isBlank()) return
        tts?.setPitch(activePersona.pitch)
        tts?.setSpeechRate((speechRate * activePersona.rateMultiplier).coerceIn(0.5f, 1.5f))
        val queueMode = if (isFirstChunk) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val utteranceId = "RIVO_STREAM_${System.currentTimeMillis()}"
        val params = android.os.Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, speechVolume)
        }
        tts?.speak(clean, queueMode, params, utteranceId)
        tts?.playSilentUtterance(150L, TextToSpeech.QUEUE_ADD, "pause_stream_${System.currentTimeMillis()}")
        isSpeaking = true
    }

    fun speak(text: String) {
        if (!isInitialized) return
        stop()

        val cleanSpokenText = cleanTextForNaturalSpeech(text)
        if (cleanSpokenText.isBlank()) return

        tts?.setSpeechRate((speechRate * activePersona.rateMultiplier).coerceIn(0.5f, 1.5f))
        tts?.setPitch(activePersona.pitch)

        // Split text into short, natural spoken sentences/phrases for breath pauses
        val clauses = cleanSpokenText
            .split(Regex("(?<=[.!\n؟،,])|(?=\\n)"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        if (clauses.isEmpty()) return

        clauses.forEachIndexed { index, clause ->
            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val utteranceId = "MR7_VOICE_${System.currentTimeMillis()}_$index"
            val params = android.os.Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, speechVolume)
            }
            tts?.speak(clause, queueMode, params, utteranceId)
            // Add a natural 180ms breathing pause between sentences
            tts?.playSilentUtterance(180L, TextToSpeech.QUEUE_ADD, "pause_$index")
        }
        isSpeaking = true
    }

    private fun cleanTextForNaturalSpeech(rawText: String): String {
        return rawText
            // Remove emojis & visual UI symbols
            .replace(Regex("[\\uD83C-\\uDBFF\\uDC00-\\uDFFF\\u2700-\\u27BF\\u2600-\\u26FF\\u2300-\\u23FF]"), "")
            // Remove markdown formatting
            .replace(Regex("\\*\\*|\\*|#|_|`|~|>"), "")
            .replace(Regex("\\[(.*?)\\]\\(.*?\\)"), "$1")
            // Remove code or XML tags
            .replace(Regex("<[^>]*>"), "")
            // Remove bullet point symbols
            .replace(Regex("^[\\-*•\\d+\\.]+\\s*", RegexOption.MULTILINE), "")
            // Replace awkward punctuation clusters with commas
            .replace(Regex("[:;\\-]{2,}"), " ، ")
            // Convert time notations like 10:30 to spoken words (10 و 30 دقيقة)
            .replace(Regex("(\\d{1,2}):(\\d{2})")) { match ->
                val h = match.groupValues[1]
                val m = match.groupValues[2]
                if (m == "00") "الساعة $h" else "الساعة $h و $m دقيقة"
            }
            // Add natural pause before medical dosage terms
            .replace(Regex("(\\d+)\\s*(قرص|مجم|ملجم|سم3|كبسولة|مرات|ساعة|ساعات|يومياً|صباحاً|مساءً)"), "$1 $2 ، ")
            // Collapse multiple spaces or newlines
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun stop() {
        if (tts?.isSpeaking == true) {
            tts?.stop()
        }
        isSpeaking = false
    }

    fun setSpeed(rate: Float) {
        speechRate = rate
        tts?.setSpeechRate(rate)
    }

    fun setPitch(pitch: Float) {
        tts?.setPitch(pitch)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
