package com.example.ai

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.*

class TtsHelper(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)

    var isInitialized by mutableStateOf(false)
        private set

    var isSpeaking by mutableStateOf(false)
        private set

    var speechRate by mutableFloatStateOf(0.92f) // Natural human speech cadence

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            setupNaturalAudioAttributes()
            setupNaturalArabicVoice()
            setupUtteranceListener()
            isInitialized = true
        }
    }

    private fun setupNaturalAudioAttributes() {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            tts?.setAudioAttributes(audioAttributes)
        } catch (e: Exception) {
            // Fallback audio settings
        }
    }

    private fun setupNaturalArabicVoice() {
        try {
            val arLocale = Locale("ar", "EG")
            val langResult = tts?.setLanguage(arLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("ar"))
            }

            // Search for highest quality natural/neural human voice available in system
            val voices = tts?.voices
            if (!voices.isNullOrEmpty()) {
                val selectedVoice = voices.filter { voice ->
                    val isArabic = voice.locale.language.equals("ar", ignoreCase = true)
                    val isNotInstalled = voice.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                    isArabic && !isNotInstalled
                }.maxByOrNull { voice ->
                    var score = 0
                    if (voice.quality >= Voice.QUALITY_HIGH) score += 50
                    if (voice.quality >= Voice.QUALITY_NORMAL) score += 20
                    val vName = voice.name.lowercase()
                    if (vName.contains("network") || vName.contains("natural") || vName.contains("neural")) score += 40
                    if (vName.contains("google")) score += 20
                    if (voice.locale.country.equals("EG", ignoreCase = true)) score += 15
                    if (!voice.isNetworkConnectionRequired) score += 10
                    score
                }

                if (selectedVoice != null) {
                    tts?.voice = selectedVoice
                }
            }

            // Warm human pitch & relaxed speech rate
            tts?.setPitch(1.0f)
            tts?.setSpeechRate(speechRate)
        } catch (e: Exception) {
            tts?.setLanguage(Locale("ar"))
        }
    }

    private fun setupUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeaking = true
            }

            override fun onDone(utteranceId: String?) {
                isSpeaking = false
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                isSpeaking = false
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                isSpeaking = false
            }
        })
    }

    fun speak(text: String) {
        if (!isInitialized) return
        stop()

        val cleanSpokenText = cleanTextForNaturalSpeech(text)
        if (cleanSpokenText.isBlank()) return

        tts?.setSpeechRate(speechRate)
        tts?.setPitch(0.98f) // Warm human pitch

        // Split text into short, natural spoken sentences/phrases for breath pauses
        val clauses = cleanSpokenText
            .split(Regex("(?<=[.!\n؟،,])|(?=\\n)"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        if (clauses.isEmpty()) return

        clauses.forEachIndexed { index, clause ->
            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            val utteranceId = "MR7_VOICE_${System.currentTimeMillis()}_$index"
            val params = android.os.Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }
            tts?.speak(clause, queueMode, params, utteranceId)
            // Add a natural 220ms breathing pause between sentences
            tts?.playSilentUtterance(220L, TextToSpeech.QUEUE_ADD, "pause_$index")
        }
        isSpeaking = true
    }

    private fun cleanTextForNaturalSpeech(rawText: String): String {
        return rawText
            // Remove emojis & visual UI symbols
            .replace(Regex("[\\uD83C-\\uDBFF\\uDC00-\\uDFFF\\u2700-\\u27BF\\u2600-\\u26FF\\u2300-\\u23FF]"), "")
            // Remove markdown formatting
            .replace(Regex("\\*\\*|\\*|#|_|`|~|>"), "")
            .replace(Regex("\\[(.*?)\\]\\(.*?\\)"), "$1")
            // Remove code or XML tags
            .replace(Regex("<[^>]*>"), "")
            // Remove bullet point symbols
            .replace(Regex("^[\\-*•\\d+\\.]+\\s*", RegexOption.MULTILINE), "")
            // Replace awkward punctuation clusters with commas
            .replace(Regex("[:;\\-]{2,}"), " ، ")
            // Convert time notations like 10:30 to spoken words (10 و 30 دقيقة)
            .replace(Regex("(\\d{1,2}):(\\d{2})")) { match ->
                val h = match.groupValues[1]
                val m = match.groupValues[2]
                if (m == "00") "الساعة $h" else "الساعة $h و $m دقيقة"
            }
            // Add natural pause before medical dosage terms
            .replace(Regex("(\\d+)\\s*(قرص|مجم|ملجم|سم3|كبسولة|مرات|ساعة|ساعات|يومياً|صباحاً|مساءً)"), "$1 $2 ، ")
            // Collapse multiple spaces or newlines
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun stop() {
        if (tts?.isSpeaking == true) {
            tts?.stop()
        }
        isSpeaking = false
    }

    fun setSpeed(rate: Float) {
        speechRate = rate
        tts?.setSpeechRate(rate)
    }

    fun setPitch(pitch: Float) {
        tts?.setPitch(pitch)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
