package com.example.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

enum class GeminiErrorType {
    NONE,
    TRANSIENT_RATE_LIMIT_OR_SERVER, // 429, 500, 502, 503, 504, timeout, network
    MODEL_NOT_FOUND,                // 404
    PERMANENT_AUTH_OR_REQUEST       // 400, 401, 403 (do NOT retry)
}

data class ModelTransitionEvent(
    val timestampMs: Long,
    val modelName: String,
    val success: Boolean,
    val httpCode: Int,
    val errorType: GeminiErrorType,
    val reason: String,
    val latencyMs: Long
)

data class SmartFallbackResult(
    val success: Boolean,
    val text: String = "",
    val usedModel: String = "",
    val totalLatencyMs: Long = 0L,
    val transitions: List<ModelTransitionEvent> = emptyList(),
    val errorMessage: String = ""
)

class GeminiSmartFallback(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build(),
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta"
) {
    companion object {
        val DEFAULT_RIVO_MODELS = listOf(
            "gemini-3.5-flash-lite",
            "gemini-flash-lite-latest",
            "gemini-3.1-flash-lite",
            "gemini-3.1-flash-lite-preview"
        )

        val STABLE_TEXT_FALLBACKS = listOf(
            "gemini-3.5-flash-lite",
            "gemini-flash-lite-latest",
            "gemini-3.1-flash-lite",
            "gemini-3.1-flash-lite-preview"
        )
    }

    @Volatile
    private var configuredModels: List<String> = DEFAULT_RIVO_MODELS

    private val unavailableModels = ConcurrentHashMap.newKeySet<String>()
    private val transitionLog = CopyOnWriteArrayList<ModelTransitionEvent>()

    @Volatile
    private var verifiedAvailableModels: Set<String>? = null

    fun setModelPriority(models: List<String>) {
        if (models.isNotEmpty()) {
            configuredModels = models.distinct()
        }
    }

    fun getModelPriority(): List<String> = configuredModels

    fun getTransitionLogs(): List<ModelTransitionEvent> = transitionLog.toList()

    fun clearTransitionLogs() {
        transitionLog.clear()
    }

    /**
     * Queries Gemini API /models endpoint to verify which models are actually available
     * and support generateContent. Substitutes unavailable models with stable text models.
     */
    suspend fun verifyAndResolveModels(apiKey: String): List<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext configuredModels

        verifiedAvailableModels?.let { available ->
            return@withContext resolveAgainstAvailable(available)
        }

        try {
            val req = Request.Builder()
                .url("$baseUrl/models?key=$apiKey")
                .get()
                .build()
            val resp = client.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            if (resp.isSuccessful && body.isNotBlank()) {
                val root = JSONObject(body)
                val modelsArr = root.optJSONArray("models") ?: JSONArray()
                val available = mutableSetOf<String>()
                for (i in 0 until modelsArr.length()) {
                    val m = modelsArr.optJSONObject(i) ?: continue
                    val rawName = m.optString("name", "").removePrefix("models/")
                    val methods = m.optJSONArray("supportedGenerationMethods")
                    var supportsGenerate = false
                    if (methods != null) {
                        for (j in 0 until methods.length()) {
                            if (methods.optString(j) == "generateContent") {
                                supportsGenerate = true
                                break
                            }
                        }
                    }
                    if (rawName.isNotBlank() && supportsGenerate) {
                        available.add(rawName)
                    }
                }
                if (available.isNotEmpty()) {
                    verifiedAvailableModels = available
                    return@withContext resolveAgainstAvailable(available)
                }
            }
        } catch (_: Exception) {
            // If /models check fails due to transient network, proceed with configuredModels
        }
        return@withContext configuredModels
    }

    private fun resolveAgainstAvailable(available: Set<String>): List<String> {
        val resolved = mutableListOf<String>()
        for (model in configuredModels) {
            if (available.contains(model)) {
                resolved.add(model)
            } else {
                unavailableModels.add(model)
                transitionLog.add(
                    ModelTransitionEvent(
                        timestampMs = System.currentTimeMillis(),
                        modelName = model,
                        success = false,
                        httpCode = 404,
                        errorType = GeminiErrorType.MODEL_NOT_FOUND,
                        reason = "النموذج $model غير متاح في قائمة النماذج المدعومة، سيتم استبداله بنموذج مستقر متاح.",
                        latencyMs = 0L
                    )
                )
            }
        }
        for (stable in STABLE_TEXT_FALLBACKS) {
            if (available.contains(stable) && !resolved.contains(stable)) {
                resolved.add(stable)
            }
        }
        return if (resolved.isNotEmpty()) resolved else configuredModels
    }

    suspend fun generateWithFallback(
        apiKey: String,
        requestJson: JSONObject,
        maxRetriesPerModel: Int = 2,
        initialBackoffMs: Long = 500L
    ): SmartFallbackResult = withContext(Dispatchers.IO) {
        val overallStart = System.currentTimeMillis()
        if (apiKey.isBlank()) {
            return@withContext SmartFallbackResult(
                success = false,
                totalLatencyMs = 0L,
                errorMessage = "مفتاح Gemini API غير مُعدّ. يرجى إضافته في إعدادات الأسرار (Secrets)."
            )
        }

        val candidateModels = verifyAndResolveModels(apiKey)
            .filterNot { unavailableModels.contains(it) }
            .ifEmpty { STABLE_TEXT_FALLBACKS }

        val localTransitions = mutableListOf<ModelTransitionEvent>()
        var lastErrorMsg = "تعذر الاتصال بنماذج الذكاء الاصطناعي."

        for (model in candidateModels) {
            var attempt = 0
            while (attempt <= maxRetriesPerModel) {
                if (attempt > 0) {
                    val backoff = initialBackoffMs * (1L shl (attempt - 1))
                    delay(backoff)
                }

                val callStart = System.currentTimeMillis()
                try {
                    val url = "$baseUrl/models/$model:generateContent?key=$apiKey"
                    val httpRequest = Request.Builder()
                        .url(url)
                        .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
                        .build()

                    val response = client.newCall(httpRequest).execute()
                    val code = response.code
                    val body = response.body?.string() ?: ""
                    val latency = System.currentTimeMillis() - callStart

                    if (response.isSuccessful && body.isNotBlank()) {
                        val root = JSONObject(body)
                        val text = root.optJSONArray("candidates")
                            ?.optJSONObject(0)
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts")
                            ?.optJSONObject(0)
                            ?.optString("text", "")
                            ?.trim()
                            ?: ""

                        if (text.isNotBlank()) {
                            val event = ModelTransitionEvent(
                                timestampMs = System.currentTimeMillis(),
                                modelName = model,
                                success = true,
                                httpCode = code,
                                errorType = GeminiErrorType.NONE,
                                reason = "نجح الطلب عبر $model",
                                latencyMs = latency
                            )
                            localTransitions.add(event)
                            transitionLog.add(event)
                            return@withContext SmartFallbackResult(
                                success = true,
                                text = text,
                                usedModel = model,
                                totalLatencyMs = System.currentTimeMillis() - overallStart,
                                transitions = localTransitions
                            )
                        }
                    }

                    val errorType = classifyHttpError(code)
                    val reason = when (errorType) {
                        GeminiErrorType.PERMANENT_AUTH_OR_REQUEST ->
                            "خطأ دائم (رمز $code): مفتاح API غير صالح أو الطلب غير مدعوم. لن تتم إعادة المحاولة."
                        GeminiErrorType.MODEL_NOT_FOUND ->
                            "النموذج $model غير موجود (رمز 404)، جاري الانتقال للنموذج الاحتياطي."
                        GeminiErrorType.TRANSIENT_RATE_LIMIT_OR_SERVER ->
                            "ضغط أو تجاوز حصة أو عطل مؤقت في $model (رمز $code)، محاولة ${attempt + 1}."
                        GeminiErrorType.NONE ->
                            "استجابة فارغة من $model."
                    }

                    val event = ModelTransitionEvent(
                        timestampMs = System.currentTimeMillis(),
                        modelName = model,
                        success = false,
                        httpCode = code,
                        errorType = errorType,
                        reason = reason,
                        latencyMs = latency
                    )
                    localTransitions.add(event)
                    transitionLog.add(event)
                    lastErrorMsg = reason

                    if (errorType == GeminiErrorType.PERMANENT_AUTH_OR_REQUEST) {
                        return@withContext SmartFallbackResult(
                            success = false,
                            totalLatencyMs = System.currentTimeMillis() - overallStart,
                            transitions = localTransitions,
                            errorMessage = reason
                        )
                    }

                    if (errorType == GeminiErrorType.MODEL_NOT_FOUND) {
                        unavailableModels.add(model)
                        break // Move immediately to next model
                    }
                } catch (e: Exception) {
                    val latency = System.currentTimeMillis() - callStart
                    val isTimeout = e is SocketTimeoutException || e is IOException
                    val reason = if (isTimeout) {
                        "انتهت مهلة الاتصال أو انقطع الإنترنت مع $model، محاولة ${attempt + 1}."
                    } else {
                        "خطأ غير متوقع مع $model: ${e.localizedMessage ?: "تعذر الاتصال"}"
                    }
                    val event = ModelTransitionEvent(
                        timestampMs = System.currentTimeMillis(),
                        modelName = model,
                        success = false,
                        httpCode = 0,
                        errorType = GeminiErrorType.TRANSIENT_RATE_LIMIT_OR_SERVER,
                        reason = reason,
                        latencyMs = latency
                    )
                    localTransitions.add(event)
                    transitionLog.add(event)
                    lastErrorMsg = reason
                }

                attempt++
            }
        }

        return@withContext SmartFallbackResult(
            success = false,
            totalLatencyMs = System.currentTimeMillis() - overallStart,
            transitions = localTransitions,
            errorMessage = lastErrorMsg
        )
    }

    fun classifyHttpError(httpCode: Int): GeminiErrorType {
        return when (httpCode) {
            400, 401, 403 -> GeminiErrorType.PERMANENT_AUTH_OR_REQUEST
            404 -> GeminiErrorType.MODEL_NOT_FOUND
            429, 500, 502, 503, 504 -> GeminiErrorType.TRANSIENT_RATE_LIMIT_OR_SERVER
            else -> if (httpCode in 500..599) {
                GeminiErrorType.TRANSIENT_RATE_LIMIT_OR_SERVER
            } else {
                GeminiErrorType.PERMANENT_AUTH_OR_REQUEST
            }
        }
    }
}
