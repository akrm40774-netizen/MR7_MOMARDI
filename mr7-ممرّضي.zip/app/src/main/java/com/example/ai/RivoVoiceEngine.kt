package com.example.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.BuildConfig
import com.example.data.local.AppointmentEntity
import com.example.data.local.DoseLogEntity
import com.example.data.local.MedicationEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

enum class RivoConversationState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING
}

enum class RivoConnectionStatus(val labelAr: String) {
    ONLINE("متصل 🟢"),
    OFFLINE("غير متصل 🔴"),
    RECONNECTING("جاري إعادة الاتصال 🟡")
}

data class RivoPendingReminder(
    val medicationName: String,
    val timeDisplay: String,
    val instructions: String
)

data class RivoResponse(
    val text: String,
    val latencyMs: Long,
    val isFromCache: Boolean = false,
    val pendingReminder: RivoPendingReminder? = null
)

interface RivoVoiceProvider {
    suspend fun processQuery(
        query: String,
        language: String,
        dialect: String,
        medications: List<MedicationEntity>,
        todayDoses: List<DoseLogEntity>,
        appointments: List<AppointmentEntity>,
        history: List<Pair<String, String>>
    ): RivoResponse
}

class GeminiRivoProvider : RivoVoiceProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val responseCache = ConcurrentHashMap<String, String>()

    private val apiKey: String
        get() = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

    fun clearCache() {
        responseCache.clear()
    }

    override suspend fun processQuery(
        query: String,
        language: String,
        dialect: String,
        medications: List<MedicationEntity>,
        todayDoses: List<DoseLogEntity>,
        appointments: List<AppointmentEntity>,
        history: List<Pair<String, String>>
    ): RivoResponse = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val cleanInput = query.trim()

        // Check if user is asking to add a new reminder
        val pendingReminder = detectReminderIntent(cleanInput)

        // Check cache for frequent static/general queries
        val cacheKey = "${language}_${dialect}_${cleanInput.lowercase()}"
        val isPersonalQuery = cleanInput.contains("دوا") || cleanInput.contains("ميعاد") ||
            cleanInput.contains("موعد") || cleanInput.contains("جرع") || cleanInput.contains("مخزون")
        if (!isPersonalQuery && pendingReminder == null) {
            responseCache[cacheKey]?.let { cached ->
                return@withContext RivoResponse(
                    text = cached,
                    latencyMs = System.currentTimeMillis() - startTime,
                    isFromCache = true
                )
            }
        }

        val medsContext = if (medications.isEmpty()) {
            "لا توجد أدوية مسجلة حالياً."
        } else {
            medications.joinToString("\n") {
                "- ${it.userNickname} (${it.officialName}): التركيز ${it.concentration}، الشكل ${it.form}، المواعيد ${it.timesOfDay}، التعليمات: ${it.instructions}، المتبقي: ${it.stockCount}"
            }
        }

        val dosesContext = if (todayDoses.isEmpty()) {
            "لا توجد جرعات مجدولة لليوم."
        } else {
            todayDoses.joinToString("\n") {
                "- ${it.medicationName} الساعة ${it.scheduledTime} (${it.status})"
            }
        }

        val appsContext = if (appointments.isEmpty()) {
            "لا توجد مواعيد أطباء قادمة."
        } else {
            appointments.take(3).joinToString("\n") {
                "- د. ${it.doctorName} (${it.specialty}) يوم ${it.dateDisplay} الساعة ${it.timeDisplay}"
            }
        }

        val dialectInstruction = when {
            language == "en" -> "Respond in clear, friendly, natural English."
            dialect == "EG" -> "تحدث باللهجة المصرية الطبيعية الودودة والهادئة."
            dialect == "SA" -> "تحدث باللهجة السعودية / الخليجية المهذبة والودودة."
            dialect == "AE" -> "تحدث باللهجة الإماراتية المهذبة والودودة."
            dialect == "JO" -> "تحدث باللهجة الشامية المهذبة والودودة."
            dialect == "MA" -> "تحدث باللهجة المغاربية الواضحة والودودة."
            else -> "تحدث باللغة العربية الفصحى البسيطة والواضحة."
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val systemPrompt = """
                    أنت 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 (ريڤو) - المساعد الصوتي الذكي داخل تطبيق 𝐌𝐑𝟕 ممرّضي.
                    $dialectInstruction
                    أسلوبك: ودود، واضح، هادئ، طبيعي وغير متكلف.
                    
                    بيانات المستخدم المصرح بها:
                    [الأدوية المسجلة]:
                    $medsContext
                    
                    [جرعات اليوم]:
                    $dosesContext
                    
                    [مواعيد الأطباء]:
                    $appsContext
                    
                    قواعد صارمة:
                    1. أجب بإيجاز ووضوح (جملة إلى 3 جمل قصيرة) لأن الرد يُنطق صوتياً.
                    2. ممنوع تماماً تغيير جرعات الأدوية أو إيقاف علاج أو تقديم تشخيص طبي من تلقاء نفسك؛ وجّه المستخدم لاستشارة الطبيب أو الصيدلي.
                    3. ممنوع استخدام أي رموز ماركداون (* أو # أو _).
                """.trimIndent()

                val partsArray = JSONArray()
                history.takeLast(4).forEach { (sender, text) ->
                    val role = if (sender == "USER") "المستخدم" else "ريڤو"
                    partsArray.put(JSONObject().put("text", "$role: $text"))
                }
                partsArray.put(JSONObject().put("text", "المستخدم: $cleanInput"))

                val requestJson = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", partsArray)))
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                    .put("generationConfig", JSONObject().put("temperature", 0.3).put("maxOutputTokens", 180))

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(request).execute()
                val body = response.body?.string() ?: ""
                if (response.isSuccessful && body.isNotBlank()) {
                    val root = JSONObject(body)
                    val reply = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text", "")
                        ?.replace(Regex("[\\*#_`~>•]"), "")
                        ?.trim()

                    if (!reply.isNullOrBlank()) {
                        if (!isPersonalQuery && pendingReminder == null) {
                            responseCache[cacheKey] = reply
                        }
                        return@withContext RivoResponse(
                            text = reply,
                            latencyMs = System.currentTimeMillis() - startTime,
                            pendingReminder = pendingReminder
                        )
                    }
                }
            } catch (_: Exception) {
                // Fallback to local intelligent engine
            }
        }

        val fallbackText = generateLocalRivoResponse(
            query = cleanInput,
            medications = medications,
            todayDoses = todayDoses,
            appointments = appointments,
            pendingReminder = pendingReminder
        )
        return@withContext RivoResponse(
            text = fallbackText,
            latencyMs = System.currentTimeMillis() - startTime,
            pendingReminder = pendingReminder
        )
    }

    private fun detectReminderIntent(query: String): RivoPendingReminder? {
        val q = query.lowercase()
        if (q.contains("ذكرني") || q.contains("أضف تذكير") || q.contains("اضف تذكير") || q.contains("منبه دواء")) {
            val medName = query
                .replace(Regex("ذكرني بـ|ذكرني ب|ذكرني|أضف تذكير|اضف تذكير|دواء"), "")
                .trim()
                .ifBlank { "دواء جديد" }
            return RivoPendingReminder(
                medicationName = medName,
                timeDisplay = "08:00 م",
                instructions = "حسب إرشادات الطبيب"
            )
        }
        return null
    }

    private fun generateLocalRivoResponse(
        query: String,
        medications: List<MedicationEntity>,
        todayDoses: List<DoseLogEntity>,
        appointments: List<AppointmentEntity>,
        pendingReminder: RivoPendingReminder?
    ): String {
        if (pendingReminder != null) {
            return "جهزت لك تذكير لدواء ${pendingReminder.medicationName} الساعة ${pendingReminder.timeDisplay}. اضغط تأكيد لإضافته لجدولك."
        }
        val q = query.lowercase()
        if (q.contains("تغيير جرعة") || q.contains("أوقف") || q.contains("اوقف") || q.contains("تشخيص")) {
            return "لأمانك الطبي، لا يمكنني تغيير الجرعات أو إيقاف أي علاج أو تقديم تشخيص. يرجى مراجعة طبيبك المعالج فوراً."
        }
        for (med in medications) {
            if (q.contains(med.userNickname.lowercase()) || (med.officialName.isNotBlank() && q.contains(med.officialName.lowercase()))) {
                return "دواء ${med.userNickname}، تركيزه ${med.concentration}، ومواعيده ${med.timesOfDay}، والتعليمات: ${med.instructions}."
            }
        }
        return when {
            q.contains("موعد") || q.contains("ميعاد") || q.contains("عيادة") || q.contains("دكتور") -> {
                val nextApp = appointments.firstOrNull { !it.isCompleted }
                if (nextApp != null) {
                    "موعدك القادم مع دكتور ${nextApp.doctorName} يوم ${nextApp.dateDisplay} الساعة ${nextApp.timeDisplay}."
                } else {
                    "لا توجد مواعيد أطباء قادمة مسجلة حالياً."
                }
            }
            q.contains("أدوي") || q.contains("ادوي") || q.contains("جرع") -> {
                if (medications.isNotEmpty()) {
                    "عندك ${medications.size} أدوية مسجلة، أقربها ${medications.first().userNickname} الساعة ${medications.first().timesOfDay}."
                } else {
                    "لا توجد أدوية مسجلة في جدولك حالياً."
                }
            }
            else -> "أهلاً بك، أنا ريڤو مساعدك في ممرّضي. يمكنك سؤالي عن مواعيد أدويتك أو عياداتك أو طلب إضافة تذكير."
        }
    }

    companion object {
        fun checkConnectionStatus(context: Context): RivoConnectionStatus {
            return try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val network = cm?.activeNetwork ?: return RivoConnectionStatus.OFFLINE
                val caps = cm.getNetworkCapabilities(network) ?: return RivoConnectionStatus.OFFLINE
                if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    RivoConnectionStatus.ONLINE
                } else {
                    RivoConnectionStatus.OFFLINE
                }
            } catch (_: Exception) {
                RivoConnectionStatus.ONLINE
            }
        }
    }
}
