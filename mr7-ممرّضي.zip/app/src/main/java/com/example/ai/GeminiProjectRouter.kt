package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

enum class GeminiProject(val displayName: String, val envVarName: String) {
    MR7_VERSION("MR7 Version", "GEMINI_MR7_VERSION_API_KEY"),
    MR7_MEDICAL("MR7 Medical", "GEMINI_MR7_MEDICAL_API_KEY"),
    MR7_ALLERGY("MR7 حساسية", "GEMINI_MR7_ALLERGY_API_KEY")
}

data class GeminiCallResult(
    val success: Boolean,
    val text: String = "",
    val latencyMs: Long = 0L,
    val httpCode: Int = 0,
    val errorMessage: String = "",
    val groundingSources: List<String> = emptyList()
)

data class ProjectMetrics(
    val totalCalls: Int,
    val avgLatencyMs: Long,
    val errorCount: Int
)

object GeminiProjectRouter {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    val rivoSmartFallback = GeminiSmartFallback(client = client)

    suspend fun generateRivoContent(requestJson: JSONObject): SmartFallbackResult {
        val key = getApiKey(GeminiProject.MR7_VERSION)
        if (key.isBlank()) {
            return SmartFallbackResult(
                success = false,
                errorMessage = missingKeyMessageAr(GeminiProject.MR7_VERSION)
            )
        }
        return rivoSmartFallback.generateWithFallback(
            apiKey = key,
            requestJson = requestJson
        )
    }

    private val inFlightRequests = ConcurrentHashMap<String, CompletableDeferred<GeminiCallResult>>()
    private val callCounts = ConcurrentHashMap<GeminiProject, AtomicInteger>()
    private val totalLatencies = ConcurrentHashMap<GeminiProject, AtomicLong>()
    private val errorCounts = ConcurrentHashMap<GeminiProject, AtomicInteger>()

    fun getApiKey(project: GeminiProject): String {
        val raw = when (project) {
            GeminiProject.MR7_VERSION -> safeBuildConfig { BuildConfig.GEMINI_MR7_VERSION_API_KEY }
            GeminiProject.MR7_MEDICAL -> safeBuildConfig { BuildConfig.GEMINI_MR7_MEDICAL_API_KEY }
            GeminiProject.MR7_ALLERGY -> safeBuildConfig { BuildConfig.GEMINI_MR7_ALLERGY_API_KEY }
        }
        if (isValidKey(raw)) return raw
        val legacy = safeBuildConfig { BuildConfig.GEMINI_API_KEY }
        return if (isValidKey(legacy)) legacy else ""
    }

    private fun isValidKey(key: String): Boolean {
        return key.isNotBlank() &&
            !key.startsWith("YOUR_") &&
            key != "MY_GEMINI_API_KEY"
    }

    private inline fun safeBuildConfig(block: () -> String): String {
        return try {
            block().trim()
        } catch (_: Exception) {
            ""
        }
    }

    fun isKeyConfigured(project: GeminiProject): Boolean = getApiKey(project).isNotBlank()

    fun missingKeyMessageAr(project: GeminiProject): String {
        return "مفتاح الخدمة (${project.envVarName}) الخاص بمشروع ${project.displayName} غير مُعدّ حالياً. يرجى إضافته في إعدادات الأسرار (Secrets) في AI Studio."
    }

    fun getMetrics(project: GeminiProject): ProjectMetrics {
        val calls = callCounts[project]?.get() ?: 0
        val totalLat = totalLatencies[project]?.get() ?: 0L
        val errs = errorCounts[project]?.get() ?: 0
        return ProjectMetrics(
            totalCalls = calls,
            avgLatencyMs = if (calls > 0) totalLat / calls else 0L,
            errorCount = errs
        )
    }

    suspend fun generateContent(
        project: GeminiProject,
        requestJson: JSONObject,
        useGoogleSearch: Boolean = false,
        dedupeKey: String? = null
    ): GeminiCallResult = withContext(Dispatchers.IO) {
        val key = getApiKey(project)
        if (key.isBlank()) {
            return@withContext GeminiCallResult(
                success = false,
                errorMessage = missingKeyMessageAr(project)
            )
        }

        if (dedupeKey != null) {
            val existing = inFlightRequests[dedupeKey]
            if (existing != null) {
                return@withContext existing.await()
            }
        }

        val deferred = CompletableDeferred<GeminiCallResult>()
        if (dedupeKey != null) {
            inFlightRequests[dedupeKey] = deferred
        }

        try {
            if (useGoogleSearch) {
                val tools = JSONArray().put(JSONObject().put("google_search", JSONObject()))
                requestJson.put("tools", tools)
            }

            val startTime = System.currentTimeMillis()
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key"
            var lastCode = 0
            var lastError = ""

            for (attempt in 0..2) {
                if (attempt > 0) {
                    delay(600L * attempt)
                }
                try {
                    val httpRequest = Request.Builder()
                        .url(url)
                        .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
                        .build()

                    val response = client.newCall(httpRequest).execute()
                    lastCode = response.code
                    val body = response.body?.string() ?: ""

                    if (response.isSuccessful && body.isNotBlank()) {
                        val latency = System.currentTimeMillis() - startTime
                        recordMetrics(project, latency, isError = false)

                        val root = JSONObject(body)
                        val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
                        val text = candidate
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts")
                            ?.optJSONObject(0)
                            ?.optString("text", "")
                            ?.trim()
                            ?: ""

                        val sources = mutableListOf<String>()
                        val chunks = candidate
                            ?.optJSONObject("groundingMetadata")
                            ?.optJSONArray("groundingChunks")
                        if (chunks != null) {
                            for (i in 0 until chunks.length()) {
                                val web = chunks.optJSONObject(i)?.optJSONObject("web")
                                val title = web?.optString("title", "") ?: ""
                                val uri = web?.optString("uri", "") ?: ""
                                if (title.isNotBlank() || uri.isNotBlank()) {
                                    sources.add(if (title.isNotBlank()) "$title ($uri)" else uri)
                                }
                            }
                        }

                        val result = GeminiCallResult(
                            success = text.isNotBlank(),
                            text = text,
                            latencyMs = latency,
                            httpCode = lastCode,
                            groundingSources = sources.distinct()
                        )
                        deferred.complete(result)
                        return@withContext result
                    }

                    if (lastCode == 429 || lastCode == 503) {
                        lastError = "الخدمة مشغولة حالياً (رمز $lastCode)، جاري إعادة المحاولة..."
                        continue
                    } else {
                        lastError = "تعذر إتمام الطلب (رمز $lastCode)"
                        break
                    }
                } catch (e: Exception) {
                    lastError = "تعذر الاتصال بالخادم، يرجى التحقق من الإنترنت"
                }
            }

            val latency = System.currentTimeMillis() - startTime
            recordMetrics(project, latency, isError = true)
            val failResult = GeminiCallResult(
                success = false,
                latencyMs = latency,
                httpCode = lastCode,
                errorMessage = lastError.ifBlank { "حدث خطأ غير متوقع أثناء الاتصال" }
            )
            deferred.complete(failResult)
            return@withContext failResult
        } finally {
            if (dedupeKey != null) {
                inFlightRequests.remove(dedupeKey)
            }
        }
    }

    private fun recordMetrics(project: GeminiProject, latencyMs: Long, isError: Boolean) {
        callCounts.getOrPut(project) { AtomicInteger(0) }.incrementAndGet()
        totalLatencies.getOrPut(project) { AtomicLong(0L) }.addAndGet(latencyMs)
        if (isError) {
            errorCounts.getOrPut(project) { AtomicInteger(0) }.incrementAndGet()
        }
    }
}
