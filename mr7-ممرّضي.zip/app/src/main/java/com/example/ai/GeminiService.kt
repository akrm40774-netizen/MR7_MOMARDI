package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.MedicationEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class VisionScanResult(
    val medicationName: String,
    val concentration: String,
    val instructions: String,
    val frequency: String,
    val doctorName: String,
    val reviewDate: String,
    val confidence: String, // "🟢 واضح", "🟡 يحتاج مراجعة", "🔴 غير واضح"
    val confidenceDetails: String,
    val rawText: String
)

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val apiKey: String
        get() = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

    // --- MR7 VOICE CONVERSATION ---
    suspend fun processVoiceChat(
        userInput: String,
        medications: List<MedicationEntity>,
        conversationHistory: List<Pair<String, String>>,
        isSeniorMode: Boolean
    ): String = withContext(Dispatchers.IO) {
        if (userInput.isBlank()) return@withContext "أهلاً بك! قولي عايز تعرف إيه عن أدويتك أو مواعيدك وأنا معاك."

        val localResponse = tryMatchLocalVoiceQuery(userInput, medications)
        if (localResponse != null) {
            return@withContext localResponse
        }

        if (apiKey.isBlank()) {
            return@withContext "ممرّضي معاك! قولي عايز تعرف إيه، عندك ${medications.size} أدوية مسجلة حاليًا."
        }

        try {
            val systemPrompt = """
                أنت ممرّضي (MR7 Voice) - مساعد صحي شخصي ذكي يتحدث باللهجة المصرية البسيطة جداً وبصوت مريح.
                قواعد هامة جداً للسرعة والسلامة:
                1. صغ إجابتك في جملة واحدة أو جملتين قصيرتين فقط وبشكل مباشر جداً وبدون أي مقدمات أو حشو.
                2. بدون استخدام رموز ماركداون (لا تستخدم ** ولا أسهم ولا قوائم نقطية).
                3. لا تقم بتشخيص أمراض أو تغيير جرعات. اعتمد فقط على بيانات الأدوية المسجلة.
                4. أجب بالعامية المصرية الودودة.

                الأدوية المسجلة:
                ${medications.joinToString("\n") { "- ${it.userNickname} (${it.officialName}), التركيز: ${it.concentration}, الموعد: ${it.timesOfDay}, المتبقي: ${it.stockCount}" }}
            """.trimIndent()

            val partsArray = JSONArray()

            conversationHistory.takeLast(2).forEach { (sender, text) ->
                val role = if (sender == "USER") "المستخدم" else "ممرّضي"
                partsArray.put(JSONObject().put("text", "$role: $text"))
            }
            partsArray.put(JSONObject().put("text", "المستخدم: $userInput"))

            val contentsArray = JSONArray().put(JSONObject().put("parts", partsArray))
            val sysInstructionObj = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))

            val genConfigObj = JSONObject()
                .put("temperature", 0.2)
                .put("maxOutputTokens", 120)

            val requestJsonObj = JSONObject()
                .put("contents", contentsArray)
                .put("systemInstruction", sysInstructionObj)
                .put("generationConfig", genConfigObj)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val httpRequest = Request.Builder()
                .url(url)
                .post(requestJsonObj.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(httpRequest).execute()
            val responseStr = response.body?.string() ?: ""

            if (response.isSuccessful && responseStr.isNotBlank()) {
                val root = JSONObject(responseStr)
                val candidates = root.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val cand = candidates.getJSONObject(0)
                    val content = cand.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val replyText = parts.getJSONObject(0).optString("text", "")
                        if (replyText.isNotBlank()) {
                            return@withContext replyText.trim()
                        }
                    }
                }
            }

            localResponse ?: "تمام يا فندم، أنا معاك. أدويتك المسجلة هي: ${medications.joinToString(", ") { it.userNickname }}."
        } catch (e: Exception) {
            localResponse ?: "ولا يهمك، قولي بس إنت عايز تعرف إيه عن أدويتك وأنا هساعدك فوراً."
        }
    }

    private fun tryMatchLocalVoiceQuery(query: String, medications: List<MedicationEntity>): String? {
        val q = query.trim().lowercase()

        if (q.contains("عظام") || q.contains("العظام")) {
            val med = medications.find { it.userNickname.contains("عظام") || it.officialName.contains("Calcium", ignoreCase = true) }
            if (med != null) {
                return "دواء العظام المسجل عندك هو: ${med.userNickname} (${med.officialName}). معاده: ${med.timesOfDay}، والمخزون المتبقي منه: ${med.stockCount} حبة."
            }
        }
        if (q.contains("ضغط") || q.contains("الضغط") || q.contains("قلب") || q.contains("القلب")) {
            val med = medications.find { it.userNickname.contains("قلب") || it.userNickname.contains("ضغط") || it.officialName.contains("Aspirin", ignoreCase = true) }
            if (med != null) {
                return "دواء القلب والضغط المسجل هو: ${med.userNickname} (${med.officialName}). معاده: ${med.timesOfDay}، ومخزونه الحالي ${med.stockCount} حبة."
            }
        }
        if (q.contains("مضاد") || q.contains("المضاد")) {
            val med = medications.find { it.userNickname.contains("مضاد") || it.officialName.contains("Amoxicillin", ignoreCase = true) }
            if (med != null) {
                return "المضاد الحيوي المسجل: ${med.userNickname}. معاده: ${med.timesOfDay}، والمخزون الحالي: ${med.stockCount} كبسولة."
            }
        }
        if (q.contains("دكتور") || q.contains("طبيب") || q.contains("موعد")) {
            return if (medications.isNotEmpty()) {
                "يمكنك الاطلاع على مواعيدك وأدويتك المسجلة في شريط التنقل السفلي."
            } else {
                "لا توجد أدوية أو مواعيد مسجلة حالياً. يمكنك إضافة دواء أو موعد جديد بسهولة."
            }
        }
        if (q.contains("أخدت") || q.contains("اخدت") || q.contains("نسيت")) {
            return if (medications.isNotEmpty()) {
                "يرجى مراجعة قائمة الجرعات اليومية المسجلة للتأكد من حالة الجرعة."
            } else {
                "لم تقم بتسجيل أي أدوية بعد."
            }
        }
        return null
    }

    // --- MR7 VISION SCANNING ---
    suspend fun analyzePrescriptionOrPackage(
        bitmap: Bitmap,
        scanType: String
    ): VisionScanResult = withContext(Dispatchers.IO) {

        if (apiKey.isNotBlank()) {
            try {
                val maxDim = 1024
                val scaledBitmap = if (bitmap.width > maxDim || bitmap.height > maxDim) {
                    val ratio = minOf(maxDim.toFloat() / bitmap.width, maxDim.toFloat() / bitmap.height)
                    Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
                } else {
                    bitmap
                }

                val stream = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream)
                val base64Image = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

                val prompt = if (scanType == "PRESCRIPTION") {
                    """
                        أنت نظام MR7 Vision السريع جداً لتحليل الروشتات الطبية. استخرج البيانات بدقة متناهية.
                        قم بإرجاع النتيجة بتنسيق JSON فقط:
                        {
                          "medicationName": "اسم الدواء",
                          "concentration": "التركيز",
                          "instructions": "التعليمات",
                          "frequency": "التكرار اليومي",
                          "doctorName": "اسم الطبيب",
                          "reviewDate": "تاريخ المراجعة",
                          "confidence": "🟢 واضح",
                          "confidenceDetails": "تفاصيل درجة الثقة"
                        }
                    """.trimIndent()
                } else {
                    """
                        أنت نظام MR7 Vision لقراءة عبوة الدواء. استخرج البيانات المطبوعة بدقة.
                        قم بإرجاع النتيجة بتنسيق JSON فقط:
                        {
                          "medicationName": "اسم الدواء",
                          "concentration": "التركيز",
                          "instructions": "طريقة الاستخدام",
                          "frequency": "التكرار",
                          "doctorName": "غير محدد",
                          "reviewDate": "غير محدد",
                          "confidence": "🟢 واضح",
                          "confidenceDetails": "عبوة مطبوعة"
                        }
                    """.trimIndent()
                }

                val inlineDataObj = JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", base64Image)

                val partsArray = JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("inlineData", inlineDataObj))

                val genConfigObj = JSONObject()
                    .put("temperature", 0.1)
                    .put("maxOutputTokens", 250)
                    .put("responseMimeType", "application/json")

                val requestJsonObj = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", partsArray)))
                    .put("generationConfig", genConfigObj)

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

                val httpRequest = Request.Builder()
                    .url(url)
                    .post(requestJsonObj.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(httpRequest).execute()
                val responseStr = response.body?.string() ?: ""

                if (response.isSuccessful && responseStr.isNotBlank()) {
                    val root = JSONObject(responseStr)
                    val candidates = root.optJSONArray("candidates")
                    val text = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text", "") ?: ""

                    if (text.isNotBlank()) {
                        val cleanJson = text.substringAfter("{").substringBeforeLast("}")
                        if (cleanJson.isNotBlank()) {
                            val jsonObj = JSONObject("{$cleanJson}")

                            val name = jsonObj.optString("medicationName", "")
                            val conc = jsonObj.optString("concentration", "")
                            val inst = jsonObj.optString("instructions", "")
                            val freq = jsonObj.optString("frequency", "")
                            val doc = jsonObj.optString("doctorName", "")
                            val rev = jsonObj.optString("reviewDate", "")
                            val conf = jsonObj.optString("confidence", "")
                            val details = jsonObj.optString("confidenceDetails", "")

                            return@withContext VisionScanResult(
                                medicationName = if (name.isBlank()) "دواء غير مسمى" else name,
                                concentration = if (conc.isBlank()) "غير محدد" else conc,
                                instructions = if (inst.isBlank()) "حسَب إرشادات الطبيب" else inst,
                                frequency = if (freq.isBlank()) "غير محدد" else freq,
                                doctorName = if (doc.isBlank()) "غير محدد" else doc,
                                reviewDate = if (rev.isBlank()) "غير محدد" else rev,
                                confidence = if (conf.isBlank()) "🟢 تم التحليل" else conf,
                                confidenceDetails = if (details.isBlank()) "تم استخراج النص المتاح بنجاح" else details,
                                rawText = text
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // Fallback below
            }
        }

        // Generic fallback when API is offline or image unreadable
        if (scanType == "PRESCRIPTION") {
            VisionScanResult(
                medicationName = "يرجى كتابة اسم الدواء",
                concentration = "غير محدد",
                instructions = "يرجى كتابة التعليمات",
                frequency = "غير محدد",
                doctorName = "غير محدد",
                reviewDate = "غير محدد",
                confidence = "🟡 قراءة أولية",
                confidenceDetails = "يرجى مراجعة وتأكيد بيانات الروشتة يدويًا",
                rawText = ""
            )
        } else {
            VisionScanResult(
                medicationName = "يرجى كتابة اسم الدواء",
                concentration = "غير محدد",
                instructions = "يرجى كتابة التعليمات",
                frequency = "غير محدد",
                doctorName = "غير محدد",
                reviewDate = "غير محدد",
                confidence = "🟡 قراءة أولية",
                confidenceDetails = "يرجى مراجعة وتأكيد بيانات عبوة الدواء يدويًا",
                rawText = ""
            )
        }
    }
}
