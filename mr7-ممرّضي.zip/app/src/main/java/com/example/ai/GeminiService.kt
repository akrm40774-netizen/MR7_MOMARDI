package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.MedicationEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class VisionScanResult(
    val medicationName: String,
    val activeIngredient: String,
    val concentration: String,
    val dosageForm: String,
    val dosageUnits: String,
    val frequency: String,
    val timing: String,
    val durationDays: String,
    val stockCount: Int,
    val instructions: String,
    val manufacturer: String = "",
    val additionalInfo: String = "",
    val doctorName: String = "",
    val doctorNotes: String = "",
    val confidence: String,
    val isConfirmedByAi: Boolean,
    val confidenceDetails: String,
    val rawExtractedText: String,
    val latencyMs: Long = 0L
)

data class AllergySuggestionItem(
    val unifiedNameAr: String,
    val unifiedNameEn: String,
    val categoryAr: String, // e.g. "حساسية تنفسية" / "التهاب الجيوب الأنفية" / "حساسية دوائية"
    val confidencePercent: Int,
    val explanationAr: String
)

data class AllergySuggestionResponse(
    val suggestions: List<AllergySuggestionItem>,
    val confirmationQuestionAr: String? = null,
    val errorMessage: String? = null,
    val latencyMs: Long = 0L
)

enum class AllergyConflictStatus {
    SAFE_NO_KNOWN_CONFLICT,
    POTENTIAL_CONFLICT,
    INSUFFICIENT_DATA
}

data class AllergyCompatibilityResult(
    val status: AllergyConflictStatus,
    val warningTitleAr: String,
    val matchedIngredient: String,
    val reasonAr: String,
    val verifiedActiveIngredients: List<String>,
    val sources: List<String>,
    val accessedAt: String,
    val latencyMs: Long = 0L
)

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val apiKey: String
        get() = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

    // --- MR7 INTELLIGENT VOICE CONVERSATION ---
    suspend fun processVoiceChat(
        userInput: String,
        medications: List<MedicationEntity>,
        conversationHistory: List<Pair<String, String>>,
        isSeniorMode: Boolean
    ): String = withContext(Dispatchers.IO) {
        val cleanInput = userInput.trim()
        if (cleanInput.isBlank()) {
            return@withContext "أهلاً بك! قولي تحب تعرف إيه عن أدويتك أو روتينك الصحي اليوم؟"
        }

        val medsContext = if (medications.isEmpty()) {
            "لا توجد أدوية مسجلة في جدول المستخدم حتى الآن."
        } else {
            medications.joinToString("\n") {
                "- ${it.userNickname} (الاسم العلمي: ${it.officialName}), التركيز: ${it.concentration}, الشكل: ${it.form}, المواعيد: ${it.timesOfDay}, التعليمات: ${it.instructions}, المتبقي في المخزون: ${it.stockCount} ${it.form}"
            }
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val systemPrompt = """
                    أنت ممرّضي (𝐌𝐑𝟕 Voice) - المساعد الصحي والدوائي الذكي للمستخدم. تتحدث باللغة العربية البسيطة وباللهجة المصرية المهذبة والمريحة.
                    
                    سياق أدوية المستخدم المسجلة حالياً:
                    $medsContext
                    
                    قواعد الإجابة الإلزامية:
                    1. افهم السؤال جيداً وأجب بدقة وواقعية وفقاً لمضمون السؤال وسياق الأدوية المتاحة.
                    2. ممنوع تكرار نفس الرد الجاهز على أسئلة مختلفة.
                    3. صغ إجابتك في جملة أو جملتين مباشرتين جداً وواضحتين ومفيدة بدون حشو أو مقدمات مكررة.
                    4. تعامل مع أسئلة الأدوية بحذر ووعي، لا تقترح جرعات جديدة من عندك، وإذا سأل عن دواء غير مسجل أو معلومة غير مؤكدة، اطلب منه استشارة الطبيب المعالج أو الصيدلي فوراً.
                    5. ممنوع تماماً استخدام أي رموز ماركداون (مثل النجوم ** أو الشُرط أو علامات الترقيم الغريبة) لأن هذا النص يتم نطقه صوتياً مباشرة للمريض.
                """.trimIndent()

                val partsArray = JSONArray()

                // Add recent history for context
                conversationHistory.takeLast(4).forEach { (sender, text) ->
                    val role = if (sender == "USER") "المستخدم" else "ممرّضي"
                    partsArray.put(JSONObject().put("text", "$role: $text"))
                }
                partsArray.put(JSONObject().put("text", "المستخدم: $cleanInput"))

                val contentsArray = JSONArray().put(JSONObject().put("parts", partsArray))
                val sysInstructionObj = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))

                val genConfigObj = JSONObject()
                    .put("temperature", 0.3)
                    .put("maxOutputTokens", 150)

                val requestJsonObj = JSONObject()
                    .put("contents", contentsArray)
                    .put("systemInstruction", sysInstructionObj)
                    .put("generationConfig", genConfigObj)

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

                val httpRequest = Request.Builder()
                    .url(url)
                    .post(requestJsonObj.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(httpRequest).execute()
                val responseStr = response.body?.string() ?: ""

                if (response.isSuccessful && responseStr.isNotBlank()) {
                    val root = JSONObject(responseStr)
                    val candidates = root.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val cand = candidates.getJSONObject(0)
                        val content = cand.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val replyText = parts.getJSONObject(0).optString("text", "")
                            if (replyText.isNotBlank()) {
                                return@withContext cleanResponseForSpeech(replyText.trim())
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Network / Gemini fallback handled contextually below
            }
        }

        // Contextual intelligent offline fallback based on the actual question
        return@withContext generateContextualOfflineResponse(cleanInput, medications)
    }

    private fun cleanResponseForSpeech(text: String): String {
        return text
            .replace(Regex("[\\*#_`~>•-]"), "")
            .replace("mg", "مليجرام")
            .replace("ml", "مليلتر")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun generateContextualOfflineResponse(query: String, medications: List<MedicationEntity>): String {
        val q = query.lowercase().trim()

        // Check for specific medication inquiries
        for (med in medications) {
            val nick = med.userNickname.lowercase()
            val off = med.officialName.lowercase()
            if (q.contains(nick) || (off.isNotBlank() && q.contains(off))) {
                return "بالنسبة لـ ${med.userNickname}، معاده المسجل هو ${med.timesOfDay}، وتعليماته: ${med.instructions}، وباقي في العلبة ${med.stockCount} ${med.form}."
            }
        }

        return when {
            q.contains("ميعاد") || q.contains("موعد") || q.contains("امتى") || q.contains("ساعة") -> {
                if (medications.isNotEmpty()) {
                    val first = medications.first()
                    "أقرب دواء مسجل هو ${first.userNickname} في تمام ${first.timesOfDay}."
                } else {
                    "ما عندكش أدوية مسجلة حالياً لليوم، تحب نضيف دواء جديد في جدولك؟"
                }
            }
            q.contains("مخزون") || q.contains("ناقص") || q.contains("علبة") || q.contains("فاضل") -> {
                val lowMeds = medications.filter { it.stockCount <= it.refillThreshold }
                if (lowMeds.isNotEmpty()) {
                    "خلي بالك، الأدوية اللي قربت تخلص هي: ${lowMeds.joinToString(" و ") { it.userNickname }}."
                } else {
                    "كل أدويتك المسجلة مخزونها كافي ومطمئن ومفيش أي نواقص حالياً."
                }
            }
            q.contains("ازيك") || q.contains("سلام") || q.contains("صباح") || q.contains("مساء") -> {
                "أهلاً بحضرتك، يومك سعيد وصحتك دائماً بخير. أنا معاك لأي سؤال عن أدويتك أو روتينك."
            }
            q.contains("شكرا") || q.contains("تسلم") || q.contains("تمام") -> {
                "الشكر لله يا فندم، بالصحة والعافية دايماً وأنا في خدمتك في أي وقت."
            }
            else -> {
                if (medications.isNotEmpty()) {
                    "سؤالك واضح ومهم. بخصوص جدولك الصحي، عندك ${medications.size} أدوية مسجلة حالياً، تقدر تسألني عن مواعيد أي دواء منهم أو مخزونه."
                } else {
                    "أنا ممرّضي وسامعك بكل اهتمام. للحفاظ على سلامتك، استشر طبيبك أو الصيدلي عن أي تفاصيل طبية دقيقة."
                }
            }
        }
    }

    // --- MR7 REAL OCR & MULTIMODAL MEDICAL SCANNING (Project: MR7 Medical) ---
    suspend fun analyzePrescriptionOrPackage(
        bitmap: Bitmap,
        scanType: String
    ): VisionScanResult = withContext(Dispatchers.IO) {
        val maxDim = 1280
        val scaledBitmap = if (bitmap.width > maxDim || bitmap.height > maxDim) {
            val ratio = minOf(maxDim.toFloat() / bitmap.width, maxDim.toFloat() / bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
        } else {
            bitmap
        }

        val stream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val base64Image = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

        val prompt = """
            أنت خبير OCR وتحليل روشتات وعلب أدوية متقدم (𝐌𝐑𝟕 Medical Vision).
            نوع الصورة: ${if (scanType == "PRESCRIPTION") "روشتة طبية مكتوبة بخط اليد أو مطبوعة" else "علبة دواء أو شريط دواء مطبوع"}.
            
            قواعد صارمة جداً:
            1. استخرج فقط المعلومات الظاهرة بوضوح في الصورة. ممنوع تماماً اختراع أو تخمين أي اسم دواء أو تركيز أو عدد أقراص أو مدة علاج غير مكتوبة.
            2. لا تضع التركيز (مثل 1000 mg) مكان اسم الدواء التجاري (مثل Doliprane).
            3. لا تضع المادة الفعالة (مثل Paracetamol) مكان التركيز.
            4. إذا كان حقل غير ظاهر في الصورة، اتركه فارغاً "" (وبالنسبة لـ stockCount اجعله 0 إذا لم يكن مكتوباً).
            5. في الروشتات: ميّز بدقة بين اسم الدواء، والتركيز، والجرعة بالمرة الواحدة، وعدد مرات الاستخدام، وتوقيت الاستخدام (مثل: قبل الإفطار، بعد الطعام، الساعة 8 صباحاً)، ومدة العلاج.
            6. إذا كانت الكتابة غير واضحة أو بها انعكاس ضوء أو ميلان يمنع القراءة المؤكدة، اجعل isConfirmedByAi = false و confidence = "🟡 يحتاج مراجعة وتأكيد" واشرح السبب في confidenceDetails.
            
            أعد النتيجة بتنسيق JSON حصري:
            {
              "medicationName": "اسم الدواء التجاري فقط كما هو مكتوب",
              "activeIngredient": "المادة الفعالة إن كانت مكتوبة",
              "concentration": "التركيز مثل 1000 mg أو 500 mg إن كان مكتوباً",
              "dosageForm": "قرص أو كبسولة أو شراب أو مرهم أو حقن",
              "dosageUnits": "الجرعة بالمرة الواحدة إن ذكرت",
              "frequency": "عدد مرات الاستخدام مثل مرتين يومياً",
              "timing": "توقيت الاستخدام مثل قبل الإفطار أو بعد الطعام أو الساعة 8 صباحاً",
              "durationDays": "مدة العلاج إن ذكرت",
              "stockCount": 0,
              "manufacturer": "الشركة المصنعة إن كانت ظاهرة",
              "additionalInfo": "أي معلومات إضافية مفيدة مكتوبة على العبوة",
              "instructions": "تعليمات الاستخدام الظاهرة",
              "doctorName": "اسم الطبيب المعالج إن ذكر في الروشتة",
              "doctorNotes": "ملاحظات الطبيب إن وجدت",
              "confidence": "🟢 مؤكد وواضح",
              "isConfirmedByAi": true,
              "confidenceDetails": "تفاصيل درجة وضوح وقراءة النص",
              "rawExtractedText": "النص الكامل المقروء من الصورة"
            }
        """.trimIndent()

        val inlineDataObj = JSONObject()
            .put("mimeType", "image/jpeg")
            .put("data", base64Image)

        val partsArray = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inlineData", inlineDataObj))

        val requestJsonObj = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", partsArray)))
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.1)
                    .put("maxOutputTokens", 2048)
                    .put("responseMimeType", "application/json")
            )

        val callResult = GeminiProjectRouter.generateContent(
            project = GeminiProject.MR7_MEDICAL,
            requestJson = requestJsonObj
        )

        if (callResult.success && callResult.text.isNotBlank()) {
            try {
                val startIdx = callResult.text.indexOf('{')
                val endIdx = callResult.text.lastIndexOf('}')
                if (startIdx != -1 && endIdx > startIdx) {
                    val jsonObj = JSONObject(callResult.text.substring(startIdx, endIdx + 1))
                    val name = jsonObj.optString("medicationName", "").trim()
                    val ingredient = jsonObj.optString("activeIngredient", "").trim()
                    val conc = jsonObj.optString("concentration", "").trim()
                    val form = jsonObj.optString("dosageForm", "قرص").trim().ifBlank { "قرص" }
                    val units = jsonObj.optString("dosageUnits", "").trim()
                    val freq = jsonObj.optString("frequency", "").trim()
                    val timing = jsonObj.optString("timing", "").trim()
                    val duration = jsonObj.optString("durationDays", "").trim()
                    val stock = jsonObj.optInt("stockCount", 0)
                    val manufacturer = jsonObj.optString("manufacturer", "").trim()
                    val additionalInfo = jsonObj.optString("additionalInfo", "").trim()
                    val inst = jsonObj.optString("instructions", "").trim()
                    val doctor = jsonObj.optString("doctorName", "").trim()
                    val notes = jsonObj.optString("doctorNotes", "").trim()
                    val rawConf = jsonObj.optString("confidence", "🟡 يحتاج مراجعة وتأكيد")
                    val isConfirmed = jsonObj.optBoolean("isConfirmedByAi", false) && name.isNotBlank()
                    val details = jsonObj.optString("confidenceDetails", "يرجى مراجعة الحقول المستخرجة وتأكيدها قبل الحفظ.")
                    val raw = jsonObj.optString("rawExtractedText", "")

                    return@withContext VisionScanResult(
                        medicationName = name,
                        activeIngredient = ingredient,
                        concentration = conc,
                        dosageForm = form,
                        dosageUnits = units,
                        frequency = freq,
                        timing = timing,
                        durationDays = duration,
                        stockCount = if (stock > 0) stock else 0,
                        instructions = inst,
                        manufacturer = manufacturer,
                        additionalInfo = additionalInfo,
                        doctorName = doctor,
                        doctorNotes = notes,
                        confidence = if (name.isBlank()) "🟡 يحتاج مراجعة وتأكيد" else rawConf,
                        isConfirmedByAi = isConfirmed,
                        confidenceDetails = if (name.isBlank()) "لم يتمكن النظام من قراءة اسم الدواء بوضوح، يرجى إدخاله يدوياً أو التقاط صورة أوضح." else details,
                        rawExtractedText = raw,
                        latencyMs = callResult.latencyMs
                    )
                }
            } catch (_: Exception) {
                // Fall through to honest parse error
            }
        }

        return@withContext VisionScanResult(
            medicationName = "",
            activeIngredient = "",
            concentration = "",
            dosageForm = "قرص",
            dosageUnits = "",
            frequency = "",
            timing = "",
            durationDays = "",
            stockCount = 0,
            instructions = "",
            confidence = "🔴 تعذر التحليل",
            isConfirmedByAi = false,
            confidenceDetails = callResult.errorMessage.ifBlank { "تعذر قراءة الصورة، يرجى التقاط صورة أوضح أو إدخال البيانات يدوياً." },
            rawExtractedText = "",
            latencyMs = callResult.latencyMs
        )
    }

    // --- MR7 ALLERGY INTELLIGENCE & DRUG COMPATIBILITY (Project: MR7 حساسية) ---
    suspend fun suggestAllergies(userInput: String): AllergySuggestionResponse = withContext(Dispatchers.IO) {
        val clean = userInput.trim()
        if (clean.length < 2) {
            return@withContext AllergySuggestionResponse(suggestions = emptyList())
        }

        val prompt = """
            أنت نظام 𝐌𝐑𝟕 حساسية الذكي لتحليل وفهم أسماء الحساسية بالعربية والإنجليزية.
            النص المدخل من المستخدم: "$clean"
            
            القواعد:
            1. افهم الأخطاء الإملائية والأسماء الناقصة أو المختصرة بالعربية والإنجليزية.
            2. ميّز بدقة بين: الحساسية التنفسية (مثل حساسية الجيوب الأنفية / Sinus Allergy)، والتهاب الجيوب الأنفية (Sinusitis)، والحساسية الدوائية (مثل حساسية البنسلين)، والحساسية الغذائية. لا تعتبرها شيئاً واحداً تلقائياً.
            3. لا تقدم تشخيصاً طبياً؛ قدم اقتراحات موحدة مع نسبة ثقة (0 إلى 100) وشرح مبسط لكل خيار.
            4. إذا كانت الثقة >= 90% لأحد الخيارات، اكتب سؤال تأكيد واضح في confirmationQuestionAr مثل: "هل تقصد حساسية الجيوب الأنفية؟".
            
            أعد JSON حصري:
            {
              "confirmationQuestionAr": "سؤال تأكيد إذا كانت الثقة >= 90% أو null",
              "suggestions": [
                {
                  "unifiedNameAr": "الاسم الموحد بالعربية",
                  "unifiedNameEn": "Unified English Name",
                  "categoryAr": "التصنيف (حساسية تنفسية / التهاب الجيوب الأنفية / حساسية دوائية / حساسية غذائية)",
                  "confidencePercent": 92,
                  "explanationAr": "شرح مبسط للحالة"
                }
              ]
            }
        """.trimIndent()

        val requestJson = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.2)
                    .put("maxOutputTokens", 1024)
                    .put("responseMimeType", "application/json")
            )

        val callResult = GeminiProjectRouter.generateContent(
            project = GeminiProject.MR7_ALLERGY,
            requestJson = requestJson,
            dedupeKey = "allergy_suggest_${clean.lowercase()}"
        )

        if (callResult.success && callResult.text.isNotBlank()) {
            try {
                val startIdx = callResult.text.indexOf('{')
                val endIdx = callResult.text.lastIndexOf('}')
                if (startIdx != -1 && endIdx > startIdx) {
                    val obj = JSONObject(callResult.text.substring(startIdx, endIdx + 1))
                    val confirmQ = obj.optString("confirmationQuestionAr", "").takeIf { it.isNotBlank() && it != "null" }
                    val arr = obj.optJSONArray("suggestions") ?: JSONArray()
                    val list = mutableListOf<AllergySuggestionItem>()
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        list.add(
                            AllergySuggestionItem(
                                unifiedNameAr = item.optString("unifiedNameAr", ""),
                                unifiedNameEn = item.optString("unifiedNameEn", ""),
                                categoryAr = item.optString("categoryAr", ""),
                                confidencePercent = item.optInt("confidencePercent", 0),
                                explanationAr = item.optString("explanationAr", "")
                            )
                        )
                    }
                    return@withContext AllergySuggestionResponse(
                        suggestions = list,
                        confirmationQuestionAr = confirmQ,
                        latencyMs = callResult.latencyMs
                    )
                }
            } catch (_: Exception) {
            }
        }

        return@withContext AllergySuggestionResponse(
            suggestions = emptyList(),
            errorMessage = callResult.errorMessage.ifBlank { "تعذر جلب اقتراحات الحساسية حالياً." },
            latencyMs = callResult.latencyMs
        )
    }

    suspend fun checkDrugAllergyCompatibility(
        medicationName: String,
        activeIngredient: String,
        registeredAllergies: List<String>
    ): AllergyCompatibilityResult = withContext(Dispatchers.IO) {
        val accessedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
            .format(java.util.Date())

        if (registeredAllergies.isEmpty()) {
            return@withContext AllergyCompatibilityResult(
                status = AllergyConflictStatus.SAFE_NO_KNOWN_CONFLICT,
                warningTitleAr = "لا توجد حساسيات مسجلة",
                matchedIngredient = "",
                reasonAr = "لم يتم تسجيل أي حساسية في ملفك الصحي للمقارنة.",
                verifiedActiveIngredients = listOfNotNull(activeIngredient.takeIf { it.isNotBlank() }),
                sources = emptyList(),
                accessedAt = accessedAt
            )
        }

        val prompt = """
            أنت نظام 𝐌𝐑𝟕 حساسية للتحقق من توافق الأدوية مع الحساسية المسجلة باستخدام البحث الطبي الموثوق.
            اسم الدواء: "$medicationName"
            المادة الفعالة المدخلة: "$activeIngredient"
            الحساسيات المسجلة للمستخدم: ${registeredAllergies.joinToString("، ")}
            
            المطلوب:
            1. ابحث عن التركيبة الدوائية والمواد الفعالة والمكونات ذات الصلة لهذا الدواء من مصادر طبية ورسمية موثوقة.
            2. قارن المواد الفعالة والمكونات بالحساسيات المسجلة.
            3. ممنوع تماماً اختراع تفاعلات دوائية أو مكونات غير مثبتة.
            4. إذا لم تتوفر معلومات كافية أو موثوقة، اجعل status = "INSUFFICIENT_DATA" ولا تعطِ نتيجة آمنة مؤكدة.
            5. إذا وجد تعارض معروف أو محتمل، اجعل status = "POTENTIAL_CONFLICT" واذكر المادة الفعالة المرتبطة بالتحذير وسبب التحذير واطلب مراجعة الطبيب أو الصيدلي.
            6. إذا لم يوجد تعارض معروف مع توفر بيانات موثوقة، اجعل status = "SAFE_NO_KNOWN_CONFLICT".
            
            أعد JSON حصري:
            {
              "status": "POTENTIAL_CONFLICT | SAFE_NO_KNOWN_CONFLICT | INSUFFICIENT_DATA",
              "warningTitleAr": "عنوان النتيجة",
              "matchedIngredient": "اسم المادة الفعالة المرتبطة بالتحذير إن وجدت",
              "reasonAr": "شرح واضح ومبسط لسبب النتيجة مع توجيه لمراجعة الطبيب أو الصيدلي",
              "verifiedActiveIngredients": ["المادة الفعالة 1"]
            }
        """.trimIndent()

        val requestJson = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.1)
                    .put("maxOutputTokens", 1024)
                    .put("responseMimeType", "application/json")
            )

        val callResult = GeminiProjectRouter.generateContent(
            project = GeminiProject.MR7_ALLERGY,
            requestJson = requestJson,
            useGoogleSearch = true,
            dedupeKey = "allergy_check_${medicationName.lowercase()}_${registeredAllergies.joinToString(",").hashCode()}"
        )

        if (callResult.success && callResult.text.isNotBlank()) {
            try {
                val startIdx = callResult.text.indexOf('{')
                val endIdx = callResult.text.lastIndexOf('}')
                if (startIdx != -1 && endIdx > startIdx) {
                    val obj = JSONObject(callResult.text.substring(startIdx, endIdx + 1))
                    val statusStr = obj.optString("status", "INSUFFICIENT_DATA")
                    val status = when (statusStr) {
                        "POTENTIAL_CONFLICT" -> AllergyConflictStatus.POTENTIAL_CONFLICT
                        "SAFE_NO_KNOWN_CONFLICT" -> AllergyConflictStatus.SAFE_NO_KNOWN_CONFLICT
                        else -> AllergyConflictStatus.INSUFFICIENT_DATA
                    }
                    val ingredientsArr = obj.optJSONArray("verifiedActiveIngredients") ?: JSONArray()
                    val ingredients = mutableListOf<String>()
                    for (i in 0 until ingredientsArr.length()) {
                        val s = ingredientsArr.optString(i, "").trim()
                        if (s.isNotBlank()) ingredients.add(s)
                    }
                    return@withContext AllergyCompatibilityResult(
                        status = status,
                        warningTitleAr = obj.optString("warningTitleAr", "نتيجة فحص الحساسية"),
                        matchedIngredient = obj.optString("matchedIngredient", ""),
                        reasonAr = obj.optString("reasonAr", "يرجى مراجعة الطبيب أو الصيدلي قبل استخدام الدواء."),
                        verifiedActiveIngredients = ingredients,
                        sources = callResult.groundingSources,
                        accessedAt = accessedAt,
                        latencyMs = callResult.latencyMs
                    )
                }
            } catch (_: Exception) {
            }
        }

        return@withContext AllergyCompatibilityResult(
            status = AllergyConflictStatus.INSUFFICIENT_DATA,
            warningTitleAr = "البيانات غير كافية للتحقق",
            matchedIngredient = "",
            reasonAr = callResult.errorMessage.ifBlank { "لم تتوفر معلومات كافية للتحقق من توافق الدواء مع الحساسية المسجلة. يرجى مراجعة الطبيب أو الصيدلي." },
            verifiedActiveIngredients = emptyList(),
            sources = callResult.groundingSources,
            accessedAt = accessedAt,
            latencyMs = callResult.latencyMs
        )
    }
}
