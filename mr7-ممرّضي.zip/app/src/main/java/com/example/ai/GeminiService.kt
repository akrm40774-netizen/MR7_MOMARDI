package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.data.local.MedicationEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class VisionScanResult(
    val medicationName: String,
    val activeIngredient: String,
    val concentration: String,
    val dosageForm: String,
    val dosageUnits: String,
    val frequency: String,
    val timing: String,
    val durationDays: String,
    val stockCount: Int,
    val instructions: String,
    val doctorName: String = "",
    val doctorNotes: String = "",
    val confidence: String,
    val isConfirmedByAi: Boolean,
    val confidenceDetails: String,
    val rawExtractedText: String
)

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val apiKey: String
        get() = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

    // --- MR7 INTELLIGENT VOICE CONVERSATION ---
    suspend fun processVoiceChat(
        userInput: String,
        medications: List<MedicationEntity>,
        conversationHistory: List<Pair<String, String>>,
        isSeniorMode: Boolean
    ): String = withContext(Dispatchers.IO) {
        val cleanInput = userInput.trim()
        if (cleanInput.isBlank()) {
            return@withContext "أهلاً بك! قولي تحب تعرف إيه عن أدويتك أو روتينك الصحي اليوم؟"
        }

        val medsContext = if (medications.isEmpty()) {
            "لا توجد أدوية مسجلة في جدول المستخدم حتى الآن."
        } else {
            medications.joinToString("\n") {
                "- ${it.userNickname} (الاسم العلمي: ${it.officialName}), التركيز: ${it.concentration}, الشكل: ${it.form}, المواعيد: ${it.timesOfDay}, التعليمات: ${it.instructions}, المتبقي في المخزون: ${it.stockCount} ${it.form}"
            }
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val systemPrompt = """
                    أنت ممرّضي (MR7 Voice) - المساعد الصحي والدوائي الذكي للمستخدم. تتحدث باللغة العربية البسيطة وباللهجة المصرية المهذبة والمريحة.
                    
                    سياق أدوية المستخدم المسجلة حالياً:
                    $medsContext
                    
                    قواعد الإجابة الإلزامية:
                    1. افهم السؤال جيداً وأجب بدقة وواقعية وفقاً لمضمون السؤال وسياق الأدوية المتاحة.
                    2. ممنوع تكرار نفس الرد الجاهز على أسئلة مختلفة.
                    3. صغ إجابتك في جملة أو جملتين مباشرتين جداً وواضحتين ومفيدة بدون حشو أو مقدمات مكررة.
                    4. تعامل مع أسئلة الأدوية بحذر ووعي، لا تقترح جرعات جديدة من عندك، وإذا سأل عن دواء غير مسجل أو معلومة غير مؤكدة، اطلب منه استشارة الطبيب المعالج أو الصيدلي فوراً.
                    5. ممنوع تماماً استخدام أي رموز ماركداون (مثل النجوم ** أو الشُرط أو علامات الترقيم الغريبة) لأن هذا النص يتم نطقه صوتياً مباشرة للمريض.
                """.trimIndent()

                val partsArray = JSONArray()

                // Add recent history for context
                conversationHistory.takeLast(4).forEach { (sender, text) ->
                    val role = if (sender == "USER") "المستخدم" else "ممرّضي"
                    partsArray.put(JSONObject().put("text", "$role: $text"))
                }
                partsArray.put(JSONObject().put("text", "المستخدم: $cleanInput"))

                val contentsArray = JSONArray().put(JSONObject().put("parts", partsArray))
                val sysInstructionObj = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))

                val genConfigObj = JSONObject()
                    .put("temperature", 0.3)
                    .put("maxOutputTokens", 150)

                val requestJsonObj = JSONObject()
                    .put("contents", contentsArray)
                    .put("systemInstruction", sysInstructionObj)
                    .put("generationConfig", genConfigObj)

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

                val httpRequest = Request.Builder()
                    .url(url)
                    .post(requestJsonObj.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(httpRequest).execute()
                val responseStr = response.body?.string() ?: ""

                if (response.isSuccessful && responseStr.isNotBlank()) {
                    val root = JSONObject(responseStr)
                    val candidates = root.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val cand = candidates.getJSONObject(0)
                        val content = cand.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val replyText = parts.getJSONObject(0).optString("text", "")
                            if (replyText.isNotBlank()) {
                                return@withContext cleanResponseForSpeech(replyText.trim())
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Network / Gemini fallback handled contextually below
            }
        }

        // Contextual intelligent offline fallback based on the actual question
        return@withContext generateContextualOfflineResponse(cleanInput, medications)
    }

    private fun cleanResponseForSpeech(text: String): String {
        return text
            .replace(Regex("[\\*#_`~>•-]"), "")
            .replace("mg", "مليجرام")
            .replace("ml", "مليلتر")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun generateContextualOfflineResponse(query: String, medications: List<MedicationEntity>): String {
        val q = query.lowercase().trim()

        // Check for specific medication inquiries
        for (med in medications) {
            val nick = med.userNickname.lowercase()
            val off = med.officialName.lowercase()
            if (q.contains(nick) || (off.isNotBlank() && q.contains(off))) {
                return "بالنسبة لـ ${med.userNickname}، معاده المسجل هو ${med.timesOfDay}، وتعليماته: ${med.instructions}، وباقي في العلبة ${med.stockCount} ${med.form}."
            }
        }

        return when {
            q.contains("ميعاد") || q.contains("موعد") || q.contains("امتى") || q.contains("ساعة") -> {
                if (medications.isNotEmpty()) {
                    val first = medications.first()
                    "أقرب دواء مسجل هو ${first.userNickname} في تمام ${first.timesOfDay}."
                } else {
                    "ما عندكش أدوية مسجلة حالياً لليوم، تحب نضيف دواء جديد في جدولك؟"
                }
            }
            q.contains("مخزون") || q.contains("ناقص") || q.contains("علبة") || q.contains("فاضل") -> {
                val lowMeds = medications.filter { it.stockCount <= it.refillThreshold }
                if (lowMeds.isNotEmpty()) {
                    "خلي بالك، الأدوية اللي قربت تخلص هي: ${lowMeds.joinToString(" و ") { it.userNickname }}."
                } else {
                    "كل أدويتك المسجلة مخزونها كافي ومطمئن ومفيش أي نواقص حالياً."
                }
            }
            q.contains("ازيك") || q.contains("سلام") || q.contains("صباح") || q.contains("مساء") -> {
                "أهلاً بحضرتك، يومك سعيد وصحتك دائماً بخير. أنا معاك لأي سؤال عن أدويتك أو روتينك."
            }
            q.contains("شكرا") || q.contains("تسلم") || q.contains("تمام") -> {
                "الشكر لله يا فندم، بالصحة والعافية دايماً وأنا في خدمتك في أي وقت."
            }
            else -> {
                if (medications.isNotEmpty()) {
                    "سؤالك واضح ومهم. بخصوص جدولك الصحي، عندك ${medications.size} أدوية مسجلة حالياً، تقدر تسألني عن مواعيد أي دواء منهم أو مخزونه."
                } else {
                    "أنا ممرّضي وسامعك بكل اهتمام. للحفاظ على سلامتك، استشر طبيبك أو الصيدلي عن أي تفاصيل طبية دقيقة."
                }
            }
        }
    }

    // --- MR7 REAL OCR & MULTIMODAL MEDICAL SCANNING ---
    suspend fun analyzePrescriptionOrPackage(
        bitmap: Bitmap,
        scanType: String
    ): VisionScanResult = withContext(Dispatchers.IO) {
        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val maxDim = 1200
                val scaledBitmap = if (bitmap.width > maxDim || bitmap.height > maxDim) {
                    val ratio = minOf(maxDim.toFloat() / bitmap.width, maxDim.toFloat() / bitmap.height)
                    Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
                } else {
                    bitmap
                }

                val stream = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                val base64Image = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

                val prompt = """
                    أنت خبير OCR وتحليل روشتات وعلب أدوية متقدم (MR7 Medical Vision).
                    نوع الصورة: ${if (scanType == "PRESCRIPTION") "روشتة طبية مكتوبة بخط اليد أو مطبوعة" else "علبة دواء أو شريط دواء مطبوع"}.
                    
                    قم بفحص الصورة بالكامل واستخراج كافة النصوص المقروءة بدقة وتصنيفها في حقول محددة وصارمة.
                    ممنوع الخلط بين الحقول (لا تضع الموعد في خانة الاسم، ولا تضع عدد المرات في خانة عدد الحبات).
                    
                    أعد النتيجة بتنسيق JSON حصري وبدون أي نصوص قبله أو بعده:
                    {
                      "medicationName": "اسم الدواء التجاري الواضح أو غير محدد",
                      "activeIngredient": "المادة الفعالة إن وجدت أو غير محدد",
                      "concentration": "التركيز مثل 500mg أو 1000mg",
                      "dosageForm": "قرص أو كبسولة أو شراب أو مرهم أو حقن",
                      "dosageUnits": "الجرعة بالمرة الواحدة مثل قرص واحد",
                      "frequency": "عدد المرات مثل مرتين يومياً أو كل 8 ساعات",
                      "timing": "موعد الاستخدام مثل بعد الأكل أو قبل النوم",
                      "durationDays": "مدة العلاج بالأيام إن ذكرت",
                      "stockCount": 30,
                      "instructions": "تعليمات الاستخدام وطريقة تناوله بدقة",
                      "doctorNotes": "ملاحظات الطبيب أو أي تحذيرات",
                      "confidence": "🟢 مؤكد وواضح",
                      "isConfirmedByAi": true,
                      "confidenceDetails": "تفاصيل درجة وضوح وقراءة النص في الصورة",
                      "rawExtractedText": "النص الكامل المقروء من الصورة"
                    }
                    إذا كانت الصورة غير واضحة أو مموهة أو الإضاءة سيئة، اجعل حقل confidence يحتوي على '🟡 يحتاج مراجعة وتأكيد' أو '🔴 غير واضح' مع توضيح السبب في confidenceDetails.
                """.trimIndent()

                val inlineDataObj = JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", base64Image)

                val partsArray = JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("inlineData", inlineDataObj))

                val genConfigObj = JSONObject()
                    .put("temperature", 0.1)
                    .put("maxOutputTokens", 500)
                    .put("responseMimeType", "application/json")

                val requestJsonObj = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", partsArray)))
                    .put("generationConfig", genConfigObj)

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

                val httpRequest = Request.Builder()
                    .url(url)
                    .post(requestJsonObj.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(httpRequest).execute()
                val responseStr = response.body?.string() ?: ""

                if (response.isSuccessful && responseStr.isNotBlank()) {
                    val root = JSONObject(responseStr)
                    val candidates = root.optJSONArray("candidates")
                    val text = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text", "") ?: ""

                    if (text.isNotBlank()) {
                        val cleanJson = text.substringAfter("{").substringBeforeLast("}")
                        if (cleanJson.isNotBlank()) {
                            val jsonObj = JSONObject("{$cleanJson}")
                            val name = jsonObj.optString("medicationName", "").trim()
                            val ingredient = jsonObj.optString("activeIngredient", "").trim()
                            val conc = jsonObj.optString("concentration", "").trim()
                            val form = jsonObj.optString("dosageForm", "قرص").trim()
                            val units = jsonObj.optString("dosageUnits", "قرص واحد").trim()
                            val freq = jsonObj.optString("frequency", "").trim()
                            val timing = jsonObj.optString("timing", "").trim()
                            val duration = jsonObj.optString("durationDays", "").trim()
                            val stock = jsonObj.optInt("stockCount", 30)
                            val inst = jsonObj.optString("instructions", "").trim()
                            val doctor = jsonObj.optString("doctorName", "").trim()
                            val notes = jsonObj.optString("doctorNotes", "").trim()
                            val conf = jsonObj.optString("confidence", "🟡 يحتاج مراجعة وتأكيد")
                            val isConfirmed = jsonObj.optBoolean("isConfirmedByAi", conf.contains("واضح") || conf.contains("مؤكد"))
                            val details = jsonObj.optString("confidenceDetails", "تم الاستخراج والتحليل عبر الذكاء الاصطناعي")
                            val raw = jsonObj.optString("rawExtractedText", "")

                            return@withContext VisionScanResult(
                                medicationName = if (name.isBlank() || name == "غير محدد") "دواء جديد" else name,
                                activeIngredient = ingredient,
                                concentration = if (conc.isBlank() || conc == "غير محدد") "حسب الوصفة" else conc,
                                dosageForm = form,
                                dosageUnits = units,
                                frequency = if (freq.isBlank() || freq == "غير محدد") "يومياً" else freq,
                                timing = if (timing.isBlank() || timing == "غير محدد") "بعد الأكل" else timing,
                                durationDays = duration,
                                stockCount = if (stock <= 0) 30 else stock,
                                instructions = if (inst.isBlank()) "تناول الجرعة المقررة بانتظام" else inst,
                                doctorName = doctor,
                                doctorNotes = notes,
                                confidence = conf,
                                isConfirmedByAi = isConfirmed,
                                confidenceDetails = details,
                                rawExtractedText = raw
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // Return honest unconfirmed scan result with error details
                return@withContext VisionScanResult(
                    medicationName = "",
                    activeIngredient = "",
                    concentration = "",
                    dosageForm = "قرص",
                    dosageUnits = "قرص واحد",
                    frequency = "",
                    timing = "بعد الأكل",
                    durationDays = "",
                    stockCount = 30,
                    instructions = "",
                    doctorNotes = "",
                    confidence = "🔴 تعذر الاتصال بالخادم",
                    isConfirmedByAi = false,
                    confidenceDetails = "يرجى التحقق من اتصال الإنترنت أو إدخال تفاصيل الدواء يدوياً.",
                    rawExtractedText = ""
                )
            }
        }

        // Honest result when API key is not configured
        VisionScanResult(
            medicationName = "",
            activeIngredient = "",
            concentration = "",
            dosageForm = "قرص",
            dosageUnits = "قرص واحد",
            frequency = "مرتين يومياً",
            timing = "بعد الأكل",
            durationDays = "7 أيام",
            stockCount = 30,
            instructions = "",
            doctorNotes = "",
            confidence = "🟡 يتطلب مراجعة المستخدم",
            isConfirmedByAi = false,
            confidenceDetails = "الصورة ملتقطة بنجاح. يرجى مراجعة وتأكيد بيانات الدواء في الحقول أدناه قبل الحفظ.",
            rawExtractedText = ""
        )
    }
}
