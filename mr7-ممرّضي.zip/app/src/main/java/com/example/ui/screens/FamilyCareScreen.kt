package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.FamilyMemberEntity
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel
import kotlin.random.Random

// ==========================================
// 🔐 MR7 SECURE LINKING TOKEN ENGINE
// ==========================================

data class LinkingTokenData(
    val userId: String,
    val userName: String,
    val email: String,
    val expiryTimestampMillis: Long,
    val tokenCode: String
)

sealed class LinkingTokenResult {
    data class Success(val data: LinkingTokenData) : LinkingTokenResult()
    object SelfLinkAttempt : LinkingTokenResult()
    object Expired : LinkingTokenResult()
    data class InvalidFormat(val message: String) : LinkingTokenResult()
}

object MR7LinkingTokenEngine {
    // Generate secure linking token valid for 15 minutes
    fun generateToken(userId: String, userName: String, email: String): String {
        val cleanUid = userId.ifBlank { "usr_777" }
        val cleanName = userName.ifBlank { "مستخدم MR7" }
        val expiry = System.currentTimeMillis() + (15 * 60 * 1000L) // 15 mins
        val rawPayload = "$cleanUid|$cleanName|$email|$expiry"
        val base64 = android.util.Base64.encodeToString(
            rawPayload.toByteArray(),
            android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE
        )
        val shortPrefix = cleanUid.takeLast(4).uppercase().ifBlank { "7777" }
        val randomDigits = (1000..9999).random()
        return "MR7-$shortPrefix-$randomDigits-$base64"
    }

    // Parse & Validate Linking Token
    fun parseAndValidateToken(
        inputToken: String,
        currentUserId: String,
        currentUserEmail: String
    ): LinkingTokenResult {
        val cleanToken = inputToken.trim()
        if (cleanToken.isBlank()) {
            return LinkingTokenResult.InvalidFormat("رمز الربط فارغ، يرجى إدخال الرمز بشكل صحيح.")
        }

        // Handle simple 6-digit legacy codes or custom tokens
        if (cleanToken.length == 6 && cleanToken.all { it.isDigit() }) {
            val myLocalCode = (currentUserId.hashCode().coerceAtLeast(100000) % 900000 + 100000).toString()
            if (cleanToken == myLocalCode) {
                return LinkingTokenResult.SelfLinkAttempt
            }
            return LinkingTokenResult.Success(
                LinkingTokenData(
                    userId = "usr_paired_$cleanToken",
                    userName = "حساب عائلي (#$cleanToken)",
                    email = "",
                    expiryTimestampMillis = System.currentTimeMillis() + (60 * 60 * 1000L),
                    tokenCode = cleanToken
                )
            )
        }

        if (!cleanToken.startsWith("MR7-")) {
            return LinkingTokenResult.InvalidFormat("صيغة الرمز غير مدعومة. تأكد أن الرمز يبدأ بـ MR7")
        }

        val parts = cleanToken.split("-")
        if (parts.size < 4) {
            return LinkingTokenResult.InvalidFormat("رمز غير مكتمل أو تالف.")
        }

        return try {
            val base64Payload = parts.last()
            val rawPayload = String(
                android.util.Base64.decode(base64Payload, android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
            )
            val subParts = rawPayload.split("|")
            if (subParts.size < 4) {
                return LinkingTokenResult.InvalidFormat("فشل تحليل بيانات الرمز.")
            }

            val targetUserId = subParts[0]
            val targetUserName = subParts[1]
            val targetEmail = subParts[2]
            val expiryMillis = subParts[3].toLongOrNull() ?: 0L

            // 🚫 CRITICAL SELF-LINK PREVENTION CHECK (Rules 7 & 8)
            val isSameUser = targetUserId == currentUserId ||
                    (currentUserEmail.isNotBlank() && targetEmail.equals(currentUserEmail, ignoreCase = true))

            if (isSameUser) {
                return LinkingTokenResult.SelfLinkAttempt
            }

            // 🔐 EXPIRATION CHECK (Rule 9)
            if (System.currentTimeMillis() > expiryMillis) {
                return LinkingTokenResult.Expired
            }

            LinkingTokenResult.Success(
                LinkingTokenData(
                    userId = targetUserId,
                    userName = targetUserName,
                    email = targetEmail,
                    expiryTimestampMillis = expiryMillis,
                    tokenCode = cleanToken
                )
            )
        } catch (e: Exception) {
            LinkingTokenResult.InvalidFormat("تعذر فك تشفير رمز الربط.")
        }
    }
}

// ==========================================
// 🎨 MAIN FAMILY CARE SCREEN
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyCareScreen(
    viewModel: MainViewModel
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    val familyMembers by viewModel.familyMembers.collectAsState()
    val prefs = viewModel.userPreferences

    val currentUserId = prefs.activeUserId ?: "usr_777"
    val currentUserName = prefs.userName
    val currentUserEmail = prefs.activeUserEmail

    // Modals & Dialog states
    var showCameraScanModal by remember { mutableStateOf(false) }
    var showMyCodeModal by remember { mutableStateOf(false) }
    var showSelfLinkForbiddenDialog by remember { mutableStateOf(false) }
    var showExpiredTokenDialog by remember { mutableStateOf(false) }
    var pendingConfirmationData by remember { mutableStateOf<LinkingTokenData?>(null) }
    var selectedMemberForPermissions by remember { mutableStateOf<FamilyMemberEntity?>(null) }
    var showConsentSheet by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // Top Header
        Surface(
            color = tokens.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "👥 MR7 Care — نظام الرعاية عن بُعد",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary,
                            fontSize = if (isSenior) 22.sp else 18.sp
                        )
                    )
                    Text(
                        text = "متابعة كبار السن والأطفال والمقربين بآمان وحماية",
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                    )
                }
            }
        }

        // Main Content List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Capacity Limits Display Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "🛡️ حدود نظام الرعاية الآمن:",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                            Text(
                                text = "يمكنك إضافة حتى 7 مراقبين موثوقين و 5 أفراد تحت الرعاية",
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.primary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "${familyMembers.size} / 5 أفراد",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = tokens.primary,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Consent Banner Link
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { showConsentSheet = true }
                        .border(1.dp, tokens.primary.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                    color = tokens.primary.copy(alpha = 0.05f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = tokens.primary)
                            Text(
                                text = "🔐 اتفاقية الخصوصية ومشاركة البيانات (موافقة صريحة)",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.primary
                                )
                            )
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = tokens.primary)
                    }
                }
            }

            // Section Header
            item {
                Text(
                    text = "👥 أفراد العائلة المتابَعين (Care Recipients)",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary,
                        fontSize = if (isSenior) 20.sp else 16.sp
                    )
                )
            }

            if (familyMembers.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = tokens.surfaceElevated)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.PeopleOutline,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = tokens.textSecondary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "لم تقم بربط أي أفراد عائلة حتى الآن.",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = tokens.textSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                            Text(
                                text = "استخدم أزرار الربط بالأسفل لمسح الرمز أو مشاركته.",
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary.copy(alpha = 0.8f))
                            )
                        }
                    }
                }
            } else {
                items(familyMembers) { member ->
                    FamilyMemberCard(
                        member = member,
                        onOpenPermissions = { selectedMemberForPermissions = member }
                    )
                }
            }
        }

        // ========================================================
        // 🎨 BOTTOM ACTION BUTTONS BAR (اليمين: مسح للربط | اليسار: إظهار رمز الربط)
        // ========================================================
        Surface(
            color = tokens.surface,
            tonalElevation = 8.dp,
            shadowElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 📷 Right side (اليمين - RTL) -> مسح للربط
                Button(
                    onClick = { showCameraScanModal = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                        .testTag("scan_qr_link_button"),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1976D2), // Modern Premium Blue
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "مسح للربط",
                            modifier = Modifier.size(24.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "مسح للربط",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = if (isSenior) 16.sp else 14.sp
                                )
                            )
                            Text(
                                text = "مسح كود الجهاز الآخر 📷",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }

                // ▦ Left side (اليسار - RTL) -> إظهار رمز الربط
                Button(
                    onClick = { showMyCodeModal = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                        .testTag("show_qr_link_button"),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1976D2), // Modern Premium Blue
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "إظهار رمز الربط",
                            modifier = Modifier.size(24.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "إظهار رمز الربط",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = if (isSenior) 16.sp else 14.sp
                                )
                            )
                            Text(
                                text = "كود الربط الخاص بي ▦",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    // ==========================================
    // MODALS & DIALOGS
    // ==========================================

    // 1. Camera Scanner Modal (📷 مسح للربط)
    if (showCameraScanModal) {
        CameraScanLinkModal(
            currentUserId = currentUserId,
            currentUserEmail = currentUserEmail,
            onDismiss = { showCameraScanModal = false },
            onCodeScanned = { code ->
                val result = MR7LinkingTokenEngine.parseAndValidateToken(code, currentUserId, currentUserEmail)
                when (result) {
                    is LinkingTokenResult.SelfLinkAttempt -> {
                        showSelfLinkForbiddenDialog = true
                    }
                    is LinkingTokenResult.Expired -> {
                        showExpiredTokenDialog = true
                    }
                    is LinkingTokenResult.InvalidFormat -> {
                        // Handled in modal
                    }
                    is LinkingTokenResult.Success -> {
                        pendingConfirmationData = result.data
                        showCameraScanModal = false
                    }
                }
            },
            onSelfLinkDetected = {
                showSelfLinkForbiddenDialog = true
            },
            onExpiredDetected = {
                showExpiredTokenDialog = true
            }
        )
    }

    // 2. Show Link Code Modal (▦ إظهار رمز الربط)
    if (showMyCodeModal) {
        ShowMyLinkCodeModal(
            userId = currentUserId,
            userName = currentUserName,
            email = currentUserEmail,
            onDismiss = { showMyCodeModal = false }
        )
    }

    // 3. Self-Link Forbidden Error Dialog (🚫 منع ربط الحساب بنفسه - Rule 7 & 8)
    if (showSelfLinkForbiddenDialog) {
        SelfLinkForbiddenDialog(
            onDismiss = { showSelfLinkForbiddenDialog = false }
        )
    }

    // 4. Token Expired Dialog (⚠️ انتهت صلاحية رمز الربط - Rule 9)
    if (showExpiredTokenDialog) {
        ExpiredTokenDialog(
            onDismiss = { showExpiredTokenDialog = false }
        )
    }

    // 5. Linking Confirmation Dialog (🔗 طلب ربط وتأكيد الخصوصية - Rule 10 & 11)
    if (pendingConfirmationData != null) {
        ConfirmLinkDialog(
            data = pendingConfirmationData!!,
            onDismiss = { pendingConfirmationData = null },
            onConfirmLink = { name, relation ->
                viewModel.addFamilyMember(
                    FamilyMemberEntity(
                        name = name,
                        relation = relation,
                        pairCode = pendingConfirmationData!!.tokenCode.take(12),
                        status = "REGULAR",
                        lastActive = "الآن"
                    )
                )
                pendingConfirmationData = null
            }
        )
    }

    // 6. Granular Permissions Modal
    if (selectedMemberForPermissions != null) {
        GranularPermissionsModal(
            member = selectedMemberForPermissions!!,
            onDismiss = { selectedMemberForPermissions = null },
            onSave = { updated ->
                viewModel.updateFamilyMember(updated)
                selectedMemberForPermissions = null
            }
        )
    }

    // 7. Privacy Agreement Sheet
    if (showConsentSheet) {
        PrivacyConsentSheet(onDismiss = { showConsentSheet = false })
    }
}

// ==========================================
// 📷 CAMERA SCANNER & MANUAL ENTRY MODAL
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScanLinkModal(
    currentUserId: String,
    currentUserEmail: String,
    onDismiss: () -> Unit,
    onCodeScanned: (String) -> Unit,
    onSelfLinkDetected: () -> Unit,
    onExpiredDetected: () -> Unit
) {
    var isManualEntry by remember { mutableStateOf(false) }
    var manualCodeInput by remember { mutableStateOf("") }
    var inputErrorMessage by remember { mutableStateOf<String?>(null) }

    // Scanner animation
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_line")
    val scannerYOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "y_offset"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0F172A) // Dark high contrast camera background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Bar with Back Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                            .testTag("scan_back_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "العودة",
                            tint = Color.White
                        )
                    }

                    Text(
                        text = "📷 مسح رمز الربط (MR7 Care)",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    )

                    Spacer(modifier = Modifier.width(48.dp))
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (!isManualEntry) {
                    // CAMERA VIEWFINDER SCANNING MODE
                    Text(
                        text = "وجّه الكاميرا نحو رمز الربط على الجهاز الآخر",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.9f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Scanner Box Frame
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color.Black.copy(alpha = 0.6f))
                            .border(2.dp, Color(0xFF1976D2), RoundedCornerShape(24.dp)),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        // Corner brackets & grid visual
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 5.dp.toPx()
                            val cornerLength = 30.dp.toPx()
                            val color = Color(0xFF2196F3)

                            // Top-Left
                            drawLine(color, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(cornerLength, 0f), strokeWidth)
                            drawLine(color, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(0f, cornerLength), strokeWidth)

                            // Top-Right
                            drawLine(color, androidx.compose.ui.geometry.Offset(size.width, 0f), androidx.compose.ui.geometry.Offset(size.width - cornerLength, 0f), strokeWidth)
                            drawLine(color, androidx.compose.ui.geometry.Offset(size.width, 0f), androidx.compose.ui.geometry.Offset(size.width, cornerLength), strokeWidth)

                            // Bottom-Left
                            drawLine(color, androidx.compose.ui.geometry.Offset(0f, size.height), androidx.compose.ui.geometry.Offset(cornerLength, size.height), strokeWidth)
                            drawLine(color, androidx.compose.ui.geometry.Offset(0f, size.height), androidx.compose.ui.geometry.Offset(0f, size.height - cornerLength), strokeWidth)

                            // Bottom-Right
                            drawLine(color, androidx.compose.ui.geometry.Offset(size.width, size.height), androidx.compose.ui.geometry.Offset(size.width - cornerLength, size.height), strokeWidth)
                            drawLine(color, androidx.compose.ui.geometry.Offset(size.width, size.height), androidx.compose.ui.geometry.Offset(size.width, size.height - cornerLength), strokeWidth)
                        }

                        // Laser Scanner Line
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .offset(y = scannerYOffset.dp)
                                .background(Color(0xFF00E676))
                        )

                        Text(
                            text = "جاري البحث عن الرمز...",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // Switch to Manual Entry Button
                    OutlinedButton(
                        onClick = { isManualEntry = true },
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(52.dp)
                            .testTag("manual_code_entry_toggle"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2196F3))
                    ) {
                        Icon(Icons.Default.Keyboard, contentDescription = null, tint = Color(0xFF2196F3))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("🔢 إدخال الكود يدويًا", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Simulated Fast Scan Demo Action
                    TextButton(
                        onClick = {
                            // Demo simulation of target user QR code
                            val sampleToken = MR7LinkingTokenEngine.generateToken("usr_target_999", "أحمد علي", "ahmed@example.com")
                            onCodeScanned(sampleToken)
                        }
                    ) {
                        Text("⚡ تجربة مسح رمز جهاز قريب (تجريبي)", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    }

                    // Simulated Self-Link Demo Scan Action
                    TextButton(
                        onClick = {
                            val selfToken = MR7LinkingTokenEngine.generateToken(currentUserId, currentUserEmail, currentUserEmail)
                            onCodeScanned(selfToken)
                        }
                    ) {
                        Text("⚠️ تجربة مسح رمز حسابي الحالي (اختبار المنع)", color = Color(0xFFFF8A80), fontSize = 12.sp)
                    }
                } else {
                    // MANUAL CODE ENTRY MODE (Requirement 2)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "🔢 إدخال رمز الربط يدويًا",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 18.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "أدخل رمز الربط المكون من أحرف وأرقام الظاهر على جهاز الشخص الآخر:",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.7f),
                                    textAlign = TextAlign.Center
                                )
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            OutlinedTextField(
                                value = manualCodeInput,
                                onValueChange = {
                                    manualCodeInput = it
                                    inputErrorMessage = null
                                },
                                label = { Text("أدخل رمز الربط") },
                                placeholder = { Text("MR7-XXXX-XXXX") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("manual_link_code_input"),
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF2196F3),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                    focusedLabelColor = Color(0xFF2196F3),
                                    unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            if (inputErrorMessage != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = inputErrorMessage!!,
                                    color = Color(0xFFFF5252),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { isManualEntry = false },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                                ) {
                                    Text("📷 المسح")
                                }

                                Button(
                                    onClick = {
                                        val res = MR7LinkingTokenEngine.parseAndValidateToken(manualCodeInput, currentUserId, currentUserEmail)
                                        when (res) {
                                            is LinkingTokenResult.SelfLinkAttempt -> {
                                                onSelfLinkDetected()
                                            }
                                            is LinkingTokenResult.Expired -> {
                                                onExpiredDetected()
                                            }
                                            is LinkingTokenResult.InvalidFormat -> {
                                                inputErrorMessage = res.message
                                            }
                                            is LinkingTokenResult.Success -> {
                                                onCodeScanned(manualCodeInput)
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .testTag("submit_manual_code_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                                ) {
                                    Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("🔗 ربط", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// ▦ SHOW MY LINK CODE MODAL (Requirement 3 & 6)
// ==========================================

@Composable
fun ShowMyLinkCodeModal(
    userId: String,
    userName: String,
    email: String,
    onDismiss: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var isCopied by remember { mutableStateOf(false) }

    // Generate unique temporary secure token
    var myToken by remember {
        mutableStateOf(MR7LinkingTokenEngine.generateToken(userId, userName, email))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🔗 رمز الربط الخاص بي", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFE3F2FD),
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Text(
                        text = "🔗 جاهز للربط",
                        color = Color(0xFF1976D2),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                // QR/Barcode Graphic
                QRBarcodeVisual(
                    codeText = myToken,
                    modifier = Modifier.fillMaxWidth(0.9f)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "رمز الربط",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Selectable / Copyable Text Code
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            clipboardManager.setText(AnnotatedString(myToken))
                            isCopied = true
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = myToken.take(20) + "...",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 14.sp
                            )
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                                contentDescription = "نسخ",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                if (isCopied) "تم النسخ!" else "نسخ",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "⏱️ رمز آمن ومؤقت (صالح لمدة 15 دقيقة)",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("تم")
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    myToken = MR7LinkingTokenEngine.generateToken(userId, userName, email)
                    isCopied = false
                }
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تحديث الرمز")
            }
        }
    )
}

// ==========================================
// 🎨 QR & BARCODE VISUAL COMPONENT
// ==========================================

@Composable
fun QRBarcodeVisual(
    codeText: String,
    modifier: Modifier = Modifier
) {
    val primaryColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(18.dp))
            .border(2.dp, primaryColor.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(
                modifier = Modifier
                    .size(170.dp)
                    .testTag("qr_code_canvas")
            ) {
                val sizePx = size.width
                val gridSize = 15
                val cellSize = sizePx / gridSize
                val seed = codeText.hashCode()
                val random = Random(seed.toLong())

                // Background
                drawRect(color = Color.White)

                // 3 Finder patterns
                val finders = listOf(0 to 0, (gridSize - 5) to 0, 0 to (gridSize - 5))
                for (pos in finders) {
                    val startX = pos.first * cellSize
                    val startY = pos.second * cellSize
                    val boxSize = 5 * cellSize

                    drawRect(
                        color = Color.Black,
                        topLeft = androidx.compose.ui.geometry.Offset(startX, startY),
                        size = androidx.compose.ui.geometry.Size(boxSize, boxSize)
                    )
                    drawRect(
                        color = Color.White,
                        topLeft = androidx.compose.ui.geometry.Offset(startX + cellSize, startY + cellSize),
                        size = androidx.compose.ui.geometry.Size(boxSize - 2 * cellSize, boxSize - 2 * cellSize)
                    )
                    drawRect(
                        color = Color.Black,
                        topLeft = androidx.compose.ui.geometry.Offset(startX + 1.5f * cellSize, startY + 1.5f * cellSize),
                        size = androidx.compose.ui.geometry.Size(2f * cellSize, 2f * cellSize)
                    )
                }

                // QR dots
                for (r in 0 until gridSize) {
                    for (c in 0 until gridSize) {
                        if ((r < 5 && c < 5) || (r < 5 && c >= gridSize - 5) || (r >= gridSize - 5 && c < 5)) continue

                        if (random.nextBoolean()) {
                            drawRect(
                                color = if (random.nextBoolean()) Color.Black else primaryColor,
                                topLeft = androidx.compose.ui.geometry.Offset(c * cellSize + 1f, r * cellSize + 1f),
                                size = androidx.compose.ui.geometry.Size(cellSize - 2f, cellSize - 2f)
                            )
                        }
                    }
                }

                // Center MR7 badge
                val badgeSize = 3.5f * cellSize
                val badgeOffset = (sizePx - badgeSize) / 2f
                drawRoundRect(
                    color = primaryColor,
                    topLeft = androidx.compose.ui.geometry.Offset(badgeOffset, badgeOffset),
                    size = androidx.compose.ui.geometry.Size(badgeSize, badgeSize),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Barcode strips below QR code
            Canvas(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(28.dp)
            ) {
                val widthPx = size.width
                val heightPx = size.height
                var x = 0f
                val rand = Random((codeText.hashCode() + 42).toLong())
                while (x < widthPx) {
                    val barWidth = (2..6).random(rand).toFloat()
                    val isGap = rand.nextBoolean()
                    if (!isGap && x + barWidth <= widthPx) {
                        drawRect(
                            color = Color.Black,
                            topLeft = androidx.compose.ui.geometry.Offset(x, 0f),
                            size = androidx.compose.ui.geometry.Size(barWidth, heightPx)
                        )
                    }
                    x += barWidth + (1..3).random(rand).toFloat()
                }
            }
        }
    }
}

// ==========================================
// 🚫 SELF-LINK FORBIDDEN DIALOG (Requirement 7 & 8 - CRITICAL)
// ==========================================

@Composable
fun SelfLinkForbiddenDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Text("🚫", fontSize = 40.sp)
        },
        title = {
            Text(
                text = "🚫 لا يمكن ربط الحساب بنفسه",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
            )
        },
        text = {
            Text(
                text = "يبدو أنك تحاول ربط حسابك بنفس الحساب.\nلا يمكنك إضافة نفسك كولي أمر أو كشخص تتم رعايته.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
            )
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dismiss_self_link_error_button")
            ) {
                Text("حسنًا", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    )
}

// ==========================================
// ⚠️ EXPIRED TOKEN DIALOG (Requirement 9)
// ==========================================

@Composable
fun ExpiredTokenDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Text("⚠️", fontSize = 36.sp)
        },
        title = {
            Text(
                text = "انتهت صلاحية الرمز",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "⚠️ انتهت صلاحية رمز الربط، يرجى إنشاء رمز جديد.",
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("موافق")
            }
        }
    )
}

// ==========================================
// 🔗 LINKING CONFIRMATION MODAL (Requirement 10 & 11)
// ==========================================

@Composable
fun ConfirmLinkDialog(
    data: LinkingTokenData,
    onDismiss: () -> Unit,
    onConfirmLink: (name: String, relation: String) -> Unit
) {
    var selectedRelation by remember { mutableStateOf("أبي") }
    var customName by remember { mutableStateOf(data.userName) }

    val relationsList = listOf(
        "أبي", "أمي", "ابني / ابنتي", "مريض تحت الرعاية", "ولي أمر / مراقب", "قريب"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "🔗 طلب ربط",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Target Account Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "الحساب المطلوب ربطه:",
                            style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.primary)
                        )
                        Text(
                            text = customName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        if (data.email.isNotBlank()) {
                            Text(
                                text = data.email,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }
                }

                // Relation Selector
                Text(
                    text = "نوع العلاقة / صلة القرابة:",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    relationsList.take(3).forEach { rel ->
                        FilterChip(
                            selected = (selectedRelation == rel),
                            onClick = { selectedRelation = rel },
                            label = { Text(rel, fontSize = 12.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    relationsList.drop(3).forEach { rel ->
                        FilterChip(
                            selected = (selectedRelation == rel),
                            onClick = { selectedRelation = rel },
                            label = { Text(rel, fontSize = 12.sp) }
                        )
                    }
                }

                // Privacy Warning Note (Requirement 11)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text("🛡️", fontSize = 18.sp, modifier = Modifier.padding(end = 8.dp))
                        Text(
                            text = "«بإتمام الربط، سيتم مشاركة معلومات الرعاية التي يسمح بها نظام 𝐌𝑅𝟕 ممرّضي مع الشخص المرتبط بك.»",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmLink(customName, selectedRelation) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_link_button")
            ) {
                Text("✅ تأكيد الربط", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("❌ إلغاء")
            }
        }
    )
}

// ==========================================
// EXISTING SUPPORTING COMPONENTS
// ==========================================

@Composable
fun FamilyMemberCard(
    member: FamilyMemberEntity,
    onOpenPermissions: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    val statusText = when (member.status) {
        "REGULAR" -> "🟢 اليوم منتظم - جميع الجرعات مؤكدة"
        "WARNING" -> "🟡 توجد جرعة غير مؤكدة"
        else -> "🔴 غير متصل"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .border(1.dp, tokens.cardBorder, RoundedCornerShape(24.dp))
            .testTag("family_member_card_${member.id}"),
        colors = CardDefaults.cardColors(containerColor = tokens.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = tokens.primary.copy(alpha = 0.15f),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(if (member.relation.contains("أبي") || member.relation.contains("أمي")) "👴" else "👦", fontSize = 24.sp)
                        }
                    }

                    Column {
                        Text(
                            text = member.name,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        Text(
                            text = "صلة القرابة: ${member.relation} | رمز الربط: ${member.pairCode}",
                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                        )
                    }
                }

                IconButton(onClick = onOpenPermissions) {
                    Icon(Icons.Default.Tune, contentDescription = "الصلاحيات", tint = tokens.primary)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = when (member.status) {
                    "REGULAR" -> tokens.success.copy(alpha = 0.12f)
                    "WARNING" -> tokens.warning.copy(alpha = 0.12f)
                    else -> tokens.error.copy(alpha = 0.12f)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = when (member.status) {
                                "REGULAR" -> tokens.success
                                "WARNING" -> tokens.warning
                                else -> tokens.error
                            }
                        )
                    )

                    Text(
                        text = "آخر نشاط: ${member.lastActive}",
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { /* Nudge action simulation */ },
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("🔔 إرسال تذكير وِدّي")
                }

                OutlinedButton(
                    onClick = onOpenPermissions,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("تعديل الصلاحيات")
                }
            }
        }
    }
}

@Composable
fun GranularPermissionsModal(
    member: FamilyMemberEntity,
    onDismiss: () -> Unit,
    onSave: (FamilyMemberEntity) -> Unit
) {
    var allowMeds by remember { mutableStateOf(member.allowMeds) }
    var allowAppointments by remember { mutableStateOf(member.allowAppointments) }
    var allowHistory by remember { mutableStateOf(member.allowHistory) }
    var allowAllergies by remember { mutableStateOf(member.allowAllergies) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🎛️ إدارة صلاحيات ${member.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("حدد البيانات المصرح لهذا المراقب بالاطلاع عليها:")

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = allowMeds, onCheckedChange = { allowMeds = it })
                    Text("عرض جدول الأدوية والمخزون")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = allowAppointments, onCheckedChange = { allowAppointments = it })
                    Text("عرض مواعيد الأطباء")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = allowHistory, onCheckedChange = { allowHistory = it })
                    Text("عرض سجل تأكيد الجرعات")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = allowAllergies, onCheckedChange = { allowAllergies = it })
                    Text("عرض ملف الحساسيات الطبية")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    member.copy(
                        allowMeds = allowMeds,
                        allowAppointments = allowAppointments,
                        allowHistory = allowHistory,
                        allowAllergies = allowAllergies
                    )
                )
            }) {
                Text("حفظ الصلاحيات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun PrivacyConsentSheet(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🔐 اتفاقية مشاركة البيانات والخصوصية") },
        text = {
            Text(
                "في MR7 Care، جميع بياناتك الصحية وأدويتك مشفرة ومحفوظة على جهازك المحلي. لا يتم مشاركة أي معلومات مع أي مراقب أو فرد من عائلتك إلا بموافقتك الصريحة وتحديدك المستقل للصلاحيات.",
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("فهمت وموافق") }
        }
    )
}
