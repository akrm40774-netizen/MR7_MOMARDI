package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val LocalThemeTokens = staticCompositionLocalOf {
    getThemeTokens(AppThemeMode.MEDICAL_BLUE)
}

val LocalSeniorMode = staticCompositionLocalOf { false }

fun getScaledTypography(isSeniorMode: Boolean): Typography {
    val scale = if (isSeniorMode) 1.25f else 1.0f
    return Typography(
        displayLarge = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Bold,
            fontSize = (32 * scale).sp
        ),
        headlineLarge = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Bold,
            fontSize = (26 * scale).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.SemiBold,
            fontSize = (22 * scale).sp
        ),
        titleLarge = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Bold,
            fontSize = (20 * scale).sp
        ),
        titleMedium = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Medium,
            fontSize = (18 * scale).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Normal,
            fontSize = (16 * scale).sp,
            lineHeight = (24 * scale).sp
        ),
        bodyMedium = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Normal,
            fontSize = (14 * scale).sp,
            lineHeight = (20 * scale).sp
        ),
        labelLarge = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.SemiBold,
            fontSize = (14 * scale).sp
        ),
        labelMedium = TextStyle(
            fontFamily = FontFamily.Default,
            fontWeight = FontWeight.Medium,
            fontSize = (12 * scale).sp
        )
    )
}

@Composable
fun Mr7Theme(
    themeMode: AppThemeMode = AppThemeMode.MEDICAL_BLUE,
    isSeniorMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val tokens = getThemeTokens(themeMode)
    val typography = getScaledTypography(isSeniorMode)

    val colorScheme = if (tokens.isDark) {
        darkColorScheme(
            primary = tokens.primary,
            onPrimary = tokens.onPrimary,
            secondary = tokens.secondary,
            onSecondary = tokens.onSecondary,
            background = tokens.background,
            surface = tokens.surface,
            onBackground = tokens.textPrimary,
            onSurface = tokens.textPrimary,
            error = tokens.error
        )
    } else {
        lightColorScheme(
            primary = tokens.primary,
            onPrimary = tokens.onPrimary,
            secondary = tokens.secondary,
            onSecondary = tokens.onSecondary,
            background = tokens.background,
            surface = tokens.surface,
            onBackground = tokens.textPrimary,
            onSurface = tokens.textPrimary,
            error = tokens.error
        )
    }

    CompositionLocalProvider(
        LocalThemeTokens provides tokens,
        LocalSeniorMode provides isSeniorMode
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            content = content
        )
    }
}
