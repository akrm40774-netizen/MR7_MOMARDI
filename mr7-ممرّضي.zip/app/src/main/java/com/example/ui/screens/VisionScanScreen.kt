package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.VisionScanResult
import com.example.data.local.MedicationEntity
import com.example.ui.components.AppPermissionType
import com.example.ui.components.ContextualPermissionRequester
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@Composable
fun VisionScanScreen(
    viewModel: MainViewModel,
    onMedicationAdded: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current
    val context = LocalContext.current

    var selectedMode by remember { mutableStateOf("PRESCRIPTION") } // "PRESCRIPTION" or "PACKAGE"
    val isAnalyzing by viewModel.isVisionAnalyzing.collectAsState()
    val scanResult by viewModel.visionScanResult.collectAsState()

    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var cameraErrorMessage by remember { mutableStateOf<String?>(null) }

    var customName by remember { mutableStateOf("") }
    var customNickname by remember { mutableStateOf("") }
    var customConc by remember { mutableStateOf("") }
    var customInst by remember { mutableStateOf("") }
    var customFreq by remember { mutableStateOf("") }
    var customActiveIngredient by remember { mutableStateOf("") }
    var customDosageUnits by remember { mutableStateOf("أقراص") }
    var customTiming by remember { mutableStateOf("") }
    var customDurationDays by remember { mutableStateOf("7") }
    var customStockCount by remember { mutableStateOf("30") }
    var customDoctorNotes by remember { mutableStateOf("") }

    var showCameraPermissionDialog by remember { mutableStateOf(false) }

    // Gallery Photo Picker (Zero runtime permissions required)
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                val stream = context.contentResolver.openInputStream(uri)
                val bitmap = android.graphics.BitmapFactory.decodeStream(stream)
                stream?.close()
                if (bitmap != null) {
                    capturedBitmap = bitmap
                    cameraErrorMessage = null
                    viewModel.clearVisionResult()
                } else {
                    cameraErrorMessage = "تعذر قراءة الصورة من المعرض."
                }
            } catch (e: Exception) {
                cameraErrorMessage = "حدث خطأ أثناء تحميل الصورة: ${e.message}"
            }
        }
    }

    // Real Camera Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            capturedBitmap = bitmap
            cameraErrorMessage = null
            viewModel.clearVisionResult()
        } else {
            cameraErrorMessage = "لم يتم التقاط الصورة. يمكنك المحاولة مرة أخرى."
        }
    }

    // Permission Launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraErrorMessage = null
            cameraLauncher.launch(null)
        } else {
            cameraErrorMessage = "تم رفض صلاحية الكاميرا. يحتاج التطبيق للصلاحية لتصوير الروشتة."
            showCameraPermissionDialog = true
        }
    }

    val launchCameraWithPermission = {
        val hasCamPermission = AppPermissionType.isPermissionGranted(context, android.Manifest.permission.CAMERA)
        if (hasCamPermission) {
            cameraErrorMessage = null
            cameraLauncher.launch(null)
        } else {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    if (showCameraPermissionDialog) {
        ContextualPermissionRequester(
            permissionType = AppPermissionType.CAMERA,
            showRationale = true,
            onDismiss = { showCameraPermissionDialog = false },
            onPermissionGranted = {
                showCameraPermissionDialog = false
                cameraLauncher.launch(null)
            }
        )
    }

    // Synchronize scanned result when it arrives
    LaunchedEffect(scanResult) {
        if (scanResult != null) {
            val res = scanResult!!
            customName = res.medicationName
            customNickname = res.medicationName
            customConc = res.concentration
            customInst = res.instructions
            customFreq = res.frequency
            customActiveIngredient = res.activeIngredient
            customDosageUnits = res.dosageUnits.ifBlank { "أقراص" }
            customTiming = res.timing
            customDurationDays = res.durationDays.ifBlank { "7" }
            customStockCount = res.stockCount.toString()
            customDoctorNotes = res.doctorNotes
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // Screen Header
        Surface(
            color = tokens.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "📷 MR7 Vision — قراءة الصور الطبية",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    )
                )
                Text(
                    text = "التعرف الآلي الذكي على خط الروشتات وعبوات الأدوية",
                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(tokens.surfaceElevated)
                        .padding(4.dp)
                ) {
                    val isPrescription = selectedMode == "PRESCRIPTION"
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedMode = "PRESCRIPTION" },
                        color = if (isPrescription) tokens.primary else Color.Transparent
                    ) {
                        Text(
                            text = "📷 قراءة روشتة",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = if (isPrescription) Color.White else tokens.textPrimary,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier
                                .padding(vertical = 10.dp)
                                .fillMaxWidth(),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedMode = "PACKAGE" },
                        color = if (!isPrescription) tokens.primary else Color.Transparent
                    ) {
                        Text(
                            text = "📦 تصوير علبة دواء",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = if (!isPrescription) Color.White else tokens.textPrimary,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier
                                .padding(vertical = 10.dp)
                                .fillMaxWidth(),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Camera Failure / Permission Error Warning Banner
            if (cameraErrorMessage != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = tokens.error.copy(alpha = 0.12f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.error.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = tokens.error)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تنبيه الكاميرا",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.error
                                    )
                                )
                                Text(
                                    text = cameraErrorMessage!!,
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textPrimary)
                                )
                            }
                            Button(
                                onClick = launchCameraWithPermission,
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.error),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("محاولة مجدداً", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Photo Capture Launcher Card / Captured Photo Preview
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (capturedBitmap == null) {
                            // Initial State: Launch Camera
                            Surface(
                                shape = CircleShape,
                                color = tokens.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(72.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (selectedMode == "PRESCRIPTION") Icons.Default.Description else Icons.Default.MedicalServices,
                                        contentDescription = null,
                                        tint = tokens.primary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = if (selectedMode == "PRESCRIPTION") "التقط صورة لروشتة الطبيب" else "التقط صورة لعلبة الدواء",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )

                            Text(
                                text = "MR7 Vision سيقوم بقراءة النص، استخراج اسم الدواء، التركيز، وتحديد الجرعة",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = tokens.textSecondary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                ),
                                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = launchCameraWithPermission,
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(if (isSenior) 54.dp else 48.dp)
                                        .testTag("scan_camera_button"),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                                ) {
                                    Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("📸 فتح الكاميرا", fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        galleryLauncher.launch(
                                            androidx.activity.result.PickVisualMediaRequest(
                                                ActivityResultContracts.PickVisualMedia.ImageOnly
                                            )
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(if (isSenior) 54.dp else 48.dp)
                                        .testTag("scan_gallery_button"),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("🖼️ المعرض", fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            // Captured Image Review State
                            Text(
                                text = "📸 الصورة المحددة للمراجعة",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                ),
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(220.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(1.5.dp, tokens.primary, RoundedCornerShape(16.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    bitmap = capturedBitmap!!.asImageBitmap(),
                                    contentDescription = "الروشتة الملتقطة",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = launchCameraWithPermission,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(if (isSenior) 52.dp else 46.dp),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إعادة تصوير 📸", fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        viewModel.analyzeImageWithVision(capturedBitmap!!, selectedMode)
                                    },
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(if (isSenior) 52.dp else 46.dp)
                                        .testTag("analyze_captured_image_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("بدء التحليل 🧠", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Analysis Loading Progress
            if (isAnalyzing) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = tokens.surfaceElevated)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircularProgressIndicator(
                                color = tokens.primary,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(28.dp)
                            )
                            Column {
                                Text(
                                    text = "🧠 MR7 Vision يحلل الصورة الآن...",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.primary
                                    )
                                )
                                Text(
                                    text = "استخراج اسم الدواء، المادة الفعالة، والجرعات بدقة...",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }
                    }
                }
            }

            // Results Review Card
            if (scanResult != null && !isAnalyzing) {
                item {
                    val result = scanResult!!
                    val isUnconfirmed = !result.isConfirmedByAi || result.confidence.contains("غير مؤكد") || result.confidence.contains("مراجعة")

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .border(1.5.dp, tokens.primary.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                            .testTag("vision_results_card"),
                        colors = CardDefaults.cardColors(containerColor = tokens.surface),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🔎 نتيجة القراءة والمراجعة",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isUnconfirmed) tokens.warning.copy(alpha = 0.15f) else tokens.success.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = result.confidence,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (isUnconfirmed) tokens.warning else tokens.success
                                        ),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }

                            if (isUnconfirmed) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = tokens.warning.copy(alpha = 0.12f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.HelpOutline, contentDescription = null, tint = tokens.warning, modifier = Modifier.size(18.dp))
                                        Text(
                                            text = "⚠️ يحتوي الاستخراج على بيانات غير مؤكدة قطعيًا. يرجى مراجعتها بدقة والتعديل قبل الحفظ.",
                                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.warning, fontWeight = FontWeight.SemiBold)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 1. Medicine Name & Active Ingredient
                            OutlinedTextField(
                                value = customNickname,
                                onValueChange = { customNickname = it },
                                label = { Text("💊 اسم الدواء التجاري") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = customActiveIngredient,
                                onValueChange = { customActiveIngredient = it },
                                label = { Text("🧪 المادة الفعالة (Active Ingredient)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // 2. Concentration & Dosage Form
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = customConc,
                                    onValueChange = { customConc = it },
                                    label = { Text("🏷️ التركيز (مثل: 500mg)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = customDosageUnits,
                                    onValueChange = { customDosageUnits = it },
                                    label = { Text("💊 شكل الجرعة (أقراص/كبسول)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // 3. Frequency & Timing
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = customFreq,
                                    onValueChange = { customFreq = it },
                                    label = { Text("🕐 المواعيد (مثال: مرتين يومياً)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = customTiming,
                                    onValueChange = { customTiming = it },
                                    label = { Text("🍽️ التوقيت (قبل/بعد الأكل)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // 4. Duration & Stock Count
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = customDurationDays,
                                    onValueChange = { customDurationDays = it },
                                    label = { Text("📅 مدة العلاج (بالأيام)") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = customStockCount,
                                    onValueChange = { customStockCount = it },
                                    label = { Text("📦 عدد العبوة / المخزون") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = customInst,
                                onValueChange = { customInst = it },
                                label = { Text("📋 تعليمات الاستخدام والجرعة") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            if (result.doctorName.isNotBlank() && result.doctorName != "غير محدد") {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "👨‍⚕️ اسم الطبيب: ${result.doctorName}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = tokens.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }

                            if (customDoctorNotes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "📝 ملاحظات إضافية: $customDoctorNotes",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Mandatory AI Safety Disclaimer
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = tokens.surfaceElevated,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = tokens.warning,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "تنبيه طبي: الذكاء الاصطناعي أداة مساعدة لقراءة الخط والعبوات. تأكد من مطابقة المعلومات مع العبوة أو استشر الطبيب/الصيدلي قبل الحفظ.",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = tokens.textSecondary,
                                            lineHeight = 16.sp
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val combinedNotes = listOfNotNull(
                                            if (customActiveIngredient.isNotBlank()) "المادة الفعالة: $customActiveIngredient" else null,
                                            if (customTiming.isNotBlank()) "التوقيت: $customTiming" else null,
                                            if (customDurationDays.isNotBlank()) "المدة: $customDurationDays يوم" else null,
                                            if (customDoctorNotes.isNotBlank()) "ملاحظات: $customDoctorNotes" else null
                                        ).joinToString(" | ")

                                        viewModel.addMedication(
                                            MedicationEntity(
                                                officialName = customName.ifBlank { customNickname },
                                                userNickname = customNickname,
                                                concentration = customConc,
                                                form = customDosageUnits.ifBlank { "أقراص" },
                                                instructions = customInst,
                                                timesOfDay = customFreq,
                                                stockCount = customStockCount.toIntOrNull() ?: 30,
                                                notes = combinedNotes.ifBlank { "تمت إضافته عبر MR7 Vision" }
                                            )
                                        )
                                        viewModel.clearVisionResult()
                                        onMedicationAdded()
                                    },
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .height(if (isSenior) 54.dp else 48.dp)
                                        .testTag("save_vision_med_button"),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = tokens.success)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تأكيد وحفظ الدواء", fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { viewModel.clearVisionResult() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Text("إلغاء")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Helper to construct sample bitmap for demo vision capture
fun generateSampleBitmap(title: String): Bitmap {
    val bitmap = Bitmap.createBitmap(400, 250, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint().apply {
        color = android.graphics.Color.WHITE
        style = Paint.Style.FILL
    }
    canvas.drawRect(0f, 0f, 400f, 250f, paint)

    val textPaint = Paint().apply {
        color = android.graphics.Color.DKGRAY
        textSize = 28f
        isAntiAlias = true
    }
    canvas.drawText("MR7 Vision Sample Scan", 40f, 60f, textPaint)
    canvas.drawText(title, 40f, 120f, textPaint)
    return bitmap
}
