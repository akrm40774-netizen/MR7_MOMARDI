package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.LocalThemeTokens
import kotlinx.coroutines.delay

@Composable
fun TransitionLoadingScreen(
    onLoadingFinished: () -> Unit
) {
    val tokens = LocalThemeTokens.current

    // Trigger timer for a smooth 1.8 second loading transition
    LaunchedEffect(Unit) {
        delay(1800)
        onLoadingFinished()
    }

    // Infinite breathing pulse effect for Revo mascot avatar
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_transition")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "avatar_scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        tokens.background,
                        tokens.surfaceElevated.copy(alpha = 0.9f),
                        tokens.background
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(32.dp)
                .fillMaxWidth()
        ) {
            // Revo Mascot Avatar Container with Pulse Animation
            Surface(
                modifier = Modifier
                    .size(120.dp)
                    .scale(scale)
                    .shadow(16.dp, shape = CircleShape, spotColor = tokens.primary.copy(alpha = 0.25f))
                    .border(3.dp, tokens.primary.copy(alpha = 0.25f), CircleShape),
                shape = CircleShape,
                color = Color.White
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = R.drawable.onboarding_revo_ai),
                        contentDescription = "ريڤو المساعد الذكي",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Revo Greeting Badge
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = tokens.primary.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("💙", fontSize = 16.sp)
                    Text(
                        text = "ريڤو جاهز للبدء معك",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.primary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "جاري تجهيز تجربة ريڤو الخاصة بك...",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = tokens.textPrimary
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "نستعد لتقديم رعاية صحية ذكية وشخصية تناسبك تماماً",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = tokens.textSecondary,
                    lineHeight = 20.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Smooth Progress Indicator
            CircularProgressIndicator(
                color = tokens.primary,
                strokeWidth = 3.5.dp,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}
