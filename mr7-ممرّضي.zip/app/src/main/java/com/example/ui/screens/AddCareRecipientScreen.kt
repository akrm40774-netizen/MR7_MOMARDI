package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.UserPreferences
import com.example.ui.theme.LocalThemeTokens

@Composable
fun AddCareRecipientScreen(
    userPreferences: UserPreferences,
    onCareRecipientSetupFinished: () -> Unit
) {
    val tokens = LocalThemeTokens.current

    // Form inputs state
    var recipientName by remember { mutableStateOf(userPreferences.careRecipientName) }
    var selectedRelation by remember { mutableStateOf(userPreferences.careRecipientRelation.ifBlank { "والد" }) }
    var ageOrBirthYear by remember { mutableStateOf(userPreferences.careRecipientAge) }
    var emergencyPhone by remember { mutableStateOf(userPreferences.careRecipientPhone) }
    var selectedAvatar by remember { mutableStateOf(userPreferences.careRecipientAvatar.ifBlank { "👴🏻" }) }

    var nameError by remember { mutableStateOf(false) }

    val relationOptions = remember {
        listOf("والد", "والدة", "زوج", "زوجة", "ابن", "ابنة", "أخ", "أخت", "آخر")
    }

    val avatarOptions = remember {
        listOf("👴🏻", "👵🏻", "👨🏻‍🦳", "👩🏻‍🦳", "👦🏻", "👧🏻", "❤️", "🏥")
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        tokens.background,
                        tokens.surfaceElevated.copy(alpha = 0.85f),
                        tokens.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("add_care_recipient_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Revo Mascot / Warm Medical Icon Header Badge
            Surface(
                modifier = Modifier
                    .size(80.dp)
                    .shadow(12.dp, shape = CircleShape, spotColor = tokens.primary.copy(alpha = 0.2f))
                    .border(2.dp, tokens.primary.copy(alpha = 0.25f), CircleShape),
                shape = CircleShape,
                color = Color.White
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = R.drawable.onboarding_revo_ai),
                        contentDescription = "ريڤو المساعد الذكي",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Screen Title
            Text(
                text = "إضافة متلقي الرعاية",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = tokens.textPrimary,
                    fontSize = 24.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Screen Subtitle Message (exact prompt text)
            Text(
                text = "قم بإدارة خطة علاج من تحب، وتابع أدويتهم وقياساتهم وروتينهم الصحي في مكان واحد، لتكون دائمًا قريبًا من رعايتهم وااحتياجاتهم.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = tokens.textSecondary,
                    lineHeight = 22.sp,
                    fontSize = 14.sp
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Human Touch Informational Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = tokens.primary.copy(alpha = 0.08f),
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = tokens.primary.copy(alpha = 0.15f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = tokens.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = "من هو متلقي الرعاية؟",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.primary,
                                fontSize = 15.sp
                            )
                        )
                        Text(
                            text = "هو الشخص (والدك، والدتك، أحد أفراد أسرتك) الذي ترغب في تتبع مواعيد أدويته وقياساته ومساعدته على الاهتمام بصحته بكل سهولة.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = tokens.textPrimary,
                                lineHeight = 18.sp,
                                fontSize = 12.5.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Form Section Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = tokens.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Avatar Emoji Selector
                    Text(
                        text = "اختر الرمز التعبيري لمتلقي الرعاية",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        avatarOptions.forEach { emoji ->
                            val isSelected = selectedAvatar == emoji
                            Surface(
                                shape = CircleShape,
                                color = if (isSelected) tokens.primary.copy(alpha = 0.2f) else tokens.surfaceElevated,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) tokens.primary else tokens.cardBorder
                                ),
                                modifier = Modifier
                                    .size(42.dp)
                                    .clickable { selectedAvatar = emoji }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = emoji, fontSize = 20.sp)
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.5f))

                    // Name Input
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "اسم متلقي الرعاية *",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = recipientName,
                            onValueChange = {
                                recipientName = it
                                if (it.isNotBlank()) nameError = false
                            },
                            placeholder = { Text("مثال: الوالد (أبو أحمد)", color = tokens.textSecondary.copy(alpha = 0.6f)) },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = tokens.primary) },
                            isError = nameError,
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = tokens.primary,
                                unfocusedBorderColor = tokens.cardBorder,
                                focusedContainerColor = tokens.surfaceElevated,
                                unfocusedContainerColor = tokens.surfaceElevated
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("care_recipient_name_input")
                        )
                        if (nameError) {
                            Text(
                                text = "يرجى إدخال اسم متلقي الرعاية",
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.error)
                            )
                        }
                    }

                    // Relationship Chips
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "صلة القرابة",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )

                        // Wrap chips in 2 scrollable/flow rows
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                relationOptions.take(5).forEach { rel ->
                                    val isSelected = selectedRelation == rel
                                    RelationChip(
                                        text = rel,
                                        isSelected = isSelected,
                                        onClick = { selectedRelation = rel },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                relationOptions.drop(5).forEach { rel ->
                                    val isSelected = selectedRelation == rel
                                    RelationChip(
                                        text = rel,
                                        isSelected = isSelected,
                                        onClick = { selectedRelation = rel },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    // Optional Age / Birth Year
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "العمر أو سنة الميلاد (اختياري)",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = ageOrBirthYear,
                            onValueChange = { ageOrBirthYear = it },
                            placeholder = { Text("مثال: 68 سنة أو 1958", color = tokens.textSecondary.copy(alpha = 0.6f)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = tokens.primary,
                                unfocusedBorderColor = tokens.cardBorder,
                                focusedContainerColor = tokens.surfaceElevated,
                                unfocusedContainerColor = tokens.surfaceElevated
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Optional Emergency Contact Phone
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "رقم التواصل للطوارئ (اختياري)",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        OutlinedTextField(
                            value = emergencyPhone,
                            onValueChange = { emergencyPhone = it },
                            placeholder = { Text("مثال: 0501234567", color = tokens.textSecondary.copy(alpha = 0.6f)) },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = tokens.primary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = tokens.primary,
                                unfocusedBorderColor = tokens.cardBorder,
                                focusedContainerColor = tokens.surfaceElevated,
                                unfocusedContainerColor = tokens.surfaceElevated
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Action Button ("حفظ ومتابعة")
            Button(
                onClick = {
                    if (recipientName.isBlank()) {
                        nameError = true
                    } else {
                        userPreferences.completeCareRecipientSetup(
                            name = recipientName,
                            relation = selectedRelation,
                            age = ageOrBirthYear,
                            phone = emergencyPhone,
                            avatar = selectedAvatar
                        )
                        onCareRecipientSetupFinished()
                    }
                },
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                contentPadding = PaddingValues(vertical = 16.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("save_care_recipient_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "حفظ وإضافة متلقي الرعاية",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Secondary Skip Button (Friendly skip option)
            TextButton(
                onClick = {
                    userPreferences.completeCareRecipientSetup(
                        name = "",
                        relation = "",
                        age = "",
                        phone = "",
                        avatar = "👴🏻"
                    )
                    onCareRecipientSetupFinished()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("skip_care_recipient_button")
            ) {
                Text(
                    text = "سأضيف متلقي رعاية لاحقاً (تخطي)",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = tokens.textSecondary,
                        fontWeight = FontWeight.Medium
                    )
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun RelationChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) tokens.primary else tokens.surfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) tokens.primary else tokens.cardBorder
        ),
        modifier = modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else tokens.textPrimary,
                    fontSize = 13.sp
                )
            )
        }
    }
}
