package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppointmentEntity
import com.example.data.local.DoctorEntity
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentsScreen(
    viewModel: MainViewModel
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current
    val context = LocalContext.current

    val doctors by viewModel.allDoctors.collectAsState()
    val appointments by viewModel.upcomingAppointments.collectAsState()
    val activeMeds by viewModel.activeMedications.collectAsState()
    val allergies by viewModel.allAllergies.collectAsState()

    var showAddDoctorDialog by remember { mutableStateOf(false) }
    var showAddAppDialog by remember { mutableStateOf(false) }
    var showVisitPrepSheet by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // Top Header
        Surface(
            color = tokens.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📅 مواعيدي الطبية",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )
                    Text(
                        text = "متابعة الاستشارات، الأطباء، وتجهيز الزيارات",
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { showAddDoctorDialog = true }) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "إضافة طبيب", tint = tokens.primary)
                    }
                    Button(
                        onClick = { showAddAppDialog = true },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حجز موعد")
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 🩺 Doctor Visit Preparation Summary (تجهيز زيارة الطبيب)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showVisitPrepSheet = true }
                        .testTag("doctor_visit_prep_button"),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF7C4DFF).copy(alpha = 0.08f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7C4DFF).copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF7C4DFF),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "🩺 تجهيز زيارة الطبيب (Visit Summary)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF7C4DFF)
                                    )
                                )
                                Text(
                                    text = "ملخص منظم لأدويتك الحالية، الجرعات المسجلة للحذف/المشاركة",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Color(0xFF7C4DFF))
                    }
                }
            }

            // Section 1: Upcoming Appointments
            item {
                Text(
                    text = "📆 المواعيد القادمة",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    )
                )
            }

            if (appointments.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد مواعيد طبيب قادمة حاليًا.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                items(appointments) { app ->
                    AppointmentCard(
                        appointment = app,
                        onCompleted = { viewModel.completeAppointment(app.id) }
                    )
                }
            }

            // Section 2: Registered Doctor Profiles
            item {
                Text(
                    text = "👨‍⚕️ ملفات الأطباء (Doctor Profiles)",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    ),
                    modifier = Modifier.padding(top = 10.dp)
                )
            }

            if (doctors.isEmpty()) {
                item {
                    Text(
                        text = "لم تقم بإضافة أطباء حتى الآن.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary)
                    )
                }
            } else {
                items(doctors) { doc ->
                    DoctorCard(
                        doctor = doc,
                        onOpenMap = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(doc.mapUrl.ifBlank { "geo:0,0?q=${doc.clinicAddress}" }))
                            context.startActivity(intent)
                        }
                    )
                }
            }
        }
    }

    // Doctor Visit Preparation Sheet Modal
    if (showVisitPrepSheet) {
        ModalBottomSheet(
            onDismissRequest = { showVisitPrepSheet = false },
            containerColor = tokens.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🩺 ملخص تجهيز زيارة الطبيب",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )
                    IconButton(onClick = { showVisitPrepSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = null)
                    }
                }

                Divider(color = tokens.divider, modifier = Modifier.padding(vertical = 12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "💊 الأدوية الحالية المسجلة (${activeMeds.size}):",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                        )
                        activeMeds.forEach { med ->
                            Text(
                                text = "• ${med.userNickname} (${med.officialName}) - ${med.concentration}: ${med.instructions}",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(start = 12.dp, top = 2.dp)
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "⚠️ الحساسيات المسجلة (${allergies.size}):",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = tokens.warning)
                        )
                        if (allergies.isEmpty()) {
                            Text("لا توجد حساسيات مسجلة.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 12.dp))
                        } else {
                            allergies.forEach { allergy ->
                                Text(
                                    text = "• ${allergy.allergyName} (درجة الشدة: ${allergy.severity})",
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(start = 12.dp, top = 2.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { showVisitPrepSheet = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                ) {
                    Text("إغلاق الملخص")
                }
            }
        }
    }

    // Add Doctor Dialog
    if (showAddDoctorDialog) {
        AddDoctorDialog(
            onDismiss = { showAddDoctorDialog = false },
            onConfirm = { doc ->
                viewModel.addDoctor(doc)
                showAddDoctorDialog = false
            }
        )
    }

    // Add Appointment Dialog
    if (showAddAppDialog) {
        AddAppointmentDialog(
            doctors = doctors,
            onDismiss = { showAddAppDialog = false },
            onConfirm = { app ->
                viewModel.addAppointment(app)
                showAddAppDialog = false
            }
        )
    }
}

@Composable
fun AppointmentCard(
    appointment: AppointmentEntity,
    onCompleted: () -> Unit
) {
    val tokens = LocalThemeTokens.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
        colors = CardDefaults.cardColors(containerColor = tokens.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = tokens.primary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "🗓️ ${appointment.dateDisplay} — 🕐 ${appointment.timeDisplay}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = tokens.primary,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = appointment.doctorName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    )
                )
                Text(
                    text = "العيادة: ${appointment.clinicAddress}",
                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                )
            }

            IconButton(onClick = onCompleted) {
                Icon(Icons.Default.CheckCircle, contentDescription = "اكتمل", tint = tokens.success)
            }
        }
    }
}

@Composable
fun DoctorCard(
    doctor: DoctorEntity,
    onOpenMap: () -> Unit
) {
    val tokens = LocalThemeTokens.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
        colors = CardDefaults.cardColors(containerColor = tokens.surfaceElevated)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = tokens.primary,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("👨‍⚕️", fontSize = 22.sp)
                    }
                }

                Column {
                    Text(
                        text = doctor.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )
                    Text(
                        text = "التخصص: ${doctor.specialty}",
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.primary, fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = doctor.clinicAddress,
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                    )
                }
            }

            OutlinedButton(
                onClick = onOpenMap,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("الموقع")
            }
        }
    }
}

@Composable
fun AddDoctorDialog(
    onDismiss: () -> Unit,
    onConfirm: (DoctorEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var specialty by remember { mutableStateOf("") }
    var clinicAddress by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("👨‍⚕️ إضافة ملف طبيب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الطبيب (د. أحمد)") })
                OutlinedTextField(value = specialty, onValueChange = { specialty = it }, label = { Text("التخصص (عظام، باطنة...)") })
                OutlinedTextField(value = clinicAddress, onValueChange = { clinicAddress = it }, label = { Text("عنوان العيادة والموقع") })
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("رقم الهاتف") })
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    onConfirm(DoctorEntity(name = name, specialty = specialty, clinicAddress = clinicAddress, phone = phone))
                }
            }) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddAppointmentDialog(
    doctors: List<DoctorEntity>,
    onDismiss: () -> Unit,
    onConfirm: (AppointmentEntity) -> Unit
) {
    val tokens = LocalThemeTokens.current

    var selectedDoctor by remember { mutableStateOf<DoctorEntity?>(doctors.firstOrNull()) }
    var doctorName by remember { mutableStateOf(selectedDoctor?.name ?: "") }
    var specialty by remember { mutableStateOf(selectedDoctor?.specialty ?: "") }
    var clinicAddress by remember { mutableStateOf(selectedDoctor?.clinicAddress ?: "") }
    var dateDisplay by remember { mutableStateOf("غداً") }
    var notes by remember { mutableStateOf("مراجعة الفحوصات والتحاليل") }

    val context = LocalContext.current
    val calendar = java.util.Calendar.getInstance()
    val initYear = calendar.get(java.util.Calendar.YEAR)
    val initMonth = calendar.get(java.util.Calendar.MONTH)
    val initDay = calendar.get(java.util.Calendar.DAY_OF_MONTH)

    val datePickerDialog = android.app.DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            dateDisplay = String.format("%04d/%02d/%02d", year, month + 1, dayOfMonth)
        },
        initYear,
        initMonth,
        initDay
    )

    // Alarm-style Time Picker state (Matching AddMedicationDialog concept)
    var selectedHour by remember { mutableStateOf(6) }
    var selectedMinute by remember { mutableStateOf(0) }
    var isAm by remember { mutableStateOf(false) } // Default to PM for doctor appointments

    val formattedTime = String.format("%02d:%02d %s", selectedHour, selectedMinute, if (isAm) "ص" else "م")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📅 حجز موعد طبيب جديد",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق")
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1️⃣ Doctor selection from saved doctors or custom
                if (doctors.isNotEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "👨‍⚕️ اختر من أطبائك المسجلين:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                doctors.forEach { doc ->
                                    val isSelected = selectedDoctor?.id == doc.id
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            selectedDoctor = doc
                                            doctorName = doc.name
                                            specialty = doc.specialty
                                            clinicAddress = doc.clinicAddress
                                        },
                                        label = { Text(doc.name, fontWeight = FontWeight.Bold) },
                                        leadingIcon = if (isSelected) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                        } else null
                                    )
                                }
                                FilterChip(
                                    selected = selectedDoctor == null,
                                    onClick = {
                                        selectedDoctor = null
                                        doctorName = ""
                                        specialty = ""
                                        clinicAddress = ""
                                    },
                                    label = { Text("+ طبيب آخر") }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = doctorName,
                        onValueChange = { doctorName = it },
                        label = { Text("اسم الطبيب (د. أحمد...)") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = specialty,
                            onValueChange = { specialty = it },
                            label = { Text("التخصص (عظام، باطنة)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = clinicAddress,
                            onValueChange = { clinicAddress = it },
                            label = { Text("عنوان العيادة") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                // 2️⃣ 📅 Date Selection (Calendar Picker & Manual Writing Input)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📅 تاريخ الموعد:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                            )
                            TextButton(onClick = { datePickerDialog.show() }) {
                                Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اختر من التقويم", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("اليوم", "غداً", "بعد غد", "الأسبوع القادم").forEach { preset ->
                                FilterChip(
                                    selected = dateDisplay == preset,
                                    onClick = { dateDisplay = preset },
                                    label = { Text(preset) }
                                )
                            }
                            FilterChip(
                                selected = false,
                                onClick = { datePickerDialog.show() },
                                label = { Text("📅 التقويم", fontWeight = FontWeight.Bold) },
                                leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            )
                        }
                        OutlinedTextField(
                            value = dateDisplay,
                            onValueChange = { dateDisplay = it },
                            label = { Text("تاريخ الموعد (كتابة يدوية أو حدد بالتقويم)") },
                            leadingIcon = {
                                IconButton(onClick = { datePickerDialog.show() }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "فتح التقويم", tint = tokens.primary)
                                }
                            },
                            trailingIcon = {
                                IconButton(onClick = { datePickerDialog.show() }) {
                                    Icon(Icons.Default.EditCalendar, contentDescription = "اختيار من التقويم", tint = tokens.primary)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }

                // 3️⃣ ⏰ Alarm-Style Time Picker Section (Same as Add Medication)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = tokens.surfaceElevated)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⏰ موعد الموعد (منبه هاتف دقيق)",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = tokens.primary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = formattedTime,
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.primary,
                                        fontSize = 14.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                // Hours Picker
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(onClick = { selectedHour = if (selectedHour >= 12) 1 else selectedHour + 1 }) {
                                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = null)
                                    }
                                    Text(
                                        text = String.format("%02d", selectedHour),
                                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                    )
                                    IconButton(onClick = { selectedHour = if (selectedHour <= 1) 12 else selectedHour - 1 }) {
                                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                                    }
                                }

                                Text(" : ", style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold), modifier = Modifier.padding(horizontal = 8.dp))

                                // Minutes Picker
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(onClick = { selectedMinute = (selectedMinute + 15) % 60 }) {
                                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = null)
                                    }
                                    Text(
                                        text = String.format("%02d", selectedMinute),
                                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                    )
                                    IconButton(onClick = { selectedMinute = if (selectedMinute - 15 < 0) 45 else selectedMinute - 15 }) {
                                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                                    }
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                // AM/PM Toggle
                                Button(
                                    onClick = { isAm = !isAm },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary.copy(alpha = 0.2f), contentColor = tokens.primary)
                                ) {
                                    Text(if (isAm) "صباحاً (ص)" else "مساءً (م)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // 4️⃣ 📝 Notes Field
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات الموعد (تحاليل، أشعة، استشارة...)") },
                        leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalDoctorName = doctorName.ifBlank { "طبيب عيادة" }
                    val cleanDate = dateDisplay.ifBlank { "غداً" }

                    val cal = java.util.Calendar.getInstance()
                    when (cleanDate) {
                        "اليوم" -> { /* keep today */ }
                        "غداً" -> cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                        "بعد غد" -> cal.add(java.util.Calendar.DAY_OF_YEAR, 2)
                        "الأسبوع القادم" -> cal.add(java.util.Calendar.DAY_OF_YEAR, 7)
                        else -> {
                            try {
                                val parts = cleanDate.split("/")
                                if (parts.size == 3) {
                                    cal.set(java.util.Calendar.YEAR, parts[0].toInt())
                                    cal.set(java.util.Calendar.MONTH, parts[1].toInt() - 1)
                                    cal.set(java.util.Calendar.DAY_OF_MONTH, parts[2].toInt())
                                }
                            } catch (e: Exception) {
                                cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                            }
                        }
                    }

                    val hour24 = if (isAm) {
                        if (selectedHour == 12) 0 else selectedHour
                    } else {
                        if (selectedHour == 12) 12 else selectedHour + 12
                    }

                    cal.set(java.util.Calendar.HOUR_OF_DAY, hour24)
                    cal.set(java.util.Calendar.MINUTE, selectedMinute)
                    cal.set(java.util.Calendar.SECOND, 0)
                    val calculatedMillis = cal.timeInMillis

                    onConfirm(
                        AppointmentEntity(
                            doctorId = selectedDoctor?.id ?: 0,
                            doctorName = finalDoctorName,
                            specialty = specialty,
                            clinicAddress = clinicAddress,
                            dateDisplay = cleanDate,
                            timeDisplay = formattedTime,
                            notes = notes,
                            appointmentTimeMillis = calculatedMillis
                        )
                    )
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("حفظ الموعد", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
