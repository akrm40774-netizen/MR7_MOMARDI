package com.example.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FloatingVoiceBar
import com.example.ui.components.SecurityPinLockDialog
import com.example.ui.screens.*
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.ui.theme.Mr7Theme
import com.example.viewmodel.MainViewModel

enum class NavigationScreen(val titleAr: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("الرئيسية", Icons.Default.Home),
    MEDICATIONS("أدويتي", Icons.Default.Medication),
    VISION("MR7 Vision", Icons.Default.CameraAlt),
    APPOINTMENTS("المواعيد", Icons.Default.Event),
    FAMILY_CARE("رعاية", Icons.Default.People),
    SETTINGS("الإعدادات", Icons.Default.Settings)
}

@Composable
fun MainContainer(
    viewModel: MainViewModel,
    initialNavigateTo: String? = null
) {
    val prefs = viewModel.userPreferences

    Mr7Theme(
        themeMode = prefs.currentTheme,
        isSeniorMode = prefs.isSeniorMode
    ) {
        val tokens = LocalThemeTokens.current
        val isSenior = LocalSeniorMode.current

        val startScreen = when (initialNavigateTo) {
            "APPOINTMENTS" -> NavigationScreen.APPOINTMENTS
            "MEDICATIONS" -> NavigationScreen.MEDICATIONS
            else -> NavigationScreen.HOME
        }
        var currentScreen by remember { mutableStateOf(startScreen) }
        var showSplash by remember { mutableStateOf(true) }
        var showTransitionLoading by remember { mutableStateOf(false) }
        var showPermissionsWelcome by remember { mutableStateOf(!prefs.hasSeenPermissionsWelcome) }
        var showAdminDashboard by remember { mutableStateOf(false) }

        if (showSplash) {
            SplashScreen(onSplashFinished = { showSplash = false })
        } else if (!prefs.isLoggedIn) {
            com.example.ui.screens.AuthScreen(viewModel = viewModel)
        } else if (!prefs.hasSeenOnboarding) {
            com.example.ui.screens.OnboardingScreen(
                onFinishOnboarding = {
                    prefs.markOnboardingSeen()
                    showTransitionLoading = true
                }
            )
        } else if (showTransitionLoading) {
            com.example.ui.screens.TransitionLoadingScreen(
                onLoadingFinished = {
                    showTransitionLoading = false
                }
            )
        } else if (!prefs.isProfileSetupCompleted) {
            com.example.ui.screens.ProfileSetupScreen(
                userPreferences = prefs,
                onProfileSetupFinished = {
                    // Profile setup is completed and saved
                }
            )
        } else if (!prefs.isRoutineSetupCompleted) {
            com.example.ui.screens.RoutineSetupScreen(
                userPreferences = prefs,
                onRoutineSetupFinished = {
                    // Routine setup is completed and saved
                }
            )
        } else if (!prefs.isCareRecipientSetupCompleted) {
            com.example.ui.screens.AddCareRecipientScreen(
                userPreferences = prefs,
                onCareRecipientSetupFinished = {
                    // Care Recipient setup is completed and saved
                }
            )
        } else if (showAdminDashboard) {
            AdminDashboardScreen(
                viewModel = viewModel,
                onBack = { showAdminDashboard = false }
            )
        } else {
            // First Launch Permissions Welcome Overview Modal
            if (showPermissionsWelcome) {
                com.example.ui.components.WelcomePermissionsDialog(
                    onDismiss = {
                        prefs.markPermissionsWelcomeSeen()
                        showPermissionsWelcome = false
                    }
                )
            }

            // Check PIN lock
            if (prefs.isAppLocked) {
                SecurityPinLockDialog(
                    userPreferences = prefs,
                    onUnlocked = { /* unlocked */ }
                )
            }

            // 15-Minute Doctor Appointment In-App Popup Reminder
            val activeAppointmentReminder by viewModel.activeAppointmentReminder.collectAsState()
            activeAppointmentReminder?.let { app ->
                DoctorAppointmentReminderPopup(
                    appointment = app,
                    onOpenDetails = {
                        viewModel.dismissAppointmentReminder(app.id)
                        currentScreen = NavigationScreen.APPOINTMENTS
                    },
                    onDismiss = {
                        viewModel.dismissAppointmentReminder(app.id)
                    }
                )
            }

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = tokens.background,
                bottomBar = {
                    Column(modifier = Modifier.background(tokens.background)) {
                        // Floating Voice Bar anchored above bottom navigation
                        FloatingVoiceBar(
                            viewModel = viewModel,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )

                        NavigationBar(
                            containerColor = tokens.surface,
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .testTag("bottom_navigation_bar")
                        ) {
                            val navItems = listOf(
                                NavigationScreen.FAMILY_CARE,
                                NavigationScreen.VISION,
                                NavigationScreen.HOME,
                                NavigationScreen.MEDICATIONS,
                                NavigationScreen.APPOINTMENTS
                            )
                            navItems.forEach { screen ->
                                val selected = currentScreen == screen
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentScreen = screen },
                                    icon = {
                                        Icon(
                                            imageVector = screen.icon,
                                            contentDescription = screen.titleAr,
                                            modifier = Modifier.size(if (isSenior) 26.dp else 22.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = screen.titleAr,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = tokens.primary,
                                        selectedTextColor = tokens.primary,
                                        unselectedIconColor = tokens.textSecondary,
                                        unselectedTextColor = tokens.textSecondary,
                                        indicatorColor = tokens.primary.copy(alpha = 0.12f)
                                    ),
                                    modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    Crossfade(targetState = currentScreen, label = "screen_crossfade") { screen ->
                        when (screen) {
                            NavigationScreen.HOME -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateToVision = { currentScreen = NavigationScreen.VISION },
                                onNavigateToMeds = { currentScreen = NavigationScreen.MEDICATIONS },
                                onNavigateToAppointments = { currentScreen = NavigationScreen.APPOINTMENTS },
                                onNavigateToCare = { currentScreen = NavigationScreen.FAMILY_CARE },
                                onNavigateToSettings = { currentScreen = NavigationScreen.SETTINGS }
                            )
                            NavigationScreen.MEDICATIONS -> MedicationsScreen(
                                viewModel = viewModel,
                                onNavigateToVision = { currentScreen = NavigationScreen.VISION }
                            )
                            NavigationScreen.VISION -> VisionScanScreen(
                                viewModel = viewModel,
                                onMedicationAdded = { currentScreen = NavigationScreen.MEDICATIONS }
                            )
                            NavigationScreen.APPOINTMENTS -> AppointmentsScreen(
                                viewModel = viewModel
                            )
                            NavigationScreen.FAMILY_CARE -> FamilyCareScreen(
                                viewModel = viewModel
                            )
                            NavigationScreen.SETTINGS -> ProfileAndSettingsScreen(
                                viewModel = viewModel,
                                onNavigateToAdmin = { showAdminDashboard = true }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DoctorAppointmentReminderPopup(
    appointment: com.example.data.local.AppointmentEntity,
    onOpenDetails: () -> Unit,
    onDismiss: () -> Unit
) {
    val tokens = LocalThemeTokens.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    color = tokens.primary.copy(alpha = 0.15f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("🩺", fontSize = 20.sp)
                    }
                }
                Column {
                    Text(
                        text = "🩺 موعدك قريب!",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.primary
                        )
                    )
                    Text(
                        text = "موعد الطبيب بعد ربع ساعة (15 دقيقة)",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = tokens.textSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        },
        text = {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = tokens.surfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("👨‍⚕️ ", fontSize = 16.sp)
                        Text(
                            text = appointment.doctorName,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        if (appointment.specialty.isNotBlank()) {
                            Text(
                                text = " (${appointment.specialty})",
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🕐 ", fontSize = 16.sp)
                        Text(
                            text = "${appointment.timeDisplay} — ${appointment.dateDisplay}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.primary
                            )
                        )
                    }

                    if (appointment.clinicAddress.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📍 ", fontSize = 16.sp)
                            Text(
                                text = appointment.clinicAddress,
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onOpenDetails,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
            ) {
                Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("📅 فتح تفاصيل الموعد", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("حسنًا", fontWeight = FontWeight.Bold, color = tokens.textSecondary)
            }
        }
    )
}
