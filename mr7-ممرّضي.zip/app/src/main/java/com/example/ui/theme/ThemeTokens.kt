package com.example.ui.theme

import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val titleAr: String, val iconRes: String) {
    MEDICAL_BLUE("الأزرق الطبي", "🩵"),
    CALM_CARE("الرعاية الهادئة", "🌿"),
    NIGHT_CARE("الوضع الليلي", "🌙"),
    MIDNIGHT_PREMIUM("ميدنايت بريميوم", "🖤"),
    MINIMAL("المبسط الناصع", "🤍")
}

data class ThemeTokens(
    val isDark: Boolean,
    val background: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val primary: Color,
    val onPrimary: Color,
    val secondary: Color,
    val onSecondary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val divider: Color,
    val cardBorder: Color
)

fun getThemeTokens(mode: AppThemeMode): ThemeTokens {
    return when (mode) {
        AppThemeMode.MEDICAL_BLUE -> ThemeTokens(
            isDark = false,
            background = Color(0xFFF0F5F9),
            surface = Color(0xFFFFFFFF),
            surfaceElevated = Color(0xFFE2EBF2),
            primary = Color(0xFF006494),
            onPrimary = Color.White,
            secondary = Color(0xFF0284C7),
            onSecondary = Color.White,
            textPrimary = Color(0xFF1A1C1E),
            textSecondary = Color(0xFF64748B),
            success = Color(0xFF16A34A),
            warning = Color(0xFFF97316),
            error = Color(0xFFDC2626),
            divider = Color(0xFFE2E8F0),
            cardBorder = Color(0xFFE2E8F0)
        )
        AppThemeMode.CALM_CARE -> ThemeTokens(
            isDark = false,
            background = Color(0xFFF2F8F5),
            surface = Color(0xFFFFFFFF),
            surfaceElevated = Color(0xFFE3F2ED),
            primary = Color(0xFF1B5E20),
            onPrimary = Color.White,
            secondary = Color(0xFF00897B),
            onSecondary = Color.White,
            textPrimary = Color(0xFF0F2B1D),
            textSecondary = Color(0xFF4A6B5B),
            success = Color(0xFF2E7D32),
            warning = Color(0xFFE65100),
            error = Color(0xFFC62828),
            divider = Color(0xFFD8EADF),
            cardBorder = Color(0xFFC4E2D3)
        )
        AppThemeMode.NIGHT_CARE -> ThemeTokens(
            isDark = true,
            background = Color(0xFF111822),
            surface = Color(0xFF1A2332),
            surfaceElevated = Color(0xFF232E42),
            primary = Color(0xFF4797FF),
            onPrimary = Color(0xFF00295C),
            secondary = Color(0xFF26A69A),
            onSecondary = Color.White,
            textPrimary = Color(0xFFF0F4F9),
            textSecondary = Color(0xFF94A3B8),
            success = Color(0xFF4CAF50),
            warning = Color(0xFFFF9800),
            error = Color(0xFFEF5350),
            divider = Color(0xFF2B384E),
            cardBorder = Color(0xFF2E3D56)
        )
        AppThemeMode.MIDNIGHT_PREMIUM -> ThemeTokens(
            isDark = true,
            background = Color(0xFF0B0E14),
            surface = Color(0xFF141A24),
            surfaceElevated = Color(0xFF1D2636),
            primary = Color(0xFF00E5FF),
            onPrimary = Color(0xFF00363A),
            secondary = Color(0xFF7C4DFF),
            onSecondary = Color.White,
            textPrimary = Color(0xFFF8FAFC),
            textSecondary = Color(0xFF8E9BAE),
            success = Color(0xFF00E676),
            warning = Color(0xFFFFAB00),
            error = Color(0xFFFF5252),
            divider = Color(0xFF263042),
            cardBorder = Color(0xFF283448)
        )
        AppThemeMode.MINIMAL -> ThemeTokens(
            isDark = false,
            background = Color(0xFFFAFAFA),
            surface = Color(0xFFFFFFFF),
            surfaceElevated = Color(0xFFF0F0F0),
            primary = Color(0xFF212121),
            onPrimary = Color.White,
            secondary = Color(0xFF616161),
            onSecondary = Color.White,
            textPrimary = Color(0xFF121212),
            textSecondary = Color(0xFF666666),
            success = Color(0xFF388E3C),
            warning = Color(0xFFF57C00),
            error = Color(0xFFD32F2F),
            divider = Color(0xFFEEEEEE),
            cardBorder = Color(0xFFE0E0E0)
        )
    }
}
