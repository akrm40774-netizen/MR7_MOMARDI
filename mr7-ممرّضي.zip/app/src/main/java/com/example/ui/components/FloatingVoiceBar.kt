package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.SpeechToTextHelper
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloatingVoiceBar(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current
    val context = LocalContext.current

    val isOpen by viewModel.isVoiceBottomSheetOpen.collectAsState()
    val isProcessing by viewModel.isVoiceProcessing.collectAsState()
    val voiceMessages by viewModel.voiceMessages.collectAsState()
    val isSpeaking = viewModel.ttsHelper.isSpeaking

    val speechHelper = remember { SpeechToTextHelper(context) }
    var textInput by remember { mutableStateOf("") }
    var micErrorMessage by remember { mutableStateOf<String?>(null) }
    var showMicPermissionDialog by remember { mutableStateOf(false) }

    // Speech-to-Text start helper
    val startVoiceRecognition = {
        micErrorMessage = null
        speechHelper.startListening(
            onResult = { recognizedText ->
                if (recognizedText.isNotBlank()) {
                    textInput = recognizedText
                    viewModel.sendVoiceQuery(recognizedText)
                }
            },
            onErrorCallback = { err ->
                micErrorMessage = err
            }
        )
    }

    // Permission Launcher
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.openVoiceBottomSheet()
            startVoiceRecognition()
        } else {
            micErrorMessage = "تم رفض صلاحية الميكروفون. يلزم إعطاء الصلاحية لاستخدام المساعد الصوتي."
            showMicPermissionDialog = true
        }
    }

    if (showMicPermissionDialog) {
        ContextualPermissionRequester(
            permissionType = AppPermissionType.MICROPHONE,
            showRationale = true,
            onDismiss = { showMicPermissionDialog = false },
            onPermissionGranted = {
                showMicPermissionDialog = false
                viewModel.openVoiceBottomSheet()
                startVoiceRecognition()
            }
        )
    }

    val onVoiceBarClicked = {
        val hasMicPermission = AppPermissionType.isPermissionGranted(context, android.Manifest.permission.RECORD_AUDIO)
        if (hasMicPermission) {
            viewModel.openVoiceBottomSheet()
            startVoiceRecognition()
        } else {
            micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        }
    }

    // Pulsing waveform animation for mic button
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Floating Bar preview above bottom bar
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("floating_voice_bar_container")
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .clickable { onVoiceBarClicked() }
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(28.dp)),
            color = Color(0xFF1E293B),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = if (isSenior) 12.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f).padding(start = 4.dp)) {
                    Text(
                        text = "ممرّضي الصوتي",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF60A5FA)
                        )
                    )
                    Text(
                        text = if (isProcessing) "🧠 ممرّضي يفكر..." else "اتكلم براحتك...",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(if (isSenior) 52.dp else 44.dp)
                        .clip(CircleShape)
                        .background(tokens.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "المساعد الصوتي",
                        tint = Color.White,
                        modifier = Modifier.size(if (isSenior) 26.dp else 22.dp)
                    )
                }
            }
        }
    }

    // Full Voice Assistant Sheet
    if (isOpen) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.closeVoiceBottomSheet() },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = tokens.surface,
            scrimColor = Color.Black.copy(alpha = 0.5f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f)
                    .padding(horizontal = 20.dp)
            ) {
                // Sheet Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = tokens.primary,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "MR7 Voice — المساعد الصوتي",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                            Text(
                                text = "محادثة طبيعية باللهجة المصرية",
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                            )
                        }
                    }

                    IconButton(onClick = { viewModel.closeVoiceBottomSheet() }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = tokens.textSecondary
                        )
                    }
                }

                HorizontalDivider(color = tokens.divider, modifier = Modifier.padding(bottom = 12.dp))

                // Microphone Error Warning Banner
                if (micErrorMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.error.copy(alpha = 0.12f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = tokens.error)
                            Text(
                                text = micErrorMessage!!,
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textPrimary),
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = startVoiceRecognition,
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.error),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("إعادة المحاولة", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Live Active Speech Recording State Banner
                if (speechHelper.isListening) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = tokens.primary.copy(alpha = 0.12f)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, tokens.primary)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                CircularProgressIndicator(
                                    color = tokens.primary,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column {
                                    Text(
                                        text = "🎙️ أستمع إليك الآن... اتكلم براحتك",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = tokens.primary
                                        )
                                    )
                                    Text(
                                        text = if (speechHelper.recognizedText.isNotBlank())
                                            "النص الملتقط: \"${speechHelper.recognizedText}\""
                                        else
                                            "تحدث بوضوح بالعامية المصرية...",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textPrimary)
                                    )
                                }
                            }

                            Button(
                                onClick = { speechHelper.stopListening() },
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.error),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إيقاف 🛑", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Conversation Message List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    reverseLayout = false
                ) {
                    items(voiceMessages) { (sender, message) ->
                        val isUser = sender == "USER"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                shape = RoundedCornerShape(
                                    topStart = 20.dp,
                                    topEnd = 20.dp,
                                    bottomStart = if (isUser) 20.dp else 4.dp,
                                    bottomEnd = if (isUser) 4.dp else 20.dp
                                ),
                                color = if (isUser) tokens.primary else tokens.surfaceElevated,
                                border = if (isUser) null else androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                                modifier = Modifier
                                    .widthIn(max = 300.dp)
                                    .padding(vertical = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = if (isUser) "أنت" else "🩺 MR7 ممرّضي",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = if (isUser) Color.White.copy(alpha = 0.8f) else tokens.primary,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                    Text(
                                        text = message,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            color = if (isUser) Color.White else tokens.textPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }

                    if (isProcessing) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = tokens.surfaceElevated,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = tokens.primary,
                                            strokeWidth = 2.dp
                                        )
                                        Text(
                                            text = "ممرّضي يفكر ويراجع بياناتك...",
                                            style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // TTS Playback Bar
                if (isSpeaking) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        color = tokens.primary.copy(alpha = 0.1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "جار القراءة الصوتية",
                                    tint = tokens.primary
                                )
                                Text(
                                    text = "جار القراءة بصوت ممرّضي الطبيعي...",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = tokens.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = { viewModel.ttsHelper.setSpeed(0.8f) }) {
                                    Text("0.8x", fontSize = 11.sp, color = tokens.primary)
                                }
                                TextButton(onClick = { viewModel.ttsHelper.setSpeed(1.0f) }) {
                                    Text("1.0x", fontSize = 11.sp, color = tokens.primary)
                                }
                                IconButton(onClick = { viewModel.ttsHelper.stop() }) {
                                    Icon(Icons.Default.Stop, contentDescription = "إيقاف", tint = tokens.error)
                                }
                            }
                        }
                    }
                }

                // Quick Egyptian Arabic Suggestion Chips
                Text(
                    text = "أسئلة مقترحة:",
                    style = MaterialTheme.typography.labelSmall.copy(color = tokens.textSecondary),
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val chips = listOf(
                        "وريني دواء العظام",
                        "أنا أخدت الدوا ولا لأ؟",
                        "هو الدكتور بتاعي إمتى؟"
                    )
                    chips.forEach { chipText ->
                        SuggestionChip(
                            onClick = { viewModel.sendVoiceQuery(chipText) },
                            label = { Text(chipText, style = MaterialTheme.typography.labelSmall) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = tokens.surfaceElevated,
                                labelColor = tokens.textPrimary
                            )
                        )
                    }
                }

                // Speech Input & Text Field Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("اكتب أو تحدث بالضغط على المايك...", fontSize = 14.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("voice_text_input"),
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = tokens.surfaceElevated,
                            unfocusedContainerColor = tokens.surfaceElevated,
                            focusedBorderColor = tokens.primary,
                            unfocusedBorderColor = tokens.cardBorder
                        ),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            if (speechHelper.isListening) {
                                speechHelper.stopListening()
                            } else if (textInput.isNotBlank()) {
                                viewModel.sendVoiceQuery(textInput)
                                textInput = ""
                            } else {
                                startVoiceRecognition()
                            }
                        },
                        modifier = Modifier
                            .size(if (isSenior) 54.dp else 48.dp)
                            .clip(CircleShape)
                            .background(if (speechHelper.isListening) tokens.error else tokens.primary)
                            .testTag("send_voice_button")
                    ) {
                        Icon(
                            imageVector = when {
                                speechHelper.isListening -> Icons.Default.Stop
                                textInput.isBlank() -> Icons.Default.Mic
                                else -> Icons.AutoMirrored.Filled.Send
                            },
                            contentDescription = "إرسال / تحدث",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
