package com.example.ui.components

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.GeminiRivoProvider
import com.example.ai.RivoConnectionStatus
import com.example.ai.RivoConversationState
import com.example.ai.RivoVoicePersona
import com.example.ai.SpeechToTextHelper
import com.example.data.LocationLocaleManager
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloatingVoiceBar(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current
    val context = LocalContext.current
    val prefs = viewModel.userPreferences

    val isOpen by viewModel.isVoiceBottomSheetOpen.collectAsState()
    val isProcessing by viewModel.isVoiceProcessing.collectAsState()
    val voiceMessages by viewModel.voiceMessages.collectAsState()
    val rivoState by viewModel.rivoState.collectAsState()
    val latencyMs by viewModel.rivoLatencyMs.collectAsState()
    val pendingReminder by viewModel.rivoPendingReminder.collectAsState()
    val isMicMuted by viewModel.isMicMuted.collectAsState()
    val isSpeaking = viewModel.ttsHelper.isSpeaking

    val effectiveState = when {
        isProcessing -> RivoConversationState.PROCESSING
        isSpeaking -> RivoConversationState.SPEAKING
        rivoState == RivoConversationState.LISTENING -> RivoConversationState.LISTENING
        else -> RivoConversationState.IDLE
    }

    val speechHelper = remember { SpeechToTextHelper(context) }
    var textInput by remember { mutableStateOf("") }
    var isTextMode by remember { mutableStateOf(false) }
    var showQuickVoicePicker by remember { mutableStateOf(false) }
    var micErrorMessage by remember { mutableStateOf<String?>(null) }
    var showMicPermissionDialog by remember { mutableStateOf(false) }
    var connectionStatus by remember { mutableStateOf(GeminiRivoProvider.checkConnectionStatus(context)) }

    val startVoiceRecognition = {
        if (!isMicMuted) {
            micErrorMessage = null
            connectionStatus = GeminiRivoProvider.checkConnectionStatus(context)
            viewModel.setRivoState(RivoConversationState.LISTENING)
            speechHelper.startListening(
                onResult = { recognizedText ->
                    viewModel.setRivoState(RivoConversationState.IDLE)
                    if (recognizedText.isNotBlank()) {
                        textInput = recognizedText
                        viewModel.sendVoiceQuery(recognizedText)
                    }
                },
                onErrorCallback = { err ->
                    viewModel.setRivoState(RivoConversationState.IDLE)
                    micErrorMessage = err
                }
            )
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.openVoiceBottomSheet()
            startVoiceRecognition()
        } else {
            micErrorMessage = "تم رفض صلاحية الميكروفون. يلزم إعطاء الصلاحية لاستخدام المساعد الصوتي 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎."
            showMicPermissionDialog = true
        }
    }

    if (showMicPermissionDialog) {
        ContextualPermissionRequester(
            permissionType = AppPermissionType.MICROPHONE,
            showRationale = true,
            onDismiss = { showMicPermissionDialog = false },
            onPermissionGranted = {
                showMicPermissionDialog = false
                viewModel.openVoiceBottomSheet()
                startVoiceRecognition()
            }
        )
    }

    val onVoiceBarClicked = {
        connectionStatus = GeminiRivoProvider.checkConnectionStatus(context)
        val hasMicPermission = AppPermissionType.isPermissionGranted(context, Manifest.permission.RECORD_AUDIO)
        if (hasMicPermission) {
            viewModel.openVoiceBottomSheet()
            if (!isMicMuted) startVoiceRecognition()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "rivo_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.16f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Floating Bar preview above bottom bar
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (isSenior) 62.dp else 54.dp)
                .clip(RoundedCornerShape(28.dp))
                .clickable { onVoiceBarClicked() }
                .border(
                    width = 1.5.dp,
                    brush = Brush.horizontalGradient(listOf(tokens.primary, tokens.secondary)),
                    shape = RoundedCornerShape(28.dp)
                )
                .testTag("floating_voice_bar"),
            color = tokens.surfaceElevated,
            shadowElevation = 6.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (isSenior) 42.dp else 36.dp)
                            .scale(if (effectiveState == RivoConversationState.LISTENING) pulseScale else 1f)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(tokens.primary, tokens.secondary))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.GraphicEq,
                            contentDescription = "𝐌𝐑𝟕 𝐑𝐈𝐕𝐎",
                            tint = Color.White,
                            modifier = Modifier.size(if (isSenior) 22.dp else 18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 (ريڤو) — المساعد الصوتي",
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.primary,
                                fontSize = if (isSenior) 15.sp else 13.sp
                            )
                        )
                        Text(
                            text = when (effectiveState) {
                                RivoConversationState.LISTENING -> "🎙️ ريڤو يستمع إليك الآن..."
                                RivoConversationState.PROCESSING -> "⏳ جاري معالجة طلبك..."
                                RivoConversationState.SPEAKING -> "🔊 ريڤو يتحدث (اضغط للمقاطعة)"
                                RivoConversationState.IDLE -> "اضغط للتحدث باللهجة المصرية أو العربية..."
                            },
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = tokens.textSecondary,
                                fontSize = if (isSenior) 13.sp else 11.sp
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.primary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "تحدث",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = tokens.primary,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }

    // Full 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 Interactive Conversation Sheet
    if (isOpen) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.closeVoiceBottomSheet() },
            containerColor = tokens.surface,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .padding(bottom = 24.dp)
            ) {
                // Header: Brand, Connection Status, Latency, Mute, Clear, Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 (ريڤو)",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = tokens.primary
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = connectionStatus.labelAr,
                                style = MaterialTheme.typography.labelSmall.copy(color = tokens.textSecondary)
                            )
                            Text(
                                text = "• ${LocationLocaleManager.getDialectDisplayName(prefs.rivoDialect)}",
                                style = MaterialTheme.typography.labelSmall.copy(color = tokens.primary)
                            )
                            if (latencyMs > 0) {
                                Text(
                                    text = "• ⚡ ${latencyMs}ms",
                                    style = MaterialTheme.typography.labelSmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { showQuickVoicePicker = !showQuickVoicePicker },
                            modifier = Modifier.testTag("rivo_voice_picker_toggle")
                        ) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "اختيار الصوت",
                                tint = tokens.primary
                            )
                        }
                        IconButton(
                            onClick = { viewModel.toggleMicMute() },
                            modifier = Modifier.testTag("rivo_mute_button")
                        ) {
                            Icon(
                                imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = if (isMicMuted) "إلغاء كتم الميكروفون" else "كتم الميكروفون",
                                tint = if (isMicMuted) tokens.error else tokens.primary
                            )
                        }
                        IconButton(
                            onClick = { viewModel.clearRivoHistory() },
                            modifier = Modifier.testTag("rivo_clear_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "حذف سجل المحادثة",
                                tint = tokens.textSecondary
                            )
                        }
                        IconButton(onClick = { viewModel.closeVoiceBottomSheet() }) {
                            Icon(Icons.Default.Close, contentDescription = "إنهاء المحادثة", tint = tokens.textSecondary)
                        }
                    }
                }

                // Quick Voice & Dialect Selector
                AnimatedVisibility(visible = showQuickVoicePicker) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.surfaceElevated,
                        border = BorderStroke(1.dp, tokens.cardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "🎙️ اختر صوت 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 وجرّبه:",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(RivoVoicePersona.entries) { persona ->
                                    val selected = prefs.rivoVoiceId == persona.id
                                    FilterChip(
                                        selected = selected,
                                        onClick = {
                                            prefs.updateRivoSettings(voiceId = persona.id)
                                            viewModel.ttsHelper.previewVoice(persona, prefs.rivoDialect, prefs.rivoSpeechRate)
                                        },
                                        label = { Text(persona.displayNameAr, fontSize = 12.sp) }
                                    )
                                }
                            }
                        }
                    }
                }

                // Visual State Banner (Listening / Processing / Speaking with Barge-in)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = when (effectiveState) {
                        RivoConversationState.LISTENING -> tokens.primary.copy(alpha = 0.12f)
                        RivoConversationState.SPEAKING -> tokens.secondary.copy(alpha = 0.12f)
                        RivoConversationState.PROCESSING -> tokens.warning.copy(alpha = 0.12f)
                        RivoConversationState.IDLE -> tokens.surfaceElevated
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            when (effectiveState) {
                                RivoConversationState.LISTENING -> {
                                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = tokens.primary)
                                    Text("ريڤو يستمع إليك الآن...", fontWeight = FontWeight.Bold, color = tokens.primary, fontSize = 13.sp)
                                }
                                RivoConversationState.PROCESSING -> {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = tokens.primary)
                                    Text("جاري فهم طلبك وتحضير الرد...", fontWeight = FontWeight.Bold, color = tokens.textPrimary, fontSize = 13.sp)
                                }
                                RivoConversationState.SPEAKING -> {
                                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = tokens.secondary)
                                    Text("ريڤو يتحدث الآن...", fontWeight = FontWeight.Bold, color = tokens.secondary, fontSize = 13.sp)
                                }
                                RivoConversationState.IDLE -> {
                                    Icon(Icons.Default.Assistant, contentDescription = null, tint = tokens.textSecondary)
                                    Text(
                                        if (isMicMuted) "الميكروفون مكتوم" else "اضغط على الميكروفون للتحدث",
                                        color = tokens.textSecondary,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }

                        if (effectiveState == RivoConversationState.SPEAKING) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.interruptRivoSpeaking()
                                    startVoiceRecognition()
                                },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("rivo_barge_in_button")
                            ) {
                                Text("مقاطعة ✋", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                micErrorMessage?.let { err ->
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.error),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                // Pending Reminder Confirmation Card
                pendingReminder?.let { rem ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = tokens.primary.copy(alpha = 0.1f),
                        border = BorderStroke(1.dp, tokens.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "💊 تأكيد إضافة تذكير: ${rem.medicationName}",
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "الموعد المقترح: ${rem.timeDisplay}",
                                    color = tokens.textSecondary,
                                    fontSize = 12.sp
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { viewModel.confirmPendingReminder() },
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Text("تأكيد ✅", fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.dismissPendingReminder() },
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Text("إلغاء", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // Conversation Transcript
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 180.dp, max = 300.dp)
                        .padding(vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(voiceMessages) { (sender, msg) ->
                        val isUser = sender == "USER"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = if (isUser) tokens.primary else tokens.surfaceElevated,
                                border = if (isUser) null else BorderStroke(1.dp, tokens.cardBorder),
                                modifier = Modifier.widthIn(max = 300.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = if (isUser) "أنت" else "🩺 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isUser) Color.White.copy(alpha = 0.85f) else tokens.primary,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(bottom = 3.dp)
                                    )
                                    Text(
                                        text = msg,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = if (isUser) Color.White else tokens.textPrimary,
                                            fontSize = if (isSenior) 17.sp else 14.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Controls: Voice / Text Mode Toggle + Mic Button + Text Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { isTextMode = !isTextMode },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(tokens.surfaceElevated)
                            .testTag("rivo_toggle_input_mode")
                    ) {
                        Icon(
                            imageVector = if (isTextMode) Icons.Default.Mic else Icons.Default.Keyboard,
                            contentDescription = if (isTextMode) "التحول للصوت" else "التحول للكتابة",
                            tint = tokens.primary
                        )
                    }

                    if (isTextMode) {
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("اكتب سؤالك لريڤو...", fontSize = 14.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            shape = RoundedCornerShape(22.dp)
                        )
                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    viewModel.sendVoiceQuery(textInput)
                                    textInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(tokens.primary)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال", tint = Color.White)
                        }
                    } else {
                        Button(
                            onClick = {
                                if (effectiveState == RivoConversationState.SPEAKING) {
                                    viewModel.interruptRivoSpeaking()
                                }
                                startVoiceRecognition()
                            },
                            enabled = !isMicMuted,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("rivo_start_listen_button"),
                            shape = RoundedCornerShape(25.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                        ) {
                            Icon(
                                imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when {
                                    isMicMuted -> "الميكروفون مكتوم"
                                    effectiveState == RivoConversationState.SPEAKING -> "مقاطعة والتحدث"
                                    effectiveState == RivoConversationState.LISTENING -> "جاري الاستماع..."
                                    else -> "اضغط للتحدث مع ريڤو"
                                },
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
