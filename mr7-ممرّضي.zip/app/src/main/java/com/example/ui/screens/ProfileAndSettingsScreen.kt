package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.launch
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SuperAdminConfig
import com.example.data.local.AllergyEntity
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileAndSettingsScreen(
    viewModel: MainViewModel,
    onNavigateToAdmin: (() -> Unit)? = null
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    val prefs = viewModel.userPreferences
    val allergies by viewModel.allAllergies.collectAsState()
    val isSuperAdmin = viewModel.isSuperAdmin

    var userNameInput by remember { mutableStateOf(prefs.userName) }
    var pinInput by remember { mutableStateOf(prefs.pinLock) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showAddAllergyDialog by remember { mutableStateOf(false) }
    var editingAllergy by remember { mutableStateOf<AllergyEntity?>(null) }

    val context = LocalContext.current
    var refreshTrigger by remember { mutableStateOf(0) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        refreshTrigger++
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // Top Header
        Surface(
            color = tokens.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "⚙️ الإعدادات والهوية — Profile & Theme",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    )
                )
                Text(
                    text = "مظاهر التطبيق، وضع كبار السن، الأمان وحساسياتك",
                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Super Admin Section (👑 إدارة التطبيق) - Visible ONLY to Super Admin
            if (isSuperAdmin) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToAdmin?.invoke() }
                            .testTag("super_admin_dashboard_card"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(46.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("👑", fontSize = 24.sp)
                                    }
                                }
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = "👑 إدارة التطبيق",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = "إدارة المستخدمين وإعدادات التطبيق الإدارية",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
            // User Account & Data Card (👤 حسابي ومزامنة البيانات)
            item {
                val isSyncing by viewModel.isSyncing.collectAsState()
                val syncMsg by viewModel.syncSuccessMessage.collectAsState()
                val activeUid = viewModel.currentUserId.collectAsState().value
                var showDeleteConfirmDialog by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "👤 حسابي وحفظ البيانات",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary,
                                        fontSize = if (isSenior) 19.sp else 16.sp
                                    )
                                )
                                Text(
                                    text = "إدارة هويتك، المزامنة، وتسجيل الخروج",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xFFE8F5E9)
                            ) {
                                Text(
                                    text = "🟢 متصل ومزامن",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2E7D32)
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // User Details Box
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = tokens.surfaceElevated,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val userAccount by viewModel.currentUserAccount.collectAsState()
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Badge,
                                        contentDescription = null,
                                        tint = tokens.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = prefs.userName,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = tokens.textPrimary
                                        )
                                    )
                                }

                                if (prefs.activeUserEmail.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "البريد: ${prefs.activeUserEmail}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                    )
                                }

                                if (prefs.userBirthDate.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "🎂 الميلاد: ${prefs.userBirthDate}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                    )
                                }

                                Row(
                                    modifier = Modifier.padding(top = 6.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (prefs.hasRegularMeds) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = tokens.primary.copy(alpha = 0.12f)
                                        ) {
                                            Text(
                                                text = "💊 أدوية منتظمة",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = tokens.primary,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    if (prefs.hasRegularAppointments) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = tokens.primary.copy(alpha = 0.12f)
                                        ) {
                                            Text(
                                                text = "🩺 مواعيد منتظمة",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = tokens.primary,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = tokens.primary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "User ID: $activeUid",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = tokens.primary,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = tokens.cardBorder, thickness = 1.dp)
                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "🔗 طرق تسجيل الدخول المرتبطة بالحساب:",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                // Linked Auth Badges
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Google Badge
                                    val isGoogleLinked = userAccount?.hasGoogleAuth == true
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isGoogleLinked) Color(0xFFE8F0FE) else tokens.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isGoogleLinked) Color(0xFF4285F4) else tokens.cardBorder),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.toggleLinkGoogle(
                                                    googleId = "goog_" + (prefs.activeUserEmail.ifBlank { activeUid }).hashCode(),
                                                    email = prefs.activeUserEmail
                                                )
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text("🔵 Google", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4285F4))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isGoogleLinked) "🟢" else "⚪",
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    // Facebook Badge
                                    val isFbLinked = userAccount?.hasFacebookAuth == true
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isFbLinked) Color(0xFFE7F3FF) else tokens.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isFbLinked) Color(0xFF1877F2) else tokens.cardBorder),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.toggleLinkFacebook(
                                                    facebookId = "fb_" + (prefs.activeUserEmail.ifBlank { activeUid }).hashCode(),
                                                    email = prefs.activeUserEmail
                                                )
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text("🔷 FB", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1877F2))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isFbLinked) "🟢" else "⚪",
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    // Email Badge
                                    val isEmailLinked = userAccount?.hasEmailAuth != false
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = tokens.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text("✉️ Email", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isEmailLinked) "🟢" else "⚪",
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Sync Success Toast/Banner
                        syncMsg?.let { msg ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFE8F5E9),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            ) {
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        // Sync & Account Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.syncDataNow() },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                                enabled = !isSyncing
                            ) {
                                if (isSyncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = Color.White,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.CloudSync, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("مزامنة الآن", fontWeight = FontWeight.Bold)
                                }
                            }

                            OutlinedButton(
                                onClick = { viewModel.signOutUser() },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Logout, contentDescription = null, tint = tokens.error)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تسجيل الخروج", fontWeight = FontWeight.Bold, color = tokens.error)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Delete Account Text Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            TextButton(onClick = { showDeleteConfirmDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.DeleteForever,
                                    contentDescription = null,
                                    tint = tokens.error.copy(alpha = 0.8f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "حذف الحساب نهائيًا المسجل بـ $activeUid",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = tokens.error.copy(alpha = 0.8f),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }
                    }
                }

                // Delete Account Confirmation Dialog
                if (showDeleteConfirmDialog) {
                    AlertDialog(
                        onDismissRequest = { showDeleteConfirmDialog = false },
                        title = { Text("⚠️ هل أنت تأكد من حذف الحساب؟") },
                        text = {
                            Text(
                                "سيتم مسح جميع بيانات الحساب الحالية (الأدوية، سجل الجرعات، مواعيد الأطباء، ورعاية العائلة) بشكل نهائي ولا يمكن استعادتها.",
                                color = tokens.textPrimary
                            )
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    showDeleteConfirmDialog = false
                                    viewModel.deleteAccount()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.error)
                            ) {
                                Text("تأكيد الحذف النهائي", fontWeight = FontWeight.Bold)
                            }
                        },
                        dismissButton = {
                            OutlinedButton(onClick = { showDeleteConfirmDialog = false }) {
                                Text("إلغاء")
                            }
                        }
                    )
                }
            }

            // Theme Engine Selector (5 Themes)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "🎨 محرك المظاهر المخصص (𝐌𝐑𝟕 Theme Engine)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        Text(
                            text = "اختر المظهر الأنسب لعينيك وراحتك البصرية",
                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary),
                            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                        )

                        val themes = AppThemeMode.values()
                        themes.forEach { mode ->
                            val isSelected = prefs.currentTheme == mode
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { prefs.updateTheme(mode) }
                                    .border(
                                        if (isSelected) 2.dp else 1.dp,
                                        if (isSelected) tokens.primary else tokens.cardBorder,
                                        RoundedCornerShape(14.dp)
                                    ),
                                color = if (isSelected) tokens.primary.copy(alpha = 0.1f) else tokens.surfaceElevated
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(mode.iconRes, fontSize = 20.sp)
                                        Text(
                                            text = mode.titleAr,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = tokens.textPrimary
                                            )
                                        )
                                    }

                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = tokens.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Senior Mode Switch Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = tokens.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("🧓", fontSize = 22.sp)
                                }
                            }

                            Column {
                                Text(
                                    text = "وضع كبار السن (Senior Mode)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "تكبير النصوص، زيادة التباين، وأزرار ضخمة وسهلة الاستخدام",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }

                        Switch(
                            checked = prefs.isSeniorMode,
                            onCheckedChange = { prefs.toggleSeniorMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = tokens.primary),
                            modifier = Modifier.testTag("senior_mode_switch")
                        )
                    }
                }
            }

            // Onboarding Guide Preview Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { prefs.resetOnboardingSeen() },
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = androidx.compose.foundation.shape.CircleShape,
                                color = tokens.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("✨", fontSize = 22.sp)
                                }
                            }

                            Column {
                                Text(
                                    text = "عرض دليل مميزات التطبيق (Onboarding)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "استعراض الجولة التعريفية والمميزات الأربعة الرائعة للتطبيق",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = tokens.primary
                        )
                    }
                }
            }

            // PIN Lock Security Settings Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = tokens.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = tokens.primary)
                                }
                            }

                            Column {
                                Text(
                                    text = "🔐 قفل ممرّضي (Security Lock)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = if (prefs.pinLock.isEmpty()) "غير مفعّل (اضغط للتعيين)" else "مفعّل بواسطة رمز PIN سري",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }

                        Button(
                            onClick = { showPinDialog = true },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (prefs.pinLock.isEmpty()) "تفعيل" else "تعديل")
                        }
                    }
                }
            }

            // 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 & Regional Settings Card
            item {
                val context = androidx.compose.ui.platform.LocalContext.current
                val coroutineScope = rememberCoroutineScope()
                var rivoLang by remember { mutableStateOf(prefs.rivoLanguage) }
                var rivoDialect by remember { mutableStateOf(prefs.rivoDialect) }
                var suggestedDialect by remember { mutableStateOf(prefs.rivoSuggestedDialect) }
                var rivoVoiceId by remember { mutableStateOf(prefs.rivoVoiceId) }
                var rivoRate by remember { mutableFloatStateOf(prefs.rivoSpeechRate) }
                var rivoVol by remember { mutableFloatStateOf(prefs.rivoVolume) }
                var countryName by remember { mutableStateOf(prefs.userCountryName) }
                var timezoneId by remember { mutableStateOf(prefs.userTimezoneId) }
                var use24h by remember { mutableStateOf(prefs.use24HourFormat) }
                var datePattern by remember { mutableStateOf(prefs.dateFormatPattern) }

                val applyDetectedLocation: () -> Unit = {
                    coroutineScope.launch {
                        val suggestion = com.example.data.LocationLocaleManager.detectRegionalSuggestion(context)
                        suggestedDialect = suggestion.suggestedDialect
                        countryName = suggestion.countryName
                        timezoneId = suggestion.timezoneId
                        use24h = suggestion.use24Hour
                        datePattern = suggestion.datePattern
                        prefs.updateSuggestedDialect(suggestion.suggestedDialect)
                        prefs.updateRegionalSettings(
                            suggestion.countryCode,
                            suggestion.countryName,
                            suggestion.timezoneId,
                            suggestion.use24Hour,
                            suggestion.datePattern
                        )
                    }
                }

                val locationLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                    androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
                ) { granted ->
                    if (granted) {
                        applyDetectedLocation()
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🎙️ المساعد الصوتي 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 والمنطقة",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "تخصيص الصوت، اللهجة، اللغة، والمنطقة الزمنية",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                            TextButton(
                                onClick = {
                                    if (com.example.ui.components.AppPermissionType.isPermissionGranted(
                                            context,
                                            android.Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    ) {
                                        applyDetectedLocation()
                                    } else {
                                        locationLauncher.launch(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                                    }
                                }
                            ) {
                                Text("تحديث من الموقع 📍", fontWeight = FontWeight.Bold, color = tokens.primary)
                            }
                        }

                        // Language Selection
                        Text("اللغة الأساسية", style = MaterialTheme.typography.labelLarge, color = tokens.textPrimary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("ar" to "العربية", "en" to "English").forEach { (code, label) ->
                                FilterChip(
                                    selected = rivoLang == code,
                                    onClick = {
                                        rivoLang = code
                                        prefs.updateRivoSettings(rivoLang, rivoDialect, rivoVoiceId, rivoRate, rivoVol)
                                    },
                                    label = { Text(label) }
                                )
                            }
                        }

                        // Dialect Selection + Suggested Dialect
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("اللهجة", style = MaterialTheme.typography.labelLarge, color = tokens.textPrimary)
                            Text(
                                text = "المقترحة لمنطقتك: ${com.example.data.LocationLocaleManager.getDialectDisplayName(suggestedDialect)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.primary
                            )
                        }
                        val dialects = listOf("EG", "SA", "AE", "JO", "MA", "MSA")
                        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(dialects.size) { idx ->
                                val d = dialects[idx]
                                FilterChip(
                                    selected = rivoDialect == d,
                                    onClick = {
                                        rivoDialect = d
                                        prefs.updateRivoSettings(rivoLang, rivoDialect, rivoVoiceId, rivoRate, rivoVol)
                                    },
                                    label = { Text(com.example.data.LocationLocaleManager.getDialectDisplayName(d)) }
                                )
                            }
                        }

                        // Voice Personas with Preview
                        Text("صوت 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎", style = MaterialTheme.typography.labelLarge, color = tokens.textPrimary)
                        com.example.ai.RivoVoicePersona.entries.forEach { persona ->
                            val isSelected = rivoVoiceId == persona.id
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        rivoVoiceId = persona.id
                                        prefs.updateRivoSettings(rivoLang, rivoDialect, rivoVoiceId, rivoRate, rivoVol)
                                        viewModel.ttsHelper.applyRivoConfig(
                                            language = rivoLang,
                                            dialect = rivoDialect,
                                            voiceId = rivoVoiceId,
                                            rate = rivoRate,
                                            volume = rivoVol
                                        )
                                    },
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) tokens.primary.copy(alpha = 0.12f) else tokens.surfaceElevated,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) tokens.primary else tokens.cardBorder
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(persona.displayNameAr, fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                        Text(persona.descriptionAr, style = MaterialTheme.typography.bodySmall, color = tokens.textSecondary)
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.ttsHelper.previewVoice(persona, rivoDialect, rivoRate) },
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("تجربة 🔊", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }

                        // Speech Rate & Volume
                        Text("سرعة النطق: ${String.format(java.util.Locale.US, "%.1fx", rivoRate)}", style = MaterialTheme.typography.labelMedium, color = tokens.textSecondary)
                        Slider(
                            value = rivoRate,
                            onValueChange = { rivoRate = it },
                            onValueChangeFinished = {
                                prefs.updateRivoSettings(rivoLang, rivoDialect, rivoVoiceId, rivoRate, rivoVol)
                                viewModel.ttsHelper.applyRivoConfig(
                                    language = rivoLang,
                                    dialect = rivoDialect,
                                    voiceId = rivoVoiceId,
                                    rate = rivoRate,
                                    volume = rivoVol
                                )
                            },
                            valueRange = 0.7f..1.4f
                        )

                        Text("مستوى الصوت: ${(rivoVol * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = tokens.textSecondary)
                        Slider(
                            value = rivoVol,
                            onValueChange = { rivoVol = it },
                            onValueChangeFinished = {
                                prefs.updateRivoSettings(rivoLang, rivoDialect, rivoVoiceId, rivoRate, rivoVol)
                                viewModel.ttsHelper.applyRivoConfig(
                                    language = rivoLang,
                                    dialect = rivoDialect,
                                    voiceId = rivoVoiceId,
                                    rate = rivoRate,
                                    volume = rivoVol
                                )
                            },
                            valueRange = 0.3f..1.0f
                        )

                        // Regional & Time Format Summary
                        HorizontalDivider(color = tokens.cardBorder)
                        Text(
                            text = "المنطقة: $countryName • المنطقة الزمنية: $timezoneId",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("نظام 24 ساعة", style = MaterialTheme.typography.bodyMedium, color = tokens.textPrimary)
                            Switch(
                                checked = use24h,
                                onCheckedChange = {
                                    use24h = it
                                    prefs.updateRegionalSettings(
                                        prefs.userCountryCode,
                                        countryName,
                                        timezoneId,
                                        use24h,
                                        datePattern
                                    )
                                }
                            )
                        }

                        // Meal Times (الإفطار، الغداء، العشاء)
                        HorizontalDivider(color = tokens.cardBorder)
                        Text(
                            text = "🍽️ مواعيد الوجبات (لتذكيرات الروشتات)",
                            style = MaterialTheme.typography.labelLarge,
                            color = tokens.textPrimary
                        )
                        var breakfast by remember { mutableStateOf(prefs.breakfastTime) }
                        var lunch by remember { mutableStateOf(prefs.lunchTime) }
                        var dinner by remember { mutableStateOf(prefs.dinnerTime) }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = breakfast,
                                onValueChange = {
                                    breakfast = it
                                    prefs.updateMealTimes(breakfast, lunch, dinner)
                                },
                                label = { Text("الإفطار", maxLines = 1) },
                                placeholder = { Text("08:00 ص") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = lunch,
                                onValueChange = {
                                    lunch = it
                                    prefs.updateMealTimes(breakfast, lunch, dinner)
                                },
                                label = { Text("الغداء", maxLines = 1) },
                                placeholder = { Text("02:00 م") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = dinner,
                                onValueChange = {
                                    dinner = it
                                    prefs.updateMealTimes(breakfast, lunch, dinner)
                                },
                                label = { Text("العشاء", maxLines = 1) },
                                placeholder = { Text("08:00 م") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Technical Support Email Button
                        HorizontalDivider(color = tokens.cardBorder)
                        var supportErrorMsg by remember { mutableStateOf<String?>(null) }
                        Button(
                            onClick = {
                                supportErrorMsg = null
                                val supportEmail = "mr7.momaredi@gmail.com"
                                val subject = Uri.encode("دعم فني – MR7 ممرضي")
                                val mailtoUri = Uri.parse("mailto:$supportEmail?subject=$subject")
                                val emailIntent = Intent(Intent.ACTION_SENDTO, mailtoUri)
                                try {
                                    context.startActivity(emailIntent)
                                } catch (_: Exception) {
                                    supportErrorMsg = "لا يوجد تطبيق بريد إلكتروني متاح على الجهاز. يمكنك مراسلتنا على: $supportEmail"
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("contact_support_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                        ) {
                            Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تواصل مع الدعم الفني", fontWeight = FontWeight.Bold)
                        }
                        if (supportErrorMsg != null) {
                            Text(
                                text = supportErrorMsg!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            // Centralized Permissions Management Card
            item {
                val context = androidx.compose.ui.platform.LocalContext.current
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "⚙️ الأذونات والخصوصية (Permissions)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "حالة صلاحيات الجهاز المستخدمة لتنبيهك والوظائف الحساسة",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                            Button(
                                onClick = { com.example.ui.components.AppPermissionType.openAppSettings(context) },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary.copy(alpha = 0.15f), contentColor = tokens.primary)
                            ) {
                                Text("إعدادات الهاتف", fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val permissionList = listOf(
                            Triple("🔔 الإشعارات والتنبيهات", android.Manifest.permission.POST_NOTIFICATIONS, "لإرسال تنبيهات الأدوية والمواعيد والمخزون"),
                            Triple("⏰ المنبهات والتذكيرات الدقيقة", android.Manifest.permission.SCHEDULE_EXACT_ALARM, "لجدولة تذكير الدواء والعيادة بالدقيقة"),
                            Triple("📷 الكاميرا", android.Manifest.permission.CAMERA, "لتصوير الروشتات ومسح رموز الربط في الرعاية"),
                            Triple("🎙️ الميكروفون", android.Manifest.permission.RECORD_AUDIO, "لاستقبال الأوامر الصوتية في 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎"),
                            Triple("📍 الموقع الجغرافي (اختياري)", android.Manifest.permission.ACCESS_COARSE_LOCATION, "لاقتراح اللغة واللهجة والمنطقة الزمنية وتنسيق التاريخ والوقت")
                        )

                        permissionList.forEach { (name, permissionString, desc) ->
                            val isGranted = remember(refreshTrigger) {
                                when (permissionString) {
                                    android.Manifest.permission.SCHEDULE_EXACT_ALARM -> {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                            val alarmManager = context.getSystemService(android.content.Context.ALARM_SERVICE) as? android.app.AlarmManager
                                            alarmManager?.canScheduleExactAlarms() == true
                                        } else {
                                            true
                                        }
                                    }
                                    else -> com.example.ui.components.AppPermissionType.isPermissionGranted(context, permissionString)
                                }
                            }
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(14.dp),
                                color = if (isGranted) tokens.surfaceElevated else tokens.warning.copy(alpha = 0.1f),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isGranted) tokens.cardBorder else tokens.warning.copy(alpha = 0.4f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                        Text(
                                            text = name,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = tokens.textPrimary,
                                                fontSize = if (isSenior) 17.sp else 15.sp
                                            )
                                        )
                                        Text(
                                            text = desc,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = tokens.textSecondary,
                                                fontSize = if (isSenior) 13.sp else 12.sp
                                            )
                                        )
                                    }

                                    if (isGranted) {
                                        Surface(
                                            shape = RoundedCornerShape(20.dp),
                                            color = Color(0xFFE8F5E9)
                                        ) {
                                            Text(
                                                text = "مسموح 🟢",
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF2E7D32)
                                                ),
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    } else {
                                        Button(
                                            onClick = {
                                                if (permissionString == android.Manifest.permission.SCHEDULE_EXACT_ALARM && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                                    try {
                                                        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                                            data = Uri.parse("package:${context.packageName}")
                                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                                        }
                                                        context.startActivity(intent)
                                                    } catch (e: Exception) {
                                                        com.example.ui.components.AppPermissionType.openAppSettings(context)
                                                    }
                                                } else {
                                                    permissionLauncher.launch(permissionString)
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                                            shape = RoundedCornerShape(12.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Text(
                                                text = "تفعيل ⚡",
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Allergy Profile Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⚠️ حساسياتي الطبية (Allergies)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                            IconButton(onClick = { showAddAllergyDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = tokens.primary)
                            }
                        }

                        if (allergies.isEmpty()) {
                            Text(
                                text = "لا توجد حساسيات مسجلة.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary)
                            )
                        } else {
                            allergies.forEach { allergy ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    color = tokens.warning.copy(alpha = 0.12f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = allergy.allergyName,
                                                style = MaterialTheme.typography.bodyLarge.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = tokens.textPrimary
                                                )
                                            )
                                            Text(
                                                text = "الشدة: ${allergy.severity} | ${allergy.notes}",
                                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                            )
                                        }

                                        Row {
                                            IconButton(onClick = { editingAllergy = allergy }) {
                                                Icon(Icons.Default.Edit, contentDescription = "تعديل الحساسية", tint = tokens.primary)
                                            }
                                            IconButton(onClick = { viewModel.deleteAllergy(allergy) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "حذف الحساسية", tint = tokens.error)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // About 𝐌𝐑𝟕 ممرّضي Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = tokens.primary.copy(alpha = 0.12f),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "𝐌𝐑𝟕",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Black,
                                        color = tokens.primary,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "𝐌𝐑𝟕 ممرّضي",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        Text(
                            text = "منظومة 𝐌𝐑𝟕 الذكية المتكاملة — الإصدار 1.1",
                            style = MaterialTheme.typography.labelMedium.copy(color = tokens.primary, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تطبيق صحي معتمد لتنظيم مواعيد الأدوية والعيادات، قراءة الروشتات بالذكاء الاصطناعي 𝐌𝐑𝟕 Vision، والمساعد الصوتي 𝐌𝐑𝟕 Voice، وحماية خصوصية بياناتك.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = tokens.textSecondary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        )
                    }
                }
            }
        }
    }

    // Set Security PIN Dialog
    if (showPinDialog) {
        var pinText by remember { mutableStateOf(prefs.pinLock) }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("🔐 تعيين رمز PIN للقفل") },
            text = {
                Column {
                    Text("أدخل رمز PIN مكون من 4 أرقام لحماية تطبيقك:")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = pinText,
                        onValueChange = { if (it.length <= 4) pinText = it },
                        label = { Text("رمز PIN (مثال: 1234)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    prefs.setPinLockCode(pinText)
                    showPinDialog = false
                }) {
                    Text("حفظ الرمز")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    prefs.setPinLockCode("")
                    showPinDialog = false
                }) {
                    Text("إلغاء القفل")
                }
            }
        )
    }

    // Add Allergy Dialog
    if (showAddAllergyDialog) {
        var allergyName by remember { mutableStateOf("") }
        var severity by remember { mutableStateOf("عالية") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddAllergyDialog = false },
            title = { Text("⚠️ إضافة حساسية طبية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = allergyName, onValueChange = { allergyName = it }, label = { Text("اسم المادة/الدواء (مثل البنسلين)") })
                    OutlinedTextField(value = severity, onValueChange = { severity = it }, label = { Text("درجة الشدة (عالية، متوسطة...)") })
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات والأعراض") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (allergyName.isNotBlank()) {
                        viewModel.addAllergy(AllergyEntity(allergyName = allergyName, severity = severity, notes = notes))
                        showAddAllergyDialog = false
                    }
                }) {
                    Text("حفظ الحساسية")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAllergyDialog = false }) { Text("إلغاء") }
            }
        )
    }

    // Edit Allergy Dialog
    editingAllergy?.let { targetAllergy ->
        var editName by remember(targetAllergy.id) { mutableStateOf(targetAllergy.allergyName) }
        var editSeverity by remember(targetAllergy.id) { mutableStateOf(targetAllergy.severity) }
        var editNotes by remember(targetAllergy.id) { mutableStateOf(targetAllergy.notes) }
        AlertDialog(
            onDismissRequest = { editingAllergy = null },
            title = { Text("✏️ تعديل الحساسية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("اسم الحساسية") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editSeverity,
                        onValueChange = { editSeverity = it },
                        label = { Text("الشدة (خفيفة / متوسطة / شديدة)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editNotes,
                        onValueChange = { editNotes = it },
                        label = { Text("ملاحظات") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isNotBlank()) {
                            viewModel.updateAllergy(
                                targetAllergy.copy(
                                    allergyName = editName.trim(),
                                    severity = editSeverity.trim().ifBlank { "متوسطة" },
                                    notes = editNotes.trim()
                                )
                            )
                            editingAllergy = null
                        }
                    }
                ) {
                    Text("حفظ التعديل")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingAllergy = null }) { Text("إلغاء") }
            }
        )
    }
}
