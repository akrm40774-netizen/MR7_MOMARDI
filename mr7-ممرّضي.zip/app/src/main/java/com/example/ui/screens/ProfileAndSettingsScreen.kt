package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SuperAdminConfig
import com.example.data.local.AllergyEntity
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileAndSettingsScreen(
    viewModel: MainViewModel,
    onNavigateToAdmin: (() -> Unit)? = null
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    val prefs = viewModel.userPreferences
    val allergies by viewModel.allAllergies.collectAsState()
    val isSuperAdmin = viewModel.isSuperAdmin

    var userNameInput by remember { mutableStateOf(prefs.userName) }
    var pinInput by remember { mutableStateOf(prefs.pinLock) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showAddAllergyDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        // Top Header
        Surface(
            color = tokens.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "⚙️ الإعدادات والهوية — Profile & Theme",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    )
                )
                Text(
                    text = "مظاهر التطبيق، وضع كبار السن، الأمان وحساسياتك",
                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Super Admin Section (👑 إدارة التطبيق) - Visible ONLY to Super Admin
            if (isSuperAdmin) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToAdmin?.invoke() }
                            .testTag("super_admin_dashboard_card"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(46.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("👑", fontSize = 24.sp)
                                    }
                                }
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = "👑 إدارة التطبيق",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = "إدارة المستخدمين وإعدادات التطبيق الإدارية",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
            // User Account & Data Card (👤 حسابي ومزامنة البيانات)
            item {
                val isSyncing by viewModel.isSyncing.collectAsState()
                val syncMsg by viewModel.syncSuccessMessage.collectAsState()
                val activeUid = viewModel.currentUserId.collectAsState().value
                var showDeleteConfirmDialog by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "👤 حسابي وحفظ البيانات",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary,
                                        fontSize = if (isSenior) 19.sp else 16.sp
                                    )
                                )
                                Text(
                                    text = "إدارة هويتك، المزامنة، وتسجيل الخروج",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xFFE8F5E9)
                            ) {
                                Text(
                                    text = "🟢 متصل ومزامن",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2E7D32)
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // User Details Box
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = tokens.surfaceElevated,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val userAccount by viewModel.currentUserAccount.collectAsState()
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Badge,
                                        contentDescription = null,
                                        tint = tokens.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = prefs.userName,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = tokens.textPrimary
                                        )
                                    )
                                }

                                if (prefs.activeUserEmail.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "البريد: ${prefs.activeUserEmail}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                    )
                                }

                                if (prefs.userBirthDate.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "🎂 الميلاد: ${prefs.userBirthDate}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                    )
                                }

                                Row(
                                    modifier = Modifier.padding(top = 6.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (prefs.hasRegularMeds) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = tokens.primary.copy(alpha = 0.12f)
                                        ) {
                                            Text(
                                                text = "💊 أدوية منتظمة",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = tokens.primary,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    if (prefs.hasRegularAppointments) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = tokens.primary.copy(alpha = 0.12f)
                                        ) {
                                            Text(
                                                text = "🩺 مواعيد منتظمة",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = tokens.primary,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = tokens.primary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "User ID: $activeUid",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = tokens.primary,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = tokens.cardBorder, thickness = 1.dp)
                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "🔗 طرق تسجيل الدخول المرتبطة بالحساب:",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                // Linked Auth Badges
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Google Badge
                                    val isGoogleLinked = userAccount?.hasGoogleAuth == true
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isGoogleLinked) Color(0xFFE8F0FE) else tokens.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isGoogleLinked) Color(0xFF4285F4) else tokens.cardBorder),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.toggleLinkGoogle(
                                                    googleId = "goog_" + (prefs.activeUserEmail.ifBlank { activeUid }).hashCode(),
                                                    email = prefs.activeUserEmail
                                                )
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text("🔵 Google", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4285F4))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isGoogleLinked) "🟢" else "⚪",
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    // Facebook Badge
                                    val isFbLinked = userAccount?.hasFacebookAuth == true
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isFbLinked) Color(0xFFE7F3FF) else tokens.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isFbLinked) Color(0xFF1877F2) else tokens.cardBorder),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                viewModel.toggleLinkFacebook(
                                                    facebookId = "fb_" + (prefs.activeUserEmail.ifBlank { activeUid }).hashCode(),
                                                    email = prefs.activeUserEmail
                                                )
                                            }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text("🔷 FB", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1877F2))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isFbLinked) "🟢" else "⚪",
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    // Email Badge
                                    val isEmailLinked = userAccount?.hasEmailAuth != false
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = tokens.surface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Text("✉️ Email", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isEmailLinked) "🟢" else "⚪",
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Sync Success Toast/Banner
                        syncMsg?.let { msg ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFE8F5E9),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            ) {
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        // Sync & Account Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.syncDataNow() },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                                enabled = !isSyncing
                            ) {
                                if (isSyncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = Color.White,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.CloudSync, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("مزامنة الآن", fontWeight = FontWeight.Bold)
                                }
                            }

                            OutlinedButton(
                                onClick = { viewModel.signOutUser() },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Logout, contentDescription = null, tint = tokens.error)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تسجيل الخروج", fontWeight = FontWeight.Bold, color = tokens.error)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Delete Account Text Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            TextButton(onClick = { showDeleteConfirmDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.DeleteForever,
                                    contentDescription = null,
                                    tint = tokens.error.copy(alpha = 0.8f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "حذف الحساب نهائيًا المسجل بـ $activeUid",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = tokens.error.copy(alpha = 0.8f),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }
                    }
                }

                // Delete Account Confirmation Dialog
                if (showDeleteConfirmDialog) {
                    AlertDialog(
                        onDismissRequest = { showDeleteConfirmDialog = false },
                        title = { Text("⚠️ هل أنت تأكد من حذف الحساب؟") },
                        text = {
                            Text(
                                "سيتم مسح جميع بيانات الحساب الحالية (الأدوية، سجل الجرعات، مواعيد الأطباء، ورعاية العائلة) بشكل نهائي ولا يمكن استعادتها.",
                                color = tokens.textPrimary
                            )
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    showDeleteConfirmDialog = false
                                    viewModel.deleteAccount()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.error)
                            ) {
                                Text("تأكيد الحذف النهائي", fontWeight = FontWeight.Bold)
                            }
                        },
                        dismissButton = {
                            OutlinedButton(onClick = { showDeleteConfirmDialog = false }) {
                                Text("إلغاء")
                            }
                        }
                    )
                }
            }

            // Theme Engine Selector (5 Themes)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "🎨 محرك المظاهر المخصص (MR7 Theme Engine)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        Text(
                            text = "اختر المظهر الأنسب لعينيك وراحتك البصرية",
                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary),
                            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                        )

                        val themes = AppThemeMode.values()
                        themes.forEach { mode ->
                            val isSelected = prefs.currentTheme == mode
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { prefs.updateTheme(mode) }
                                    .border(
                                        if (isSelected) 2.dp else 1.dp,
                                        if (isSelected) tokens.primary else tokens.cardBorder,
                                        RoundedCornerShape(14.dp)
                                    ),
                                color = if (isSelected) tokens.primary.copy(alpha = 0.1f) else tokens.surfaceElevated
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(mode.iconRes, fontSize = 20.sp)
                                        Text(
                                            text = mode.titleAr,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = tokens.textPrimary
                                            )
                                        )
                                    }

                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = tokens.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Senior Mode Switch Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = tokens.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("🧓", fontSize = 22.sp)
                                }
                            }

                            Column {
                                Text(
                                    text = "وضع كبار السن (Senior Mode)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "تكبير النصوص، زيادة التباين، وأزرار ضخمة وسهلة الاستخدام",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }

                        Switch(
                            checked = prefs.isSeniorMode,
                            onCheckedChange = { prefs.toggleSeniorMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = tokens.primary),
                            modifier = Modifier.testTag("senior_mode_switch")
                        )
                    }
                }
            }

            // Onboarding Guide Preview Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { prefs.resetOnboardingSeen() },
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = androidx.compose.foundation.shape.CircleShape,
                                color = tokens.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("✨", fontSize = 22.sp)
                                }
                            }

                            Column {
                                Text(
                                    text = "عرض دليل مميزات التطبيق (Onboarding)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "استعراض الجولة التعريفية والمميزات الأربعة الرائعة للتطبيق",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = tokens.primary
                        )
                    }
                }
            }

            // PIN Lock Security Settings Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = tokens.primary.copy(alpha = 0.12f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = tokens.primary)
                                }
                            }

                            Column {
                                Text(
                                    text = "🔐 قفل ممرّضي (Security Lock)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = if (prefs.pinLock.isEmpty()) "غير مفعّل (اضغط للتعيين)" else "مفعّل بواسطة رمز PIN سري",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }

                        Button(
                            onClick = { showPinDialog = true },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (prefs.pinLock.isEmpty()) "تفعيل" else "تعديل")
                        }
                    }
                }
            }

            // Centralized Permissions Management Card
            item {
                val context = androidx.compose.ui.platform.LocalContext.current
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "⚙️ الأذونات والخصوصية (Permissions)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "حالة صلاحيات الجهاز المستخدمة لتنبيهك والوظائف الحساسة",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                            Button(
                                onClick = { com.example.ui.components.AppPermissionType.openAppSettings(context) },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary.copy(alpha = 0.15f), contentColor = tokens.primary)
                            ) {
                                Text("إعدادات الهاتف", fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        val permissionList = listOf(
                            Triple("🔔 الإشعارات والتنبيهات", android.Manifest.permission.POST_NOTIFICATIONS, "لإرسال تنبيهات الأدوية والمواعيد والمخزون"),
                            Triple("⏰ المنبهات والتذكيرات الدقيقة", android.Manifest.permission.SCHEDULE_EXACT_ALARM, "لجدولة تذكير الدواء والعيادة بالدقيقة"),
                            Triple("📷 الكاميرا", android.Manifest.permission.CAMERA, "لتصوير الروشتات ومسح رموز الربط في الرعاية"),
                            Triple("🎙️ الميكروفون", android.Manifest.permission.RECORD_AUDIO, "لاستقبال الأوامر الصوتية في MR7 Voice")
                        )

                        permissionList.forEach { (name, permissionString, desc) ->
                            val isGranted = com.example.ui.components.AppPermissionType.isPermissionGranted(context, permissionString)
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(14.dp)),
                                color = if (isGranted) tokens.surfaceElevated else tokens.warning.copy(alpha = 0.1f),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isGranted) tokens.cardBorder else tokens.warning.copy(alpha = 0.4f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = name,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = tokens.textPrimary,
                                                fontSize = if (isSenior) 17.sp else 15.sp
                                            )
                                        )
                                        Text(
                                            text = desc,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = tokens.textSecondary,
                                                fontSize = if (isSenior) 13.sp else 12.sp
                                            )
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(20.dp),
                                        color = if (isGranted) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                                    ) {
                                        Text(
                                            text = if (isGranted) "مسموح 🟢" else "غير مسموح 🔴",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isGranted) Color(0xFF2E7D32) else Color(0xFFC62828)
                                            ),
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Allergy Profile Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⚠️ حساسياتي الطبية (Allergies)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                            IconButton(onClick = { showAddAllergyDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = tokens.primary)
                            }
                        }

                        if (allergies.isEmpty()) {
                            Text(
                                text = "لا توجد حساسيات مسجلة.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary)
                            )
                        } else {
                            allergies.forEach { allergy ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(12.dp)),
                                    color = tokens.warning.copy(alpha = 0.12f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = allergy.allergyName,
                                                style = MaterialTheme.typography.bodyLarge.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = tokens.textPrimary
                                                )
                                            )
                                            Text(
                                                text = "الشدة: ${allergy.severity} | ${allergy.notes}",
                                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                            )
                                        }

                                        IconButton(onClick = { viewModel.deleteAllergy(allergy) }) {
                                            Icon(Icons.Default.Delete, contentDescription = null, tint = tokens.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Set Security PIN Dialog
    if (showPinDialog) {
        var pinText by remember { mutableStateOf(prefs.pinLock) }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("🔐 تعيين رمز PIN للقفل") },
            text = {
                Column {
                    Text("أدخل رمز PIN مكون من 4 أرقام لحماية تطبيقك:")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = pinText,
                        onValueChange = { if (it.length <= 4) pinText = it },
                        label = { Text("رمز PIN (مثال: 1234)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    prefs.setPinLockCode(pinText)
                    showPinDialog = false
                }) {
                    Text("حفظ الرمز")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    prefs.setPinLockCode("")
                    showPinDialog = false
                }) {
                    Text("إلغاء القفل")
                }
            }
        )
    }

    // Add Allergy Dialog
    if (showAddAllergyDialog) {
        var allergyName by remember { mutableStateOf("") }
        var severity by remember { mutableStateOf("عالية") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddAllergyDialog = false },
            title = { Text("⚠️ إضافة حساسية طبية") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = allergyName, onValueChange = { allergyName = it }, label = { Text("اسم المادة/الدواء (مثل البنسلين)") })
                    OutlinedTextField(value = severity, onValueChange = { severity = it }, label = { Text("درجة الشدة (عالية، متوسطة...)") })
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات والأعراض") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (allergyName.isNotBlank()) {
                        viewModel.addAllergy(AllergyEntity(allergyName = allergyName, severity = severity, notes = notes))
                        showAddAllergyDialog = false
                    }
                }) {
                    Text("حفظ الحساسية")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAllergyDialog = false }) { Text("إلغاء") }
            }
        )
    }
}
