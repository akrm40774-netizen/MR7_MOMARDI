package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DoseLogEntity
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToVision: () -> Unit,
    onNavigateToMeds: () -> Unit,
    onNavigateToAppointments: () -> Unit,
    onNavigateToCare: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    val userName = viewModel.userPreferences.userName
    val todayDoses by viewModel.todayDoseLogs.collectAsState()
    val upcomingApps by viewModel.upcomingAppointments.collectAsState()
    val whatShouldIDoNow by viewModel.whatShouldIDoNowSummary.collectAsState()

    var showAddMedDialog by remember { mutableStateOf(false) }

    val nextPendingDose = todayDoses.find { it.status == "PENDING" || it.status == "SNOOZED" }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(tokens.background)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Header: Title "𝐌𝐑𝟕 ممرّضي" + Settings Icon in Top Right
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .testTag("home_header_card"),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "𝐌𝐑𝟕 ممرّضي",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.primary
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("👋", fontSize = 22.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "أهلاً بك، $userName — كيف يمكن لممرّضي مساعدتك اليوم؟",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = tokens.textSecondary,
                                    fontWeight = FontWeight.Normal
                                )
                            )
                        }

                        IconButton(
                            onClick = onNavigateToSettings,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(tokens.surfaceElevated)
                                .testTag("home_settings_icon_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات",
                                tint = tokens.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            // 🩺 Widget: «التالي في ممرضي»
            item {
                NextInMr7Widget(
                    upcomingAppointments = upcomingApps,
                    todayDoses = todayDoses,
                    onNavigateToAppointments = onNavigateToAppointments,
                    onConfirmDose = { logId -> viewModel.confirmDose(logId) }
                )
            }

            // "🩺 ماذا عليّ الآن؟" Action Summary
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { viewModel.computeWhatShouldIDoNow() }
                        .testTag("what_should_i_do_button"),
                    colors = CardDefaults.cardColors(
                        containerColor = tokens.primary.copy(alpha = 0.08f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = tokens.primary,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.MedicalServices,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "🩺 ماذا عليّ الآن؟",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.primary
                                    )
                                )
                                Text(
                                    text = "اضغط لتجميع أهم الجرعات والمواعيد الحالية",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ChevronLeft,
                            contentDescription = "عرض",
                            tint = tokens.primary
                        )
                    }

                    AnimatedVisibility(
                        visible = whatShouldIDoNow != null,
                        enter = expandVertically(),
                        exit = shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(tokens.surface)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = whatShouldIDoNow ?: "",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = tokens.textPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            TextButton(
                                onClick = { viewModel.dismissWhatShouldIDoNow() },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("إغلاق التلخيص", color = tokens.primary)
                            }
                        }
                    }
                }
            }

            // Visual Shortcuts Grid in User Requested Exact RTL Order:
            // Row 1: Right = 💊 أدويتي | Left = 📷 MR7 Vision
            // Row 2: Right = 📅 مواعيدي | Left = 👥 الرعاية
            item {
                Column {
                    Text(
                        text = "⚡ الاختصارات الرئيسية",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        ),
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    // Row 1: In RTL Compose, 1st child is Right, 2nd child is Left
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        QuickActionCard(
                            title = "💊 أدويتي",
                            subtitle = "جدول الأدوية والمخزون",
                            icon = Icons.Default.Medication,
                            badgeColor = tokens.primary,
                            onClick = onNavigateToMeds,
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionCard(
                            title = "📷 𝐌𝐑𝟕 Vision",
                            subtitle = "قراءة الروشتة/العبوة",
                            icon = Icons.Default.CameraAlt,
                            badgeColor = Color(0xFF00897B),
                            onClick = onNavigateToVision,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 2: In RTL Compose, 1st child is Right, 2nd child is Left
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        QuickActionCard(
                            title = "📅 مواعيدي",
                            subtitle = "الأطباء والاستشارات",
                            icon = Icons.Default.Event,
                            badgeColor = Color(0xFF7C4DFF),
                            onClick = onNavigateToAppointments,
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionCard(
                            title = "👥 الرعاية",
                            subtitle = "متابعة العائلة",
                            icon = Icons.Default.People,
                            badgeColor = tokens.secondary,
                            onClick = onNavigateToCare,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // 🔔 Next Dose Card (Featured)
            item {
                Column {
                    Text(
                        text = "🔔 الجرعة القادمة",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    if (nextPendingDose != null) {
                        NextDoseCard(
                            doseLog = nextPendingDose,
                            onConfirm = { viewModel.confirmDose(nextPendingDose.id) },
                            onSnooze = { viewModel.snoozeDose(nextPendingDose.id) }
                        )
                    } else {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = tokens.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = tokens.success,
                                    modifier = Modifier.size(36.dp)
                                )
                                Column {
                                    Text(
                                        text = "جميع الجرعات الحالية مؤكدة ✓",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = tokens.textPrimary
                                        )
                                    )
                                    Text(
                                        text = "لا توجد جرعات معلقة في هذا الوقت",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Today Command Center Timeline
            item {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🩺 مركز اليوم — Today Command Center",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        Text(
                            text = "جدول اليوم",
                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                        )
                    }
                }
            }

            // Today Timeline Items
            if (todayDoses.isEmpty() && upcomingApps.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد أحداث مسجلة لليوم حتى الآن.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary),
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            } else {
                items(todayDoses) { dose ->
                    TimelineDoseItem(
                        doseLog = dose,
                        onConfirm = { viewModel.confirmDose(dose.id) }
                    )
                }

                items(upcomingApps) { app ->
                    TimelineAppointmentItem(
                        doctorName = app.doctorName,
                        timeDisplay = app.timeDisplay,
                        notes = app.notes
                    )
                }
            }
        }

        // Section 4: Floating Action Button (FAB) at Bottom Right of Home Screen
        FloatingActionButton(
            onClick = { showAddMedDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 16.dp, end = 16.dp)
                .testTag("add_med_fab"),
            shape = CircleShape,
            containerColor = tokens.primary,
            contentColor = Color.White,
            elevation = FloatingActionButtonDefaults.elevation(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة دواء",
                modifier = Modifier.size(28.dp)
            )
        }
    }

    if (showAddMedDialog) {
        AddMedicationDialog(
            onDismiss = { showAddMedDialog = false },
            onConfirm = { newMed ->
                viewModel.addMedication(newMed)
                showAddMedDialog = false
            },
            onNavigateToVision = {
                showAddMedDialog = false
                onNavigateToVision()
            }
        )
    }
}

@Composable
fun NextDoseCard(
    doseLog: DoseLogEntity,
    onConfirm: () -> Unit,
    onSnooze: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .testTag("next_dose_card"),
        colors = CardDefaults.cardColors(containerColor = tokens.primary),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = "🔔 الجرعة القادمة",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = doseLog.medicationName,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "كبسولة واحدة • بعد الطعام",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = doseLog.scheduledTime,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Light,
                            color = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onConfirm,
                    modifier = Modifier
                        .weight(1f)
                        .height(if (isSenior) 56.dp else 48.dp)
                        .testTag("confirm_dose_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = tokens.primary
                    )
                ) {
                    Text("تم التأكيد ✓", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onSnooze,
                    modifier = Modifier
                        .weight(1f)
                        .height(if (isSenior) 56.dp else 48.dp)
                        .testTag("snooze_dose_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.25f),
                        contentColor = Color.White
                    )
                ) {
                    Text("تأجيل", fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current

    Card(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = tokens.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = badgeColor.copy(alpha = 0.15f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                )
            }
        }
    }
}

@Composable
fun TimelineDoseItem(
    doseLog: DoseLogEntity,
    onConfirm: () -> Unit
) {
    val tokens = LocalThemeTokens.current

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, tokens.cardBorder, RoundedCornerShape(16.dp)),
        color = tokens.surface
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = tokens.primary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = doseLog.scheduledTime,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = tokens.primary,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Column {
                    Text(
                        text = "💊 ${doseLog.medicationName}",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )
                    Text(
                        text = when (doseLog.status) {
                            "CONFIRMED" -> "✅ تم تأكيد الجرعة"
                            "SNOOZED" -> "⏰ جرعة مؤجلة"
                            else -> "🔔 جرعة قادمة"
                        },
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = when (doseLog.status) {
                                "CONFIRMED" -> tokens.success
                                "SNOOZED" -> tokens.warning
                                else -> tokens.textSecondary
                            }
                        )
                    )
                }
            }

            if (doseLog.status != "CONFIRMED") {
                IconButton(onClick = onConfirm) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "تأكيد الجرعة",
                        tint = tokens.success
                    )
                }
            }
        }
    }
}

@Composable
fun TimelineAppointmentItem(
    doctorName: String,
    timeDisplay: String,
    notes: String
) {
    val tokens = LocalThemeTokens.current

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF7C4DFF).copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
        color = Color(0xFF7C4DFF).copy(alpha = 0.05f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF7C4DFF).copy(alpha = 0.2f)
                ) {
                    Text(
                        text = timeDisplay,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color(0xFF7C4DFF),
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Column {
                    Text(
                        text = "🩺 موعد طبيب: $doctorName",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )
                    Text(
                        text = if (notes.isBlank()) "مراجعة عيادة الطبيب" else notes,
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                    )
                }
            }
        }
    }
}

@Composable
fun NextInMr7Widget(
    upcomingAppointments: List<com.example.data.local.AppointmentEntity>,
    todayDoses: List<DoseLogEntity>,
    onNavigateToAppointments: () -> Unit,
    onConfirmDose: (Long) -> Unit
) {
    val tokens = LocalThemeTokens.current

    val nextApp = upcomingAppointments.firstOrNull { !it.isCompleted }
    val nextDose = todayDoses.firstOrNull { it.status == "PENDING" || it.status == "SNOOZED" }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("next_in_mr7_widget"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                nextApp != null -> tokens.primary.copy(alpha = 0.09f)
                nextDose != null -> tokens.secondary.copy(alpha = 0.09f)
                else -> Color(0xFFE8F5E9)
            }
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            when {
                nextApp != null -> tokens.primary.copy(alpha = 0.35f)
                nextDose != null -> tokens.secondary.copy(alpha = 0.35f)
                else -> Color(0xFFA5D6A7)
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Widget Header Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("🩺", fontSize = 18.sp)
                    Text(
                        text = "التالي في ممرضي",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = when {
                        nextApp != null -> tokens.primary
                        nextDose != null -> tokens.secondary
                        else -> Color(0xFF2E7D32)
                    }
                ) {
                    Text(
                        text = when {
                            nextApp != null -> "👨‍⚕️ موعد طبيب"
                            nextDose != null -> "💊 جرعة دواء"
                            else -> "💚 هادئ"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.5f))

            when {
                // 1️⃣ Priority 1: Upcoming Doctor Appointment
                nextApp != null -> {
                    val remainingText = calculateRemainingTimeText(nextApp.appointmentTimeMillis, nextApp.dateDisplay, nextApp.timeDisplay)

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = nextApp.doctorName,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                if (nextApp.specialty.isNotBlank()) {
                                    Text(
                                        text = "التخصص: ${nextApp.specialty}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = tokens.primary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = remainingText,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.primary
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp), tint = tokens.primary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${nextApp.dateDisplay} — ${nextApp.timeDisplay}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                )
                            }
                            if (nextApp.clinicAddress.isNotBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp), tint = tokens.textSecondary)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = nextApp.clinicAddress,
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = onNavigateToAppointments,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فتح تفاصيل الموعد", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // 2️⃣ Priority 2: Next Medication Dose
                nextDose != null -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = nextDose.medicationName,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "موعد الجرعة اليوم: ${nextDose.scheduledTime}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = tokens.secondary.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = "موعد الجرعة: ${nextDose.scheduledTime}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.secondary
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Button(
                            onClick = { onConfirmDose(nextDose.id) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.secondary)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("أخذ الجرعة الآن", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // 3️⃣ Priority 3: All Quiet
                else -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("💚", fontSize = 28.sp)
                        Column {
                            Text(
                                text = "كل شيء هادئ الآن",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B5E20)
                                )
                            )
                            Text(
                                text = "لا توجد جرعات قادمة.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

fun calculateRemainingTimeText(targetMillis: Long, dateDisplay: String, timeDisplay: String): String {
    val now = System.currentTimeMillis()
    val diffMs = targetMillis - now
    if (diffMs <= 0) {
        return "الموعد الآن ($timeDisplay)"
    }
    val minutes = (diffMs / (1000 * 60)) % 60
    val hours = diffMs / (1000 * 60 * 60)

    return when {
        hours == 0L && minutes <= 15L -> "موعد قريب جداً (بعد $minutes دقيقة)"
        hours == 0L -> "متبقي $minutes دقيقة"
        hours < 24L -> "متبقي $hours ساعة و $minutes دقيقة"
        else -> "$dateDisplay ($timeDisplay)"
    }
}
