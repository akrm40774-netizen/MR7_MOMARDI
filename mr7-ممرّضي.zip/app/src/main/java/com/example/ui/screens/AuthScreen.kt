package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

private enum class AuthFormMode {
    CHOOSE_METHOD,
    EMAIL_FORM
}

@Composable
fun AuthScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current
    val isSenior = viewModel.userPreferences.isSeniorMode
    val authError by viewModel.authError.collectAsState()
    val isLoading by viewModel.isAuthLoading.collectAsState()

    var isSignUpTab by remember { mutableStateOf(false) }
    var activeFormMode by remember { mutableStateOf(AuthFormMode.CHOOSE_METHOD) }

    // Email Input fields
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    // Dialogs
    var showGoogleDialog by remember { mutableStateOf(false) }
    var showFacebookDialog by remember { mutableStateOf(false) }
    var showForgotPasswordDialog by remember { mutableStateOf(false) }

    // Custom Google / FB input states
    var customGoogleEmail by remember { mutableStateOf("") }
    var customGoogleName by remember { mutableStateOf("") }
    var customFbEmail by remember { mutableStateOf("") }
    var customFbName by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // App Brand Header
            Surface(
                shape = CircleShape,
                color = tokens.primary.copy(alpha = 0.15f),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = null,
                        tint = tokens.primary,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "𝐌𝐑𝟕 ممرّضي 🎩",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = tokens.textPrimary,
                    fontSize = if (isSenior) 32.sp else 26.sp
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "نظام الحسابات الآمنة وحفظ البيانات المستقلة",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = tokens.textSecondary,
                    fontSize = if (isSenior) 16.sp else 14.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Main Auth Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = tokens.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Auth Tab Switcher (Sign In vs Sign Up)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(tokens.surfaceElevated)
                            .padding(4.dp)
                    ) {
                        Button(
                            onClick = {
                                isSignUpTab = false
                                viewModel.clearAuthError()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isSignUpTab) tokens.primary else Color.Transparent,
                                contentColor = if (!isSignUpTab) Color.White else tokens.textSecondary
                            ),
                            elevation = null
                        ) {
                            Text(
                                "تسجيل الدخول",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 17.sp else 14.sp
                            )
                        }

                        Button(
                            onClick = {
                                isSignUpTab = true
                                viewModel.clearAuthError()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSignUpTab) tokens.primary else Color.Transparent,
                                contentColor = if (isSignUpTab) Color.White else tokens.textSecondary
                            ),
                            elevation = null
                        ) {
                            Text(
                                "إنشاء حساب جديد",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 17.sp else 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = if (!isSignUpTab) "👤 تسجيل الدخول إلى 𝐌𝐑𝟕 ممرّضي" else "🆕 إنشاء حساب في 𝐌𝐑𝟕 ممرّضي",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary,
                            fontSize = if (isSenior) 20.sp else 17.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Error Banner if present
                    authError?.let { err ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.error.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, tokens.error.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = tokens.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = err,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = tokens.error,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }
                    }

                    // 1. Google Official Button
                    OutlinedButton(
                        onClick = { showGoogleDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.White,
                            contentColor = Color(0xFF1F1F1F)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDADCE0)),
                        enabled = !isLoading
                    ) {
                        GoogleLogoIcon(modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (!isSignUpTab) "🔵 متابعة باستخدام Google" else "🔵 إنشاء حساب باستخدام Google",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 15.sp,
                            color = Color(0xFF3C4043)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. Facebook Official Button
                    Button(
                        onClick = { showFacebookDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1877F2),
                            contentColor = Color.White
                        ),
                        enabled = !isLoading
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "f",
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1877F2),
                                    fontSize = 17.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (!isSignUpTab) "🔷 متابعة باستخدام Facebook" else "🔷 إنشاء حساب باستخدام Facebook",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 15.sp,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 3. Email Button (Toggle Email Form)
                    Button(
                        onClick = {
                            activeFormMode = if (activeFormMode == AuthFormMode.EMAIL_FORM) AuthFormMode.CHOOSE_METHOD else AuthFormMode.EMAIL_FORM
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = tokens.surfaceElevated,
                            contentColor = tokens.textPrimary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                        enabled = !isLoading
                    ) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = null,
                            tint = tokens.primary
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (!isSignUpTab) "✉️ المتابعة باستخدام البريد الإلكتروني" else "✉️ إنشاء حساب باستخدام البريد الإلكتروني",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 15.sp,
                            color = tokens.textPrimary
                        )
                    }

                    // Expanded Email Form
                    AnimatedVisibility(
                        visible = activeFormMode == AuthFormMode.EMAIL_FORM,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp)
                        ) {
                            Divider(color = tokens.cardBorder, thickness = 1.dp)
                            Spacer(modifier = Modifier.height(16.dp))

                            if (isSignUpTab) {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    label = { Text("الاسم بالكامل (أو صلة القرابة)") },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                            }

                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = { emailInput = it },
                                label = { Text("البريد الإلكتروني") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text("كلمة المرور") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null
                                        )
                                    }
                                },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )

                            if (isSignUpTab) {
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = confirmPasswordInput,
                                    onValueChange = { confirmPasswordInput = it },
                                    label = { Text("تأكيد كلمة المرور") },
                                    leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null) },
                                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                                )
                            }

                            if (!isSignUpTab) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(onClick = { showForgotPasswordDialog = true }) {
                                        Text(
                                            "نسيت كلمة المرور؟",
                                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.primary)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action Button for Email Auth
                            Button(
                                onClick = {
                                    if (isSignUpTab) {
                                        if (passwordInput != confirmPasswordInput) {
                                            return@Button
                                        }
                                        viewModel.signUpUser(nameInput, emailInput, passwordInput)
                                    } else {
                                        viewModel.signInUser(emailInput, passwordInput)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                                enabled = !isLoading
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(22.dp),
                                        color = Color.White,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (isSignUpTab) Icons.Default.PersonAdd else Icons.Default.Login,
                                        contentDescription = null
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isSignUpTab) "إنشاء الحساب ومتابعة" else "تسجيل الدخول بالبريد",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = if (isSenior) 17.sp else 15.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quick Demo Login Button
                    OutlinedButton(
                        onClick = { viewModel.quickDemoLogin() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                        enabled = !isLoading
                    ) {
                        Icon(Icons.Default.FlashOn, contentDescription = null, tint = tokens.secondary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "⚡ الدخول التجريبي السريع (Demo)",
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Security Note Badge
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.surfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = tokens.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "🔒 ربط تلقائي آمن: الدخول بـ Google أو Facebook أو البريد يرتبط بنظام حساب واحد (User ID واحد) بدون بيانات مكررة.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = tokens.textSecondary,
                            fontSize = if (isSenior) 13.sp else 11.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // --- DIALOG 1: Google Native Account Selector ---
        if (showGoogleDialog) {
            AlertDialog(
                onDismissRequest = { showGoogleDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GoogleLogoIcon(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("متابعة باستخدام Google")
                    }
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "اختر حساب Google للمتابعة بأمان وسرعة:",
                            style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textPrimary)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Account 1 (Preset)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.surfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showGoogleDialog = false
                                    viewModel.signInWithGoogle(
                                        email = "jffhyfvg@gmail.com",
                                        name = "مستخدم Google الرئيسي",
                                        googleId = "goog_9948210"
                                    )
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = CircleShape, color = tokens.primary.copy(alpha = 0.2f), modifier = Modifier.size(36.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("G", fontWeight = FontWeight.Bold, color = tokens.primary)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("مستخدم Google الرئيسي", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("jffhyfvg@gmail.com", style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Account 2 (Preset)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.surfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showGoogleDialog = false
                                    viewModel.signInWithGoogle(
                                        email = "family.mr7@gmail.com",
                                        name = "أحمد علي - عائلة ممرّضي",
                                        googleId = "goog_8820391"
                                    )
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = CircleShape, color = Color(0xFF4285F4), modifier = Modifier.size(36.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("أ", fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("أحمد علي", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("family.mr7@gmail.com", style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text("أو أدخل بريد Google الخاص بك:", style = MaterialTheme.typography.labelMedium.copy(color = tokens.textSecondary))
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = customGoogleEmail,
                            onValueChange = { customGoogleEmail = it },
                            label = { Text("البريد الإلكتروني لـ Google") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (customGoogleEmail.isNotBlank()) {
                                showGoogleDialog = false
                                viewModel.signInWithGoogle(
                                    email = customGoogleEmail,
                                    name = customGoogleEmail.substringBefore("@").replace(".", " "),
                                    googleId = "goog_" + customGoogleEmail.hashCode()
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4))
                    ) {
                        Text("متابعة", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { showGoogleDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // --- DIALOG 2: Facebook Native Account Selector ---
        if (showFacebookDialog) {
            AlertDialog(
                onDismissRequest = { showFacebookDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = Color(0xFF1877F2), modifier = Modifier.size(24.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("f", fontWeight = FontWeight.Black, color = Color.White, fontSize = 16.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("متابعة باستخدام Facebook")
                    }
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "تسجيل الدخول الآمن عبر تطبيق Facebook:",
                            style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textPrimary)
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Preset FB Profile
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.surfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showFacebookDialog = false
                                    viewModel.signInWithFacebook(
                                        email = "jffhyfvg@gmail.com",
                                        name = "أحمد علي (Facebook Profile)",
                                        facebookId = "fb_7739102"
                                    )
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = CircleShape, color = Color(0xFF1877F2), modifier = Modifier.size(36.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("أحمد علي (Facebook)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("مرتبط ببريد jffhyfvg@gmail.com", style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text("أو أدخل بريد/رقم حساب Facebook:", style = MaterialTheme.typography.labelMedium.copy(color = tokens.textSecondary))
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = customFbEmail,
                            onValueChange = { customFbEmail = it },
                            label = { Text("البريد أو معرف Facebook") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (customFbEmail.isNotBlank()) {
                                showFacebookDialog = false
                                viewModel.signInWithFacebook(
                                    email = customFbEmail,
                                    name = "مستخدم Facebook",
                                    facebookId = "fb_" + customFbEmail.hashCode()
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1877F2))
                    ) {
                        Text("متابعة", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { showFacebookDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // --- DIALOG 3: Forgot Password ---
        if (showForgotPasswordDialog) {
            AlertDialog(
                onDismissRequest = { showForgotPasswordDialog = false },
                title = { Text("🔑 استعادة كلمة المرور") },
                text = {
                    Text(
                        "في تطبيق MR7 ممرّضي، يمكنك استعادة الوصول إلى حسابك بسهولة عبر إدخال بريدك الإلكتروني لتعيين كلمة مرور جديدة أو تسجيل الدخول بـ Google/Facebook إذا كنت قد ربطت حسابك سابقًا.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textPrimary)
                    )
                },
                confirmButton = {
                    Button(onClick = { showForgotPasswordDialog = false }) {
                        Text("حسناً")
                    }
                }
            )
        }
    }
}

@Composable
fun GoogleLogoIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Simple official 4-color Google G icon vector representation
        // Top Red segment
        drawCircle(color = Color(0xFFEA4335), radius = w / 2f)
        // Right Blue segment
        drawPath(
            path = Path().apply {
                moveTo(w / 2f, h / 2f)
                lineTo(w, h / 2f)
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(0f, 0f, w, h),
                    startAngleDegrees = 0f,
                    sweepAngleDegrees = 90f,
                    forceMoveTo = false
                )
                close()
            },
            color = Color(0xFF4285F4)
        )
        // Bottom Green segment
        drawPath(
            path = Path().apply {
                moveTo(w / 2f, h / 2f)
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(0f, 0f, w, h),
                    startAngleDegrees = 90f,
                    sweepAngleDegrees = 90f,
                    forceMoveTo = false
                )
                close()
            },
            color = Color(0xFF34A853)
        )
        // Left Yellow segment
        drawPath(
            path = Path().apply {
                moveTo(w / 2f, h / 2f)
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(0f, 0f, w, h),
                    startAngleDegrees = 180f,
                    sweepAngleDegrees = 90f,
                    forceMoveTo = false
                )
                close()
            },
            color = Color(0xFFFBBC05)
        )
        // Center cutout white
        drawCircle(color = Color.White, radius = w * 0.28f)
    }
}
