package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens

enum class AppPermissionType(
    val permissionString: String,
    val titleAr: String,
    val iconEmoji: String,
    val rationaleText: String
) {
    CAMERA(
        permissionString = Manifest.permission.CAMERA,
        titleAr = "إذن الكاميرا",
        iconEmoji = "📷",
        rationaleText = "نحتاج إلى الكاميرا لتصوير الروشتة/علبة الدواء ومسح رمز الربط في ميزات الرعاية."
    ),
    MICROPHONE(
        permissionString = Manifest.permission.RECORD_AUDIO,
        titleAr = "إذن الميكروفون",
        iconEmoji = "🎙️",
        rationaleText = "نحتاج إلى الميكروفون لاستقبال أوامرك الصوتية في MR7 Voice وتحويلها لنص وفهم طلبك."
    ),
    NOTIFICATIONS(
        permissionString = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.POST_NOTIFICATIONS else "",
        titleAr = "إذن الإشعارات",
        iconEmoji = "🔔",
        rationaleText = "نحتاج إذن الإشعارات لإرسال التنبيهات المهمة لمواعيد الأدوية وقرب انتهاء المخزون ومواعيد الأطباء."
    );

    companion object {
        fun isPermissionGranted(context: Context, permission: String): Boolean {
            if (permission.isEmpty()) return true
            return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        }

        fun openAppSettings(context: Context) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }
}

@Composable
fun ContextualPermissionRequester(
    permissionType: AppPermissionType,
    showRationale: Boolean,
    onDismiss: () -> Unit,
    onPermissionGranted: () -> Unit
) {
    val context = LocalContext.current
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    var isDeniedBefore by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onPermissionGranted()
            onDismiss()
        } else {
            isDeniedBefore = true
        }
    }

    if (showRationale) {
        val isGrantedAlready = AppPermissionType.isPermissionGranted(context, permissionType.permissionString)
        if (isGrantedAlready) {
            LaunchedEffect(Unit) {
                onPermissionGranted()
                onDismiss()
            }
            return
        }

        AlertDialog(
            onDismissRequest = onDismiss,
            shape = RoundedCornerShape(24.dp),
            containerColor = tokens.surface,
            icon = {
                Surface(
                    shape = CircleShape,
                    color = tokens.primary.copy(alpha = 0.12f),
                    modifier = Modifier.size(if (isSenior) 64.dp else 52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(permissionType.iconEmoji, fontSize = if (isSenior) 32.sp else 24.sp)
                    }
                }
            },
            title = {
                Text(
                    text = permissionType.titleAr,
                    style = if (isSenior) MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            else MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = tokens.textPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = permissionType.rationaleText,
                        style = if (isSenior) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.bodyMedium,
                        color = tokens.textSecondary,
                        textAlign = TextAlign.Center
                    )

                    if (isDeniedBefore) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.warning.copy(alpha = 0.15f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "يبدو أن الإذن مرفوض. يمكنك تفعيله يدويًا من إعدادات الهاتف لتشغيل هذه الميزة.",
                                style = MaterialTheme.typography.bodySmall.copy(color = tokens.textPrimary, fontWeight = FontWeight.Medium),
                                modifier = Modifier.padding(10.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isDeniedBefore) {
                            AppPermissionType.openAppSettings(context)
                            onDismiss()
                        } else {
                            if (permissionType.permissionString.isNotEmpty()) {
                                launcher.launch(permissionType.permissionString)
                            } else {
                                onPermissionGranted()
                                onDismiss()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (isSenior) 54.dp else 46.dp)
                        .testTag("permission_confirm_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                ) {
                    Text(
                        text = if (isDeniedBefore) "فتح إعدادات الهاتف ⚙️" else "موافق وتفعيل الإذن 🟢",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 18.sp else 15.sp
                        )
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (isSenior) 50.dp else 42.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = "ليس الآن",
                        style = MaterialTheme.typography.labelMedium.copy(fontSize = if (isSenior) 16.sp else 14.sp)
                    )
                }
            }
        )
    }
}
