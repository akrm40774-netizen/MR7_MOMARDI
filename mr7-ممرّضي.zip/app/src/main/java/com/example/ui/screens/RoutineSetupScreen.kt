package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.UserPreferences
import com.example.ui.theme.LocalThemeTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutineSetupScreen(
    userPreferences: UserPreferences,
    onRoutineSetupFinished: () -> Unit
) {
    val tokens = LocalThemeTokens.current

    // Tracking states
    var isMedsTracked by remember { mutableStateOf(userPreferences.routineMedsTracked) }
    var isVitalsTracked by remember { mutableStateOf(userPreferences.routineVitalsTracked) }
    var isActivitiesTracked by remember { mutableStateOf(userPreferences.routineActivitiesTracked) }
    var isMoodAndSymptomsTracked by remember { mutableStateOf(userPreferences.routineMoodAndSymptomsTracked) }

    // Medication First Dose Time State
    var selectedMedTime by remember { mutableStateOf(userPreferences.medFirstTime.ifBlank { "8:00 ص" }) }
    var showMedTimeDialog by remember { mutableStateOf(false) }

    // Selected Vitals State
    val allVitalsList = remember {
        listOf(
            "ضغط الدم", "معدل ضربات القلب عند الراحة", "الوزن", "سكر الدم قبل الوجبة",
            "نسبة السكر في الدم بعد الوجبة", "درجة الحرارة", "تردد النفس", "تريودوثيرونين (fT3)",
            "تشبع الأكسجين", "حجم التنفس", "حمض اليوريك", "خلايا CD4",
            "ذروة معدل التدفق الزفيري (PEFR)", "غاما-غلوتاميل ترانسفيراز (GGT)", "الكالسيوم", "الكرياتينين",
            "الكولسترول", "الكولسترول الضار LDL", "الكوليسترول الحميد HDL", "اللاكتات",
            "النيكوتين", "الهيموغلوبين (HbA1)", "الهيموغلوبين الغليكي (HbA1C)", "بيلة سكرية",
            "فصادة", "فيتامين د", "قيمة INR", "كثافة العظام",
            "كيناز الكرياتين", "محيط الخصر", "محيط الصدر", "محيط منتصف الذراع العلوي",
            "محيط منتصف الفخذ", "مستضد خاص بالبروستاتا (PSA)", "مستوى الكحول", "مستوى الليثيوم",
            "معدل الاستقلاب الأساسي (BMR)", "معدل الترشيح الكبيبي (GFR)", "نسبة الدهون في الجسم", "نسبة الماء في الجسم",
            "هرمون الغدة الدرقية (FT4)", "هرمون الغدة الدرقية (TSH)", "الأسبارتات (ASAT)", "الألانين أمينوترانسفيراز (ALAT)",
            "البروتين الدهني (Lp)", "Apolipoprotein B (Apo B)"
        ).distinct()
    }
    var selectedVitals by remember {
        mutableStateOf(
            userPreferences.selectedVitalsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
                .ifEmpty { setOf("ضغط الدم", "سكر الدم قبل الوجبة", "الوزن") }
        )
    }
    var showVitalsSheet by remember { mutableStateOf(false) }

    // Selected Activities State
    val allActivitiesList = remember {
        listOf(
            "كمية الماء", "المشي", "المشي الشمالي (النورديك)", "تدريبات العين",
            "تدريبات القوة", "تدريبات اللياقة", "تدريبات البطن", "تدريبات التنفس",
            "تمرين وظيفي", "تمتد", "تمارين الاسترخاء", "تدليك",
            "تزلج", "تلوين", "ناول السكر", "تناول الكافيين",
            "دش بارد", "دعاء", "رقص", "ركوب الخيل",
            "ركوب الدراجة", "رياضة الغولف", "رياضة بدنية", "رياضة للرئة",
            "زراعة الحدائق", "ساونا", "سباحة", "تنس",
            "تنس الريشة", "تنس طاولة", "تنظيف الأسنان", "تنظيف المنزل",
            "حقيبة فغر القولون", "حلق", "دراجة بيضاوية الشكل", "لعبة البولنج",
            "لعبة الرشق بالسهام", "لياقة أكوا", "نائم", "وقت العائلة",
            "وقت لزوجي", "وقت لنفسي", "يتناول الطعام", "يجلس",
            "سياج", "صعود الدرج", "علاج وظيفي", "قراءة",
            "كرة القدم", "كرة سلة", "كرة يد", "كمادات ساخنة / باردة",
            "الوقوف", "CPAP", "إبحار", "إعادة تأهيل",
            "اتصال اجتماعي", "اختبار روفير ديكسون", "اسكواش", "أسمع أغاني",
            "الاستحمام", "الاستلقاء", "البولينج", "التأمل",
            "التجديف", "التحفيز الكهربائي للأعصاب عبر الجلد (TENS)", "التحفيز الكهربائي للعضلات", "الحارس الليلي للأسنان",
            "الدوران", "الريكي", "العلاج الطبيعي", "العلاج النفسي",
            "العلاج بالإبر", "العلاج بالتبريد", "العلاج بالحركة", "الغناء",
            "الفنون العسكرية", "الكرة الطائرة", "اليوغا", "بيلاتيس",
            "تاي تشي"
        ).distinct()
    }
    var selectedActivities by remember {
        mutableStateOf(
            userPreferences.selectedActivitiesCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
                .ifEmpty { setOf("كمية الماء", "المشي", "تنظيف الأسنان") }
        )
    }
    var showActivitiesSheet by remember { mutableStateOf(false) }

    var showWarningBanner by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        tokens.background,
                        tokens.surfaceElevated.copy(alpha = 0.85f),
                        tokens.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("routine_setup_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Revo Mascot Header Avatar
            Surface(
                modifier = Modifier
                    .size(80.dp)
                    .shadow(12.dp, shape = CircleShape, spotColor = tokens.primary.copy(alpha = 0.2f))
                    .border(2.dp, tokens.primary.copy(alpha = 0.2f), CircleShape),
                shape = CircleShape,
                color = Color.White
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = R.drawable.onboarding_revo_ai),
                        contentDescription = "ريڤو المساعد الذكي",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Screen Title
            Text(
                text = "دعونا نضع روتينك!",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = tokens.textPrimary,
                    fontSize = 24.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Screen Subtitle
            Text(
                text = "اختر ما تريد متابعته لنساعدك على بناء روتين صحي يناسبك.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = tokens.textSecondary,
                    lineHeight = 22.sp,
                    fontSize = 14.sp
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Warning banner if nothing selected
            AnimatedVisibility(visible = showWarningBanner) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.error.copy(alpha = 0.1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.error.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = tokens.error
                        )
                        Text(
                            text = "يرجى تفعيل قسم واحد على الأقل لنساعدك في تخصيص روتينك اليومي 😊",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = tokens.textPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            // 💊 1. الأدوية (Medications Card)
            MainRoutineSectionCard(
                iconEmoji = "💊",
                title = "الأدوية",
                description = "متابعة الأدوية وتنظيمها وتسجيل مواعيدها.",
                subtitleBadge = if (isMedsTracked) "الموعد الأول: $selectedMedTime" else "غير مفعّل",
                actionLabel = "تعديل الموعد 🕐",
                isSelected = isMedsTracked,
                onToggle = {
                    isMedsTracked = !isMedsTracked
                    showWarningBanner = false
                },
                onActionClick = { showMedTimeDialog = true },
                testTag = "meds_section_card"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 🩸 2. القياسات (Vitals Card)
            MainRoutineSectionCard(
                iconEmoji = "🩸",
                title = "القياسات",
                description = "تسجيل ومتابعة القياسات الصحية مثل السكر والضغط.",
                subtitleBadge = if (isVitalsTracked) "تم اختيار ${selectedVitals.size} قياسات" else "غير مفعّل",
                actionLabel = "تخصيص القياسات 🔎",
                isSelected = isVitalsTracked,
                onToggle = {
                    isVitalsTracked = !isVitalsTracked
                    showWarningBanner = false
                },
                onActionClick = { showVitalsSheet = true },
                testTag = "vitals_section_card"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 💧 3. الأنشطة (Activities Card)
            MainRoutineSectionCard(
                iconEmoji = "💧",
                title = "الأنشطة",
                description = "متابعة الأنشطة والعادات اليومية مثل شرب الماء والمشي.",
                subtitleBadge = if (isActivitiesTracked) "تم اختيار ${selectedActivities.size} أنشطة" else "غير مفعّل",
                actionLabel = "تخصيص الأنشطة 🔎",
                isSelected = isActivitiesTracked,
                onToggle = {
                    isActivitiesTracked = !isActivitiesTracked
                    showWarningBanner = false
                },
                onActionClick = { showActivitiesSheet = true },
                testTag = "activities_section_card"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 😊 4. المزاج والأعراض (Mood & Symptoms Card - ONE combined section)
            MainRoutineSectionCard(
                iconEmoji = "😊",
                title = "المزاج والأعراض",
                description = "تسجيل ومتابعة الحالة المزاجية وتغيراتها وتتبع أي أعراض صحية طارئة.",
                subtitleBadge = if (isMoodAndSymptomsTracked) "متابعة المزاج والأعراض مفعّلة" else "غير مفعّل",
                actionLabel = null,
                isSelected = isMoodAndSymptomsTracked,
                onToggle = {
                    isMoodAndSymptomsTracked = !isMoodAndSymptomsTracked
                    showWarningBanner = false
                },
                onActionClick = null,
                testTag = "mood_symptoms_section_card"
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Primary Action Button ("متابعة")
            Button(
                onClick = {
                    if (!isMedsTracked && !isVitalsTracked && !isActivitiesTracked && !isMoodAndSymptomsTracked) {
                        showWarningBanner = true
                    } else {
                        userPreferences.completeRoutineSetup(
                            medsTracked = isMedsTracked,
                            vitalsTracked = isVitalsTracked,
                            activitiesTracked = isActivitiesTracked,
                            moodAndSymptomsTracked = isMoodAndSymptomsTracked,
                            firstMedTime = selectedMedTime,
                            vitalsCsv = selectedVitals.joinToString(","),
                            activitiesCsv = selectedActivities.joinToString(",")
                        )
                        onRoutineSetupFinished()
                    }
                },
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                contentPadding = PaddingValues(vertical = 16.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("routine_setup_continue_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "متابعة",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // --- DIALOG: Medication Time Picker (الموعد المعتاد لتناول دوائك الأول؟) ---
        if (showMedTimeDialog) {
            MedicationTimePickerDialog(
                currentTime = selectedMedTime,
                onTimeSelected = { newTime ->
                    selectedMedTime = newTime
                    isMedsTracked = true
                    showMedTimeDialog = false
                },
                onDismiss = { showMedTimeDialog = false }
            )
        }

        // --- SHEET: Vitals Search & Selection ---
        if (showVitalsSheet) {
            MultiSelectSearchSheet(
                title = "🩸 اختيارات القياسات الصحية",
                subtitle = "حدد القياسات التي ترغب في متابعتها بانتظام",
                searchPlaceholder = "🔎 بحث في القياسات...",
                allItems = allVitalsList,
                selectedItems = selectedVitals,
                onSelectionChanged = { newSet ->
                    selectedVitals = newSet
                    if (newSet.isNotEmpty()) isVitalsTracked = true
                },
                onDismiss = { showVitalsSheet = false }
            )
        }

        // --- SHEET: Activities Search & Selection ---
        if (showActivitiesSheet) {
            MultiSelectSearchSheet(
                title = "💧 اختيارات الأنشطة والعادات",
                subtitle = "حدد الأنشطة اليومية والتمارين التي تريد تتبعها",
                searchPlaceholder = "🔎 بحث في الأنشطة...",
                allItems = allActivitiesList,
                selectedItems = selectedActivities,
                onSelectionChanged = { newSet ->
                    selectedActivities = newSet
                    if (newSet.isNotEmpty()) isActivitiesTracked = true
                },
                onDismiss = { showActivitiesSheet = false }
            )
        }
    }
}

@Composable
private fun MainRoutineSectionCard(
    iconEmoji: String,
    title: String,
    description: String,
    subtitleBadge: String,
    actionLabel: String?,
    isSelected: Boolean,
    onToggle: () -> Unit,
    onActionClick: (() -> Unit)?,
    testTag: String
) {
    val tokens = LocalThemeTokens.current

    val containerColor by animateColorAsState(
        targetValue = if (isSelected) tokens.primary.copy(alpha = 0.1f) else tokens.surface,
        animationSpec = tween(250),
        label = "card_container_color"
    )

    val borderColor by animateColorAsState(
        targetValue = if (isSelected) tokens.primary else tokens.primary.copy(alpha = 0.18f),
        animationSpec = tween(250),
        label = "card_border_color"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = borderColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Emoji Icon Container
                Surface(
                    shape = CircleShape,
                    color = if (isSelected) tokens.primary.copy(alpha = 0.2f) else tokens.surfaceElevated,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = iconEmoji, fontSize = 22.sp)
                    }
                }

                // Title & Subtitle Badge
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary,
                            fontSize = 17.sp
                        )
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) tokens.primary.copy(alpha = 0.15f) else tokens.surfaceElevated
                    ) {
                        Text(
                            text = subtitleBadge,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) tokens.primary else tokens.textSecondary
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                // Selection Checkbox Badge
                Surface(
                    shape = CircleShape,
                    color = if (isSelected) tokens.primary else tokens.surfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 0.dp else 1.5.dp,
                        color = if (isSelected) Color.Transparent else tokens.cardBorder
                    ),
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = tokens.textSecondary,
                    lineHeight = 18.sp
                )
            )

            // Optional Sub-action link (e.g. "تعديل الموعد 🕐" or "تخصيص القياسات 🔎")
            if (isSelected && actionLabel != null && onActionClick != null) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onActionClick() },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = actionLabel,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.primary
                        )
                    )
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = tokens.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * Dialog for Medication First Dose Time selection
 * Question: "ما هو الموعد المعتاد لتناول دوائك الأول؟"
 * Preset choices: 6:00 ص, 7:00 ص, 8:00 ص, 9:00 ص, 10:00 ص, 11:00 ص
 * Plus: "وقت مخصص" allowing custom hour/minute and ص/م input.
 */
@Composable
private fun MedicationTimePickerDialog(
    currentTime: String,
    onTimeSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val presets = remember { listOf("6:00 ص", "7:00 ص", "8:00 ص", "9:00 ص", "10:00 ص", "11:00 ص") }

    var isCustomMode by remember { mutableStateOf(!presets.contains(currentTime)) }
    var selectedPreset by remember { mutableStateOf(if (presets.contains(currentTime)) currentTime else "8:00 ص") }

    var customHour by remember { mutableStateOf("08") }
    var customMinute by remember { mutableStateOf("00") }
    var customPeriod by remember { mutableStateOf("ص") }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val finalTime = if (isCustomMode) {
                        val h = customHour.trim().ifBlank { "8" }
                        val m = customMinute.trim().ifBlank { "00" }.padStart(2, '0')
                        "$h:$m $customPeriod"
                    } else {
                        selectedPreset
                    }
                    onTimeSelected(finalTime)
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
            ) {
                Text("تأكيد الموعد 🎯", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = tokens.textSecondary)
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("💊", fontSize = 20.sp)
                Text(
                    text = "موعد الدواء الأول",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary
                    )
                )
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "ما هو الموعد المعتاد لتناول دوائك الأول؟",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = tokens.textSecondary,
                        fontWeight = FontWeight.Medium
                    )
                )

                // Grid of 6 Preset Chips
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        presets.take(3).forEach { time ->
                            TimePresetChip(
                                timeStr = time,
                                isSelected = !isCustomMode && selectedPreset == time,
                                onClick = {
                                    isCustomMode = false
                                    selectedPreset = time
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        presets.drop(3).take(3).forEach { time ->
                            TimePresetChip(
                                timeStr = time,
                                isSelected = !isCustomMode && selectedPreset == time,
                                onClick = {
                                    isCustomMode = false
                                    selectedPreset = time
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Custom Time Option
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isCustomMode) tokens.primary.copy(alpha = 0.12f) else tokens.surfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isCustomMode) 2.dp else 1.dp,
                        color = if (isCustomMode) tokens.primary else tokens.cardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isCustomMode = true }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.AccessTime, contentDescription = null, tint = tokens.primary)
                                Text(
                                    text = "🕐 وقت مخصص",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCustomMode) tokens.primary else tokens.textPrimary
                                    )
                                )
                            }
                            if (isCustomMode) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = tokens.primary)
                            }
                        }

                        if (isCustomMode) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = customHour,
                                    onValueChange = { if (it.length <= 2) customHour = it },
                                    label = { Text("الساعة") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                Text(":", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                OutlinedTextField(
                                    value = customMinute,
                                    onValueChange = { if (it.length <= 2) customMinute = it },
                                    label = { Text("الدقيقة") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                // AM / PM Switch
                                Button(
                                    onClick = { customPeriod = if (customPeriod == "ص") "م" else "ص" },
                                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary.copy(alpha = 0.2f)),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = if (customPeriod == "ص") "صباحاً (ص)" else "مساءً (م)",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = tokens.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        shape = RoundedCornerShape(24.dp),
        containerColor = tokens.surface
    )
}

@Composable
private fun TimePresetChip(
    timeStr: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) tokens.primary else tokens.surfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) tokens.primary else tokens.cardBorder
        ),
        modifier = modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = timeStr,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else tokens.textPrimary
                )
            )
        }
    }
}

/**
 * Reusable Multi-Select Sheet with Search Bar for Vitals and Activities
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MultiSelectSearchSheet(
    title: String,
    subtitle: String,
    searchPlaceholder: String,
    allItems: List<String>,
    selectedItems: Set<String>,
    onSelectionChanged: (Set<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    var searchQuery by remember { mutableStateOf("") }

    val filteredItems = remember(searchQuery, allItems) {
        if (searchQuery.isBlank()) {
            allItems
        } else {
            val q = searchQuery.trim().lowercase()
            allItems.filter { it.lowercase().contains(q) }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = tokens.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight(0.85f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary
                        )
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = tokens.textSecondary)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 🔎 Search Bar Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(searchPlaceholder, color = tokens.textSecondary.copy(alpha = 0.6f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = tokens.primary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح", tint = tokens.textSecondary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = tokens.primary,
                    unfocusedBorderColor = tokens.cardBorder,
                    focusedContainerColor = tokens.surfaceElevated,
                    unfocusedContainerColor = tokens.surfaceElevated
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Selection Counter Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تم اختيار (${selectedItems.size}) عنصر",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.primary
                    )
                )

                if (selectedItems.isNotEmpty()) {
                    TextButton(onClick = { onSelectionChanged(emptySet()) }) {
                        Text("إلغاء تحديد الكل", style = MaterialTheme.typography.labelSmall.copy(color = tokens.error))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Scrollable List of Items
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredItems, key = { it }) { item ->
                    val isChecked = selectedItems.contains(item)
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isChecked) tokens.primary.copy(alpha = 0.12f) else tokens.surfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isChecked) 1.5.dp else 1.dp,
                            color = if (isChecked) tokens.primary else tokens.cardBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val updated = if (isChecked) {
                                    selectedItems - item
                                } else {
                                    selectedItems + item
                                }
                                onSelectionChanged(updated)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = item,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isChecked) tokens.primary else tokens.textPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    val updated = if (checked == true) {
                                        selectedItems + item
                                    } else {
                                        selectedItems - item
                                    }
                                    onSelectionChanged(updated)
                                },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = tokens.primary,
                                    uncheckedColor = tokens.cardBorder
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Done Button
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Text(
                    text = "تم الاختيار (${selectedItems.size}) ✔️",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }
    }
}
