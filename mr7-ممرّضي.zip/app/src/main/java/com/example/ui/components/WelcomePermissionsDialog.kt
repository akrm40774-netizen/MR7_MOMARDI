package com.example.ui.components

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LocationLocaleManager
import com.example.data.RegionalSuggestion
import com.example.data.UserPreferences
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import kotlinx.coroutines.launch

@Composable
fun WelcomePermissionsDialog(
    userPreferences: UserPreferences? = null,
    onDismiss: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var locationGranted by remember {
        mutableStateOf(LocationLocaleManager.hasCoarseLocationPermission(context))
    }
    var regionalSuggestion by remember { mutableStateOf<RegionalSuggestion?>(null) }

    val locationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        locationGranted = granted
        if (granted) {
            scope.launch {
                val suggestion = LocationLocaleManager.detectRegionalSuggestion(context)
                regionalSuggestion = suggestion
                userPreferences?.updateSuggestedDialect(suggestion.suggestedDialect)
                userPreferences?.updateRegionalSettings(
                    countryCode = suggestion.countryCode,
                    countryName = suggestion.countryName,
                    timezoneId = suggestion.timezoneId,
                    is24Hour = suggestion.use24Hour,
                    datePattern = suggestion.datePattern
                )
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(26.dp),
        containerColor = tokens.surface,
        icon = {
            Surface(
                shape = CircleShape,
                color = tokens.primary.copy(alpha = 0.12f),
                modifier = Modifier.size(if (isSenior) 68.dp else 56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("🔐", fontSize = if (isSenior) 34.sp else 28.sp)
                }
            }
        },
        title = {
            Text(
                text = "أهلاً بك في 𝐌𝐑𝟕 ممرّضي — الإعداد الأولي الذكي",
                style = if (isSenior) MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                else MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = tokens.textPrimary,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "لتقديم تجربة آمنة وموثوقة، يوضح التطبيق فائدة كل إذن قبل طلبه:",
                    style = if (isSenior) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.bodyMedium,
                    color = tokens.textSecondary,
                    textAlign = TextAlign.Start
                )

                // Dedicated Location Permission Section
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = tokens.primary.copy(alpha = 0.07f),
                    border = BorderStroke(1.dp, tokens.primary.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = tokens.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "إذن الموقع الجغرافي (اختياري)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                            }

                            if (locationGranted) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFE8F5E9)
                                ) {
                                    Text(
                                        text = "مفعّل 🟢",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF2E7D32)
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION) },
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier
                                        .height(32.dp)
                                        .testTag("grant_location_onboarding_button")
                                ) {
                                    Text("السماح", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Text(
                            text = "لماذا نحتاج إلى إذن الموقع؟",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.primary
                            )
                        )
                        Text(
                            text = "يساعد السماح بالوصول إلى موقعك على تحسين تجربتك داخل التطبيق، من خلال التعرّف على منطقتك واقتراح الإعدادات المحلية المناسبة، مثل اللغة الأساسية واللهجة المقترحة للمساعد الصوتي 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎، بالإضافة إلى تحديد المنطقة الزمنية المناسبة وضبط تنسيقات التاريخ والوقت وبعض الإعدادات الأخرى، للاستمتاع بتجربة أكثر توافقًا مع منطقتك واحتياجاتك.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = tokens.textSecondary,
                                lineHeight = 18.sp
                            )
                        )

                        regionalSuggestion?.let { sug ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = tokens.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(
                                        text = "📍 المنطقة: ${sug.countryName} | 🕒 ${sug.timezoneId}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = tokens.textPrimary
                                        )
                                    )
                                    Text(
                                        text = "🗣️ اللهجة المقترحة لـ 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎: ${LocationLocaleManager.getDialectDisplayName(sug.suggestedDialect)}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = tokens.primary)
                                    )
                                }
                            }
                        }
                    }
                }

                val items = listOf(
                    "🎙️ المساعد الصوتي 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 (ريڤو)" to "لسماع أسئلتك باللهجة المصرية والرد بصوت طبيعي.",
                    "💊 تذكيرات الأدوية والجرعات" to "لتنبيهك بموعد الدواء والعيادة بالضبط.",
                    "📷 تصوير الروشتة وعلبة الدواء" to "لقراءة واستخراج بيانات الدواء تلقائيًا."
                )

                items.forEach { (title, desc) ->
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = tokens.primary,
                            modifier = Modifier
                                .size(if (isSenior) 20.dp else 16.dp)
                                .padding(top = 2.dp)
                        )
                        Column {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary,
                                    fontSize = if (isSenior) 16.sp else 14.sp
                                )
                            )
                            Text(
                                text = desc,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = tokens.textSecondary,
                                    fontSize = if (isSenior) 14.sp else 12.sp
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isSenior) 54.dp else 46.dp)
                    .testTag("welcome_permissions_continue_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
            ) {
                Text(
                    text = "فهمت، متابعة 🚀",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = if (isSenior) 18.sp else 15.sp
                    )
                )
            }
        }
    )
}
