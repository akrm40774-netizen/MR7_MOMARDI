package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens

@Composable
fun WelcomePermissionsDialog(
    onDismiss: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(26.dp),
        containerColor = tokens.surface,
        icon = {
            Surface(
                shape = CircleShape,
                color = tokens.primary.copy(alpha = 0.12f),
                modifier = Modifier.size(if (isSenior) 68.dp else 56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("🔐", fontSize = if (isSenior) 34.sp else 28.sp)
                }
            }
        },
        title = {
            Text(
                text = "أهلاً بك في 𝐌𝐑𝟕 ممرّضي — الخصوصية والأذونات",
                style = if (isSenior) MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        else MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = tokens.textPrimary,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "لتقديم تجربة آمنة وموثوقة، قد يطلب التطبيق بعض صلاحيات الهاتف في سياق استخدامها فقط:",
                    style = if (isSenior) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.bodyMedium,
                    color = tokens.textSecondary,
                    textAlign = TextAlign.Start
                )

                val items = listOf(
                    "💊 تذكيرات الأدوية والجرعات" to "لتنبيهك بموعد الدواء بالضبط.",
                    "⏰ المنبهات والمواعيد" to "لتذكيرك بمواعيد عيادات الأطباء.",
                    "🔔 الإشعارات" to "لتنبيهك عند قرب انتهاء مخزون الدواء.",
                    "📷 تصوير الروشتة وعلبة الدواء" to "لقراءة واستخراج بيانات الدواء تلقائيًا.",
                    "🎙️ الأوامر الصوتية (MR7 Voice)" to "لسماع أسئلتك والرد السريع عليك.",
                    "👥 ميزات الرعاية" to "لمسح رموز الربط مع من ترعاهم."
                )

                items.forEach { (title, desc) ->
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = tokens.primary,
                            modifier = Modifier
                                .size(if (isSenior) 20.dp else 16.dp)
                                .padding(top = 2.dp)
                        )
                        Column {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary,
                                    fontSize = if (isSenior) 17.sp else 14.sp
                                )
                            )
                            Text(
                                text = desc,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = tokens.textSecondary,
                                    fontSize = if (isSenior) 14.sp else 12.sp
                                )
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = tokens.primary.copy(alpha = 0.08f),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = tokens.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "تطبيقك يحترم خصوصيتك بالكامل. لن تطلب الصلاحيات إلا فور احتياجك لها.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = tokens.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 14.sp else 12.sp
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isSenior) 56.dp else 48.dp)
                    .testTag("welcome_permissions_continue_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
            ) {
                Text(
                    text = "فهمت والمتابعة 👍",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 19.sp else 16.sp
                    )
                )
            }
        }
    )
}
