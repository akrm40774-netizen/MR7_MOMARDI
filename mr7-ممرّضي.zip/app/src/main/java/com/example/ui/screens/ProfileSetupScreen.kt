package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.UserPreferences
import com.example.ui.theme.LocalThemeTokens
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProfileSetupScreen(
    userPreferences: UserPreferences,
    onProfileSetupFinished: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val context = LocalContext.current

    val arabicMonths = remember {
        listOf(
            "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
            "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
        )
    }

    var nameInput by remember { mutableStateOf(userPreferences.userName.ifBlank { "" }) }
    var yearInput by remember { mutableStateOf("") }
    var selectedMonthIndex by remember { mutableStateOf(0) }
    var monthDropdownExpanded by remember { mutableStateOf(false) }
    var dayInput by remember { mutableStateOf("") }
    var selectedHasMeds by remember { mutableStateOf(userPreferences.hasRegularMeds) }
    var selectedHasAppointments by remember { mutableStateOf(userPreferences.hasRegularAppointments) }
    var showSuccessStep by remember { mutableStateOf(false) }

    val birthDateValidation: Pair<String, String?> = remember(yearInput, selectedMonthIndex, dayInput) {
        if (yearInput.isBlank() && dayInput.isBlank()) {
            "" to null
        } else {
            val y = yearInput.toIntOrNull()
            val d = dayInput.toIntOrNull()
            val now = Calendar.getInstance()
            val currentYear = now.get(Calendar.YEAR)
            when {
                y == null || yearInput.length != 4 || y < 1900 || y > currentYear ->
                    "" to "يرجى إدخال سنة صحيحة (من 1900 إلى $currentYear)"
                d == null || d < 1 ->
                    "" to "يرجى إدخال يوم صحيح"
                else -> {
                    val isLeap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)
                    val maxDays = when (selectedMonthIndex) {
                        1 -> if (isLeap) 29 else 28
                        3, 5, 8, 10 -> 30
                        else -> 31
                    }
                    if (d > maxDays) {
                        "" to "الشهر المختار يحتوي على $maxDays يوماً فقط"
                    } else {
                        val chosen = Calendar.getInstance().apply {
                            set(Calendar.YEAR, y)
                            set(Calendar.MONTH, selectedMonthIndex)
                            set(Calendar.DAY_OF_MONTH, d)
                            set(Calendar.HOUR_OF_DAY, 0)
                            set(Calendar.MINUTE, 0)
                            set(Calendar.SECOND, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        if (chosen.after(now)) {
                            "" to "لا يمكن إدخال تاريخ ميلاد في المستقبل"
                        } else {
                            "$d ${arabicMonths[selectedMonthIndex]} $y" to null
                        }
                    }
                }
            }
        }
    }

    val birthDateDisplay = birthDateValidation.first
    val birthDateError = birthDateValidation.second
    val isFormValid = nameInput.trim().isNotBlank() && birthDateError == null

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        tokens.background,
                        tokens.surfaceElevated.copy(alpha = 0.85f),
                        tokens.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("profile_setup_screen")
    ) {
        if (!showSuccessStep) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                // Revo Mascot Avatar & Friendly Badge
                Surface(
                    modifier = Modifier
                        .size(80.dp)
                        .shadow(12.dp, shape = CircleShape, spotColor = tokens.primary.copy(alpha = 0.2f))
                        .border(2.dp, tokens.primary.copy(alpha = 0.2f), CircleShape),
                    shape = CircleShape,
                    color = Color.White
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(id = R.drawable.onboarding_revo_ai),
                            contentDescription = "ريڤو المساعد الذكي",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Main Title
                Text(
                    text = "👤 خلّي ريڤو يتعرّف عليك",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary,
                        fontSize = 24.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Subtitle Description
                Text(
                    text = "أخبرنا ببعض المعلومات البسيطة لنساعدك على تنظيم أدويتك ومواعيدك بشكل يناسبك.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = tokens.textSecondary,
                        lineHeight = 22.sp,
                        fontSize = 14.sp
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                Spacer(modifier = Modifier.height(28.dp))

                // Field 1: Name Input (✨ اسمك)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.18f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("✨", fontSize = 18.sp)
                            Text(
                                text = "اسمك",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                        }

                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            placeholder = {
                                Text("اكتب اسمك هنا", color = tokens.textSecondary.copy(alpha = 0.6f))
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = tokens.primary)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Next
                            ),
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = tokens.primary,
                                unfocusedBorderColor = tokens.cardBorder,
                                focusedContainerColor = tokens.surfaceElevated,
                                unfocusedContainerColor = tokens.surfaceElevated
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("name_input_field")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Field 2: 3-Field RTL Birth Date Input (السنة - الشهر - اليوم)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.18f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("🎂", fontSize = 18.sp)
                            Text(
                                text = "تاريخ ميلادك",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("birth_date_selector"),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 1. السنة (Year)
                            OutlinedTextField(
                                value = yearInput,
                                onValueChange = { raw ->
                                    yearInput = raw.filter { it.isDigit() }.take(4)
                                },
                                label = { Text("السنة", maxLines = 1) },
                                placeholder = { Text("2012") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Next
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("birth_year_input")
                            )

                            // 2. الشهر (Arabic Month Dropdown)
                            @OptIn(ExperimentalMaterial3Api::class)
                            ExposedDropdownMenuBox(
                                expanded = monthDropdownExpanded,
                                onExpandedChange = { monthDropdownExpanded = !monthDropdownExpanded },
                                modifier = Modifier.weight(1.35f)
                            ) {
                                OutlinedTextField(
                                    value = arabicMonths[selectedMonthIndex],
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("الشهر", maxLines = 1) },
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = monthDropdownExpanded)
                                    },
                                    singleLine = true,
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth()
                                        .testTag("birth_month_dropdown")
                                )
                                ExposedDropdownMenu(
                                    expanded = monthDropdownExpanded,
                                    onDismissRequest = { monthDropdownExpanded = false }
                                ) {
                                    arabicMonths.forEachIndexed { index, monthName ->
                                        DropdownMenuItem(
                                            text = { Text(monthName) },
                                            onClick = {
                                                selectedMonthIndex = index
                                                monthDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // 3. اليوم (Day)
                            OutlinedTextField(
                                value = dayInput,
                                onValueChange = { raw ->
                                    dayInput = raw.filter { it.isDigit() }.take(2)
                                },
                                label = { Text("اليوم", maxLines = 1) },
                                placeholder = { Text("15") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                                modifier = Modifier
                                    .weight(0.85f)
                                    .testTag("birth_day_input")
                            )
                        }

                        if (birthDateError != null) {
                            Text(
                                text = birthDateError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Field 3: Regular Medications (💊 هل لديك أدوية منتظمة؟)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.18f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("💊", fontSize = 18.sp)
                            Text(
                                text = "هل لديك أدوية منتظمة؟",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // "نعم" Card
                            OptionCard(
                                title = "نعم",
                                isSelected = selectedHasMeds,
                                onClick = { selectedHasMeds = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("meds_option_yes")
                            )

                            // "لا" Card
                            OptionCard(
                                title = "لا",
                                isSelected = !selectedHasMeds,
                                onClick = { selectedHasMeds = false },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("meds_option_no")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Field 4: Regular Appointments (🩺 هل لديك مواعيد طبية منتظمة؟)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.18f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("🩺", fontSize = 18.sp)
                            Text(
                                text = "هل لديك مواعيد طبية منتظمة؟",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.textPrimary
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // "نعم" Card
                            OptionCard(
                                title = "نعم",
                                isSelected = selectedHasAppointments,
                                onClick = { selectedHasAppointments = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("appointments_option_yes")
                            )

                            // "لا" Card
                            OptionCard(
                                title = "لا",
                                isSelected = !selectedHasAppointments,
                                onClick = { selectedHasAppointments = false },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("appointments_option_no")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Primary Action Button (التالي →)
                Button(
                    onClick = {
                        showSuccessStep = true
                    },
                    enabled = isFormValid,
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = tokens.primary,
                        disabledContainerColor = tokens.primary.copy(alpha = 0.4f)
                    ),
                    contentPadding = PaddingValues(vertical = 16.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_setup_submit_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "التالي",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        } else {
            // Step 6 & 7: Profile Setup Success Screen
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Spacer(modifier = Modifier.height(20.dp))

                // Revo Mascot Avatar with Green Success Check Badge
                Box(contentAlignment = Alignment.BottomEnd) {
                    Surface(
                        modifier = Modifier
                            .size(100.dp)
                            .shadow(16.dp, shape = CircleShape, spotColor = tokens.primary.copy(alpha = 0.25f))
                            .border(3.dp, tokens.primary.copy(alpha = 0.25f), CircleShape),
                        shape = CircleShape,
                        color = Color.White
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Image(
                                painter = painterResource(id = R.drawable.onboarding_revo_ai),
                                contentDescription = "ريڤو المساعد الذكي",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        }
                    }

                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF4CAF50),
                        modifier = Modifier
                            .size(32.dp)
                            .border(2.dp, Color.White, CircleShape)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "🎉 تم إنشاء ملفك الشخصي بنجاح!",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = tokens.textPrimary,
                        fontSize = 22.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "أهلاً بك يا ${nameInput.trim()}! ريڤو جاهز لمساعدتك في رحلتك الصحية وتنظيم مواعيدك وأدويتك.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = tokens.textSecondary,
                        lineHeight = 22.sp,
                        fontSize = 15.sp
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Profile Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = tokens.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tokens.primary.copy(alpha = 0.18f))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "ملخص ملفك الشخصي:",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.primary
                            )
                        )

                        HorizontalDivider(color = tokens.cardBorder.copy(alpha = 0.5f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("👤 الاسم المسجل:", style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary))
                            Text(nameInput.trim(), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🎂 تاريخ الميلاد:", style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary))
                            Text(
                                if (birthDateDisplay.contains("اضغط")) "غير محدد" else birthDateDisplay,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("💊 أدوية منتظمة:", style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary))
                            Text(
                                if (selectedHasMeds) "نعم 💊" else "لا ❌",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🩺 مواعيد منتظمة:", style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary))
                            Text(
                                if (selectedHasAppointments) "نعم 🩺" else "لا ❌",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Final Action Button ("متابعة 🚀")
                Button(
                    onClick = {
                        userPreferences.completeProfileSetup(
                            name = nameInput,
                            birthDate = if (birthDateDisplay.contains("اضغط")) "" else birthDateDisplay,
                            hasMeds = selectedHasMeds,
                            hasAppointments = selectedHasAppointments
                        )
                        onProfileSetupFinished()
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                    contentPadding = PaddingValues(vertical = 16.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_success_continue_button")
                ) {
                    Text(
                        text = "متابعة 🚀",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun OptionCard(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) tokens.primary.copy(alpha = 0.12f) else tokens.surfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) tokens.primary else tokens.cardBorder
        ),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = tokens.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) tokens.primary else tokens.textPrimary
                )
            )
        }
    }
}
