package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MedicationEntity
import com.example.ui.theme.LocalSeniorMode
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicationsScreen(
    viewModel: MainViewModel,
    onNavigateToVision: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    val activeMeds by viewModel.activeMedications.collectAsState()
    val archivedMeds by viewModel.archivedMedications.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Active, 1: Archived
    var showAddDialog by remember { mutableStateOf(false) }
    var medToRefill by remember { mutableStateOf<MedicationEntity?>(null) }

    // Inventory warning check
    val lowStockMeds = activeMeds.filter { it.stockCount <= it.refillThreshold }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Screen Header
            Surface(
                color = tokens.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "💊 أدويتي — 𝐌𝐑𝟕 Medication",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        Text(
                            text = "إدارة جدول الأدوية والمخزون الذكي",
                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                        )
                    }

                    // Circular Header Add Button
                    IconButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(tokens.primary)
                            .testTag("add_medication_header_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إضافة دواء",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

        // Active / Archived Filter Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = tokens.surface,
            contentColor = tokens.primary,
            divider = { Divider(color = tokens.divider) }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Text(
                        "الأدويـة النشـطة (${activeMeds.size})",
                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                    )
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Text(
                        "العلاج المؤرشف (${archivedMeds.size})",
                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                    )
                }
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Smart Inventory Alert Banners
            if (selectedTab == 0 && lowStockMeds.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = tokens.warning.copy(alpha = 0.12f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.warning.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = tokens.warning,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "⚠️ تنبيه المخزون الذكي (Smart Stock)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.textPrimary
                                    )
                                )
                                Text(
                                    text = "المخزون المسجل لدواء (${lowStockMeds.joinToString(", ") { it.userNickname }}) قريب من النفاد وقد لا يكفي للجرعات القادمة.",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textSecondary)
                                )
                            }
                        }
                    }
                }
            }

            // Fast Camera Vision Shortcut
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onNavigateToVision() }
                        .border(1.dp, tokens.primary.copy(alpha = 0.3f), RoundedCornerShape(20.dp)),
                    color = tokens.primary.copy(alpha = 0.06f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = tokens.primary,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.CameraAlt,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "📷 قراءة روشتة أو عبوة بالكاميرا",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.primary
                                    )
                                )
                                Text(
                                    text = "استخراج اسم الدواء والجرعة تلقائياً بـ 𝐌𝐑𝟕 Vision",
                                    style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                )
                            }
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = tokens.primary)
                    }
                }
            }

            val medsList = if (selectedTab == 0) activeMeds else archivedMeds

            if (medsList.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Medication,
                                contentDescription = null,
                                tint = tokens.textSecondary.copy(alpha = 0.4f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (selectedTab == 0) "لا توجد أدوية نشطة مسجلة" else "لا توجد أدوية مؤرشفة",
                                style = MaterialTheme.typography.bodyLarge.copy(color = tokens.textSecondary)
                            )
                        }
                    }
                }
            } else {
                items(medsList) { med ->
                    MedicationItemCard(
                        medication = med,
                        onRefillStock = { medToRefill = med },
                        onArchive = { viewModel.archiveMedication(med.id) },
                        onUnarchive = { viewModel.unarchiveMedication(med.id) }
                    )
                }
            }
        }
        }

        // Circular Floating Action Button (FAB) at Bottom Right of Screen (Matching Home Screen)
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 16.dp, end = 16.dp)
                .testTag("add_medication_fab"),
            shape = CircleShape,
            containerColor = tokens.primary,
            contentColor = Color.White,
            elevation = FloatingActionButtonDefaults.elevation(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة دواء",
                modifier = Modifier.size(28.dp)
            )
        }
    }

    // Add Medication Dialog
    if (showAddDialog) {
        AddMedicationDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { newMed ->
                viewModel.addMedication(newMed)
                showAddDialog = false
            },
            onNavigateToVision = {
                showAddDialog = false
                onNavigateToVision()
            }
        )
    }

    // Refill Stock Dialog
    if (medToRefill != null) {
        val targetMed = medToRefill!!
        var addedUnits by remember { mutableStateOf("30") }

        AlertDialog(
            onDismissRequest = { medToRefill = null },
            title = { Text("➕ تجديد المخزون (إضافة علبة)") },
            text = {
                Column {
                    Text("أدخل عدد الحبات/الوحدات المضافة لـ (${targetMed.userNickname}):")
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = addedUnits,
                        onValueChange = { addedUnits = it },
                        label = { Text("عدد الوحدات") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val add = addedUnits.toIntOrNull() ?: 0
                    viewModel.updateStock(targetMed.id, targetMed.stockCount + add)
                    medToRefill = null
                }) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { medToRefill = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun MedicationItemCard(
    medication: MedicationEntity,
    onRefillStock: () -> Unit,
    onArchive: () -> Unit,
    onUnarchive: () -> Unit
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    val stockStatus = when {
        medication.stockCount <= 0 -> "🔴 نَفَد المخزون"
        medication.stockCount <= medication.refillThreshold -> "🟡 قريب من النفاد"
        else -> "🟢 كافٍ"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("medication_card_${medication.id}"),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
        colors = CardDefaults.cardColors(containerColor = tokens.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = tokens.primary.copy(alpha = 0.12f),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.MedicalInformation,
                                contentDescription = null,
                                tint = tokens.primary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = medication.userNickname,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = tokens.textPrimary
                            )
                        )
                        Text(
                            text = "الاسم العلمي: ${medication.officialName} (${medication.concentration})",
                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when {
                        medication.stockCount <= 0 -> tokens.error.copy(alpha = 0.15f)
                        medication.stockCount <= medication.refillThreshold -> tokens.warning.copy(alpha = 0.15f)
                        else -> tokens.success.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = stockStatus,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = when {
                                medication.stockCount <= 0 -> tokens.error
                                medication.stockCount <= medication.refillThreshold -> tokens.warning
                                else -> tokens.success
                            }
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(tokens.surfaceElevated)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = tokens.textSecondary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("المواعيد والتعليمات: ${medication.instructions} (${medication.timesOfDay})", style = MaterialTheme.typography.bodyMedium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Inventory2, contentDescription = null, tint = tokens.textSecondary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("المخزون المسجل: ${medication.stockCount} ${medication.form}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }

                if (medication.notes.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Notes, contentDescription = null, tint = tokens.textSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ملاحظات: ${medication.notes}", style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onRefillStock,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة علبة")
                }

                if (!medication.isArchived) {
                    TextButton(
                        onClick = onArchive,
                        colors = ButtonDefaults.textButtonColors(contentColor = tokens.textSecondary)
                    ) {
                        Icon(Icons.Default.Archive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("أرشفة العلاج")
                    }
                } else {
                    TextButton(
                        onClick = onUnarchive,
                        colors = ButtonDefaults.textButtonColors(contentColor = tokens.primary)
                    ) {
                        Icon(Icons.Default.Unarchive, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إعادة تفعيل")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddMedicationDialog(
    onDismiss: () -> Unit,
    onConfirm: (MedicationEntity) -> Unit,
    onNavigateToVision: (() -> Unit)? = null
) {
    val tokens = LocalThemeTokens.current
    val isSenior = LocalSeniorMode.current

    var officialName by remember { mutableStateOf("") }
    var userNickname by remember { mutableStateOf("") }
    var concNumber by remember { mutableStateOf("1") }
    var concUnit by remember { mutableStateOf("g") }
    var stockCountText by remember { mutableStateOf("30") }
    var notes by remember { mutableStateOf("") }

    // Selected Instruction State
    var selectedInstructionTile by remember { mutableStateOf("بعد الفطار") }
    var customInstructionText by remember { mutableStateOf("") }

    // Alarm-style Time Picker state
    var selectedHour by remember { mutableStateOf(8) }
    var selectedMinute by remember { mutableStateOf(0) }
    var isAm by remember { mutableStateOf(true) }
    var doseTimesList by remember { mutableStateOf(listOf("08:00 ص", "08:00 م")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "➕ إضافة دواء جديد",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق")
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1️⃣ 📷 تحديد بالروشتة (Top Card)
                if (onNavigateToVision != null) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToVision() }
                                .testTag("scan_prescription_card_button"),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = tokens.primary.copy(alpha = 0.12f)),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, tokens.primary.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = tokens.primary,
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.CameraAlt,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "📷 تحديد بالروشتة / العلبة بـ 𝐌𝐑𝟕 Vision",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = tokens.primary
                                        )
                                    )
                                    Text(
                                        text = "صوّر الروشتة لتعبئة بيانات الدواء تلقائيًا بذكاء",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                                    )
                                }
                            }
                        }
                    }
                }

                // 2️⃣ 💊 اسم الدواء
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "💊 اسم الدواء",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                        )
                        OutlinedTextField(
                            value = userNickname,
                            onValueChange = { userNickname = it },
                            label = { Text("اسم الدواء الشائع (مثال: دواء الضغط / أسبرين)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("med_nickname_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = officialName,
                            onValueChange = { officialName = it },
                            label = { Text("الاسم العلمي أو الرسمي (اختياري)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }

                // 3️⃣ 💊 التركيز (الوحدة g محددة مسبقًا - لوحة أرقام فقط)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "💊 التركيز (الوحدة: g)",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                        )
                        OutlinedTextField(
                            value = concNumber,
                            onValueChange = { concNumber = it.filter { char -> char.isDigit() || char == '.' } },
                            label = { Text("التركيز الرقمي فقط (الوحدة g ثابتة)") },
                            trailingIcon = {
                                Text(
                                    text = "g",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = tokens.primary),
                                    modifier = Modifier.padding(end = 12.dp)
                                )
                            },
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("med_conc_numeric_input"),
                            singleLine = true
                        )
                    }
                }

                // 4️⃣ 📦 المخزون الحالي (الوحدة حباية / قرص - لوحة أرقام فقط)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "📦 المخزون الحالي (الوحدة: حباية / قرص)",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                        )
                        OutlinedTextField(
                            value = stockCountText,
                            onValueChange = { stockCountText = it.filter { char -> char.isDigit() } },
                            label = { Text("عدد الحبات / الأقراص المتبقية") },
                            trailingIcon = {
                                Text(
                                    text = "حبة",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = tokens.textSecondary),
                                    modifier = Modifier.padding(end = 12.dp)
                                )
                            },
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("med_stock_numeric_input"),
                            singleLine = true
                        )
                    }
                }

                // 5️⃣ ⏰ موعد الجرعة (منبه الهاتف Time Picker)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = tokens.surfaceElevated)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "⏰ موعد الجرعة (تحديد مثل منبه الهاتف)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                // Hours Picker
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(onClick = { selectedHour = if (selectedHour >= 12) 1 else selectedHour + 1 }) {
                                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = null)
                                    }
                                    Text(
                                        text = String.format("%02d", selectedHour),
                                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                    )
                                    IconButton(onClick = { selectedHour = if (selectedHour <= 1) 12 else selectedHour - 1 }) {
                                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                                    }
                                }

                                Text(" : ", style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold), modifier = Modifier.padding(horizontal = 8.dp))

                                // Minutes Picker
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(onClick = { selectedMinute = (selectedMinute + 15) % 60 }) {
                                        Icon(Icons.Default.KeyboardArrowUp, contentDescription = null)
                                    }
                                    Text(
                                        text = String.format("%02d", selectedMinute),
                                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = tokens.textPrimary)
                                    )
                                    IconButton(onClick = { selectedMinute = if (selectedMinute - 15 < 0) 45 else selectedMinute - 15 }) {
                                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                                    }
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                // AM/PM Toggle
                                Button(
                                    onClick = { isAm = !isAm },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = tokens.primary.copy(alpha = 0.2f), contentColor = tokens.primary)
                                ) {
                                    Text(if (isAm) "صباحاً (ص)" else "مساءً (م)", fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    val formatted = String.format("%02d:%02d %s", selectedHour, selectedMinute, if (isAm) "ص" else "م")
                                    if (!doseTimesList.contains(formatted)) {
                                        doseTimesList = doseTimesList + formatted
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.AddAlarm, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إضافة هذا الموعد للتنبيهات")
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                doseTimesList.forEach { timeStr ->
                                    InputChip(
                                        selected = true,
                                        onClick = { doseTimesList = doseTimesList - timeStr },
                                        label = { Text(timeStr, fontWeight = FontWeight.Bold) },
                                        trailingIcon = { Icon(Icons.Default.Close, contentDescription = "حذف", modifier = Modifier.size(14.dp)) }
                                    )
                                }
                            }
                        }
                    }
                }

                // 6️⃣ 🍽️ تعليمات الجرعة (شبكة 3 × 3 RTL)
                // RTL: Right = قبل, Center = مع, Left = بعد
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "🍽️ تعليمات الجرعة (اختر من الشبكة)",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = tokens.primary)
                        )

                        // الصف الأول — الفطار (Right: قبل الفطار | Center: مع الفطار | Left: بعد الفطار)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DoseGridTile(
                                label = "قبل الفطار",
                                isSelected = selectedInstructionTile == "قبل الفطار",
                                onClick = { selectedInstructionTile = "قبل الفطار" },
                                modifier = Modifier.weight(1f)
                            )
                            DoseGridTile(
                                label = "مع الفطار",
                                isSelected = selectedInstructionTile == "مع الفطار",
                                onClick = { selectedInstructionTile = "مع الفطار" },
                                modifier = Modifier.weight(1f)
                            )
                            DoseGridTile(
                                label = "بعد الفطار",
                                isSelected = selectedInstructionTile == "بعد الفطار",
                                onClick = { selectedInstructionTile = "بعد الفطار" },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // الصف الثاني — الغداء (Right: قبل الغداء | Center: مع الغداء | Left: بعد الغداء)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DoseGridTile(
                                label = "قبل الغداء",
                                isSelected = selectedInstructionTile == "قبل الغداء",
                                onClick = { selectedInstructionTile = "قبل الغداء" },
                                modifier = Modifier.weight(1f)
                            )
                            DoseGridTile(
                                label = "مع الغداء",
                                isSelected = selectedInstructionTile == "مع الغداء",
                                onClick = { selectedInstructionTile = "مع الغداء" },
                                modifier = Modifier.weight(1f)
                            )
                            DoseGridTile(
                                label = "بعد الغداء",
                                isSelected = selectedInstructionTile == "بعد الغداء",
                                onClick = { selectedInstructionTile = "بعد الغداء" },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // الصف الثالث — العشاء (Right: قبل العشاء | Center: مع العشاء | Left: بعد العشاء)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DoseGridTile(
                                label = "قبل العشاء",
                                isSelected = selectedInstructionTile == "قبل العشاء",
                                onClick = { selectedInstructionTile = "قبل العشاء" },
                                modifier = Modifier.weight(1f)
                            )
                            DoseGridTile(
                                label = "مع العشاء",
                                isSelected = selectedInstructionTile == "مع العشاء",
                                onClick = { selectedInstructionTile = "مع العشاء" },
                                modifier = Modifier.weight(1f)
                            )
                            DoseGridTile(
                                label = "بعد العشاء",
                                isSelected = selectedInstructionTile == "بعد العشاء",
                                onClick = { selectedInstructionTile = "بعد العشاء" },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // 7️⃣ ✍️ تعليمات أخرى
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selectedInstructionTile == "✍️ تعليمات أخرى") tokens.primary.copy(alpha = 0.15f) else tokens.surfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (selectedInstructionTile == "✍️ تعليمات أخرى") tokens.primary else tokens.cardBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedInstructionTile = "✍️ تعليمات أخرى" }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "✍️ تعليمات أخرى (كتابة يدوية)",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedInstructionTile == "✍️ تعليمات أخرى") tokens.primary else tokens.textPrimary
                                    )
                                )
                                if (selectedInstructionTile == "✍️ تعليمات أخرى") {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = tokens.primary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        if (selectedInstructionTile == "✍️ تعليمات أخرى") {
                            OutlinedTextField(
                                value = customInstructionText,
                                onValueChange = { customInstructionText = it },
                                label = { Text("أدخل التعليمات الخاصة يدويًا") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // 8. Extra Notes
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات طبيب أو نصائح إضافية") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalName = if (userNickname.isNotBlank()) userNickname else officialName
                    val finalOfficial = if (officialName.isNotBlank()) officialName else userNickname
                    val finalInstructions = if (selectedInstructionTile == "✍️ تعليمات أخرى") customInstructionText else selectedInstructionTile
                    val finalTimes = if (doseTimesList.isNotEmpty()) doseTimesList.joinToString(" ، ") else "08:00 ص"

                    if (finalName.isNotBlank()) {
                        onConfirm(
                            MedicationEntity(
                                officialName = finalOfficial,
                                userNickname = finalName,
                                concentration = "$concNumber $concUnit",
                                form = "حبة",
                                instructions = finalInstructions,
                                timesOfDay = finalTimes,
                                stockCount = stockCountText.toIntOrNull() ?: 30,
                                notes = notes
                            )
                        )
                    }
                },
                modifier = Modifier
                    .height(if (isSenior) 54.dp else 48.dp)
                    .testTag("save_medication_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("حفظ الدواء وجدولته", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun DoseGridTile(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) tokens.primary else tokens.surfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) tokens.primary else tokens.cardBorder
        ),
        modifier = modifier
            .height(48.dp)
            .clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .size(14.dp)
                            .padding(end = 2.dp)
                    )
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else tokens.textPrimary
                    )
                )
            }
        }
    }
}
