package com.example.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.text.format.DateFormat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class RegionalSuggestion(
    val countryCode: String,
    val countryName: String,
    val timezoneId: String,
    val suggestedLanguage: String,
    val suggestedDialect: String,
    val use24Hour: Boolean,
    val datePattern: String,
    val isFromLocation: Boolean
)

object LocationLocaleManager {

    fun hasCoarseLocationPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Detects regional settings.
     * - Never accesses location unless ACCESS_COARSE_LOCATION is explicitly granted.
     * - Uses Android TimeZone.getDefault() and Locale.getDefault() as baseline.
     */
    @SuppressLint("MissingPermission")
    suspend fun detectRegionalSuggestion(context: Context): RegionalSuggestion = withContext(Dispatchers.IO) {
        val timezoneId = TimeZone.getDefault().id
        val deviceLocale = Locale.getDefault()
        val is24Hour = try {
            DateFormat.is24HourFormat(context)
        } catch (e: Exception) {
            false
        }

        var countryCode = deviceLocale.country.uppercase(Locale.US).ifBlank { "EG" }
        var countryName = deviceLocale.displayCountry.ifBlank { "مصر" }
        var isFromLocation = false

        if (hasCoarseLocationPermission(context)) {
            try {
                val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                val location: Location? = locationManager?.let { lm ->
                    lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                        ?: lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)
                }

                if (location != null && Geocoder.isPresent()) {
                    val geocoder = Geocoder(context, Locale("ar"))
                    @Suppress("DEPRECATION")
                    val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    val addr = addresses?.firstOrNull()
                    if (addr != null) {
                        if (!addr.countryCode.isNullOrBlank()) {
                            countryCode = addr.countryCode.uppercase(Locale.US)
                        }
                        if (!addr.countryName.isNullOrBlank()) {
                            countryName = addr.countryName
                        }
                        isFromLocation = true
                    }
                }
            } catch (e: Exception) {
                // Graceful fallback to device locale/timezone
            }
        }

        val suggestedLanguage = if (deviceLocale.language == "en" && countryCode !in setOf("EG", "SA", "AE", "KW", "QA", "BH", "OM", "JO", "LB", "SY", "IQ", "MA", "DZ", "TN")) {
            "en"
        } else {
            "ar"
        }

        val suggestedDialect = mapCountryToRivoDialect(countryCode)
        val datePattern = if (countryCode == "US") "MM/dd/yyyy" else "dd/MM/yyyy"

        RegionalSuggestion(
            countryCode = countryCode,
            countryName = countryName,
            timezoneId = timezoneId,
            suggestedLanguage = suggestedLanguage,
            suggestedDialect = suggestedDialect,
            use24Hour = is24Hour,
            datePattern = datePattern,
            isFromLocation = isFromLocation
        )
    }

    fun mapCountryToRivoDialect(countryCode: String): String {
        return when (countryCode.uppercase(Locale.US)) {
            "EG", "SD" -> "EG" // المصرية الطبيعية
            "SA", "KW", "QA", "BH", "OM", "YE" -> "SA" // الخليجية
            "AE" -> "AE" // الإماراتية
            "JO", "LB", "SY", "PS" -> "JO" // الشامية
            "MA", "DZ", "TN", "LY" -> "MA" // المغاربية
            else -> "MSA" // العربية الفصحى
        }
    }

    fun getDialectDisplayName(dialectCode: String): String {
        return when (dialectCode) {
            "EG" -> "المصرية الطبيعية 🇪🇬"
            "SA" -> "الخليجية / السعودية 🇸🇦"
            "AE" -> "الإماراتية 🇦🇪"
            "JO" -> "الشامية 🇯🇴"
            "MA" -> "المغاربية 🇲🇦"
            "MSA" -> "العربية الفصحى 🌍"
            else -> "المصرية الطبيعية 🇪🇬"
        }
    }

    fun formatTime(millis: Long, prefs: UserPreferences): String {
        val pattern = if (prefs.use24HourFormat) "HH:mm" else "hh:mm a"
        val sdf = SimpleDateFormat(pattern, Locale(prefs.rivoLanguage))
        sdf.timeZone = TimeZone.getTimeZone(prefs.userTimezoneId)
        return sdf.format(Date(millis))
    }

    fun formatDate(millis: Long, prefs: UserPreferences): String {
        val sdf = SimpleDateFormat(prefs.dateFormatPattern, Locale(prefs.rivoLanguage))
        sdf.timeZone = TimeZone.getTimeZone(prefs.userTimezoneId)
        return sdf.format(Date(millis))
    }
}
