package com.example.data.repository

import com.example.data.SuperAdminConfig
import com.example.data.local.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*

class Mr7Repository(private val db: AppDatabase) {

    // Helper: Ban check exception
    class UserBannedException(
        val banType: String?,
        val banReason: String?,
        val banEndMillis: Long?
    ) : Exception(
        if (banType == "PERMANENT") {
            "🚫 تم حظر هذا الحساب دائمًا من لوحة الإدارة.\nالسبب: ${banReason ?: "مخالفة الشروط"}"
        } else {
            val endStr = banEndMillis?.let { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(it)) } ?: ""
            "⏱️ تم حظر هذا الحساب مؤقتًا حتى: $endStr.\nالسبب: ${banReason ?: "مخالفة الشروط"}"
        }
    )

    // User Account Methods
    suspend fun createAccount(name: String, email: String, passwordInput: String): Result<UserAccountEntity> {
        val cleanEmail = email.lowercase().trim()
        val isSuperAdmin = SuperAdminConfig.isAdminEmail(cleanEmail)
        val passwordHash = SuperAdminConfig.hashWithSalt(passwordInput)
        val existing = db.userAccountDao().getUserByEmail(cleanEmail)
        if (existing != null) {
            if (existing.isBanned && !checkIfBanExpired(existing)) {
                return Result.failure(UserBannedException(existing.banType, existing.banReason, existing.banEndMillis))
            }
            if (existing.hasEmailAuth && existing.passwordHash.isNotBlank()) {
                return Result.failure(Exception("هذا البريد الإلكتروني مسجل بالفعل. يرجى اختيار 'تسجيل الدخول'"))
            } else {
                val updated = existing.copy(
                    userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else existing.userId,
                    passwordHash = passwordHash,
                    hasEmailAuth = true,
                    role = if (isSuperAdmin) "SUPER_ADMIN" else existing.role,
                    name = if (existing.name.isBlank() || existing.name == "المستخدم") name else existing.name,
                    lastActiveMillis = System.currentTimeMillis()
                )
                db.userAccountDao().insertUserAccount(updated)
                return Result.success(updated)
            }
        }
        val userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else "usr_" + UUID.randomUUID().toString().take(8)
        val newAccount = UserAccountEntity(
            userId = userId,
            name = name.trim(),
            email = cleanEmail,
            passwordHash = passwordHash,
            hasEmailAuth = true,
            role = if (isSuperAdmin) "SUPER_ADMIN" else "USER",
            lastActiveMillis = System.currentTimeMillis()
        )
        db.userAccountDao().insertUserAccount(newAccount)
        return Result.success(newAccount)
    }

    suspend fun authenticateUser(email: String, passwordInput: String): Result<UserAccountEntity> {
        val cleanEmail = email.lowercase().trim()
        val isSuperAdminEmail = SuperAdminConfig.isAdminEmail(cleanEmail)
        val isAdminPassword = SuperAdminConfig.verifyAdminLoginPassword(passwordInput)
        val hashedInput = SuperAdminConfig.hashWithSalt(passwordInput)

        var user = db.userAccountDao().getUserByEmail(cleanEmail)
        if (user == null && (isSuperAdminEmail && isAdminPassword)) {
            user = UserAccountEntity(
                userId = SuperAdminConfig.ADMIN_ID,
                name = "Super Admin 👑",
                email = cleanEmail,
                passwordHash = hashedInput,
                hasEmailAuth = true,
                role = "SUPER_ADMIN"
            )
            db.userAccountDao().insertUserAccount(user)
        }

        if (user == null) {
            return Result.failure(Exception("الحساب غير موجود. يرجى التأكد من البريد أو إنشاء حساب جديد"))
        }

        // Ban Check
        if (user.role != "SUPER_ADMIN" && user.isBanned && !checkIfBanExpired(user)) {
            return Result.failure(UserBannedException(user.banType, user.banReason, user.banEndMillis))
        }

        val isValidPass = (user.hasEmailAuth && (user.passwordHash == hashedInput || user.passwordHash == passwordInput)) ||
                          (isSuperAdminEmail && isAdminPassword) ||
                          (user.role == "SUPER_ADMIN" && isAdminPassword)

        if (!isValidPass && user.hasEmailAuth && user.passwordHash.isNotBlank()) {
            return Result.failure(Exception("كلمة المرور غير صحيحة"))
        }

        val updated = user.copy(
            userId = if (isSuperAdminEmail) SuperAdminConfig.ADMIN_ID else user.userId,
            role = if (isSuperAdminEmail) "SUPER_ADMIN" else user.role,
            lastActiveMillis = System.currentTimeMillis()
        )
        db.userAccountDao().insertUserAccount(updated)
        return Result.success(updated)
    }

    suspend fun authenticateWithGoogle(email: String, name: String, googleId: String): Result<UserAccountEntity> {
        val cleanEmail = email.lowercase().trim()
        val isSuperAdmin = SuperAdminConfig.isAdminEmail(cleanEmail)
        var user = db.userAccountDao().getUserByGoogleId(googleId)
        if (user != null) {
            if (user.role != "SUPER_ADMIN" && user.isBanned && !checkIfBanExpired(user)) {
                return Result.failure(UserBannedException(user.banType, user.banReason, user.banEndMillis))
            }
            val updated = user.copy(
                userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else user.userId,
                role = if (isSuperAdmin) "SUPER_ADMIN" else user.role,
                lastActiveMillis = System.currentTimeMillis()
            )
            db.userAccountDao().insertUserAccount(updated)
            return Result.success(updated)
        }

        // Account linking by email
        user = db.userAccountDao().getUserByEmail(cleanEmail)
        if (user != null) {
            if (user.role != "SUPER_ADMIN" && user.isBanned && !checkIfBanExpired(user)) {
                return Result.failure(UserBannedException(user.banType, user.banReason, user.banEndMillis))
            }
            val updatedUser = user.copy(
                userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else user.userId,
                hasGoogleAuth = true,
                googleId = googleId,
                role = if (isSuperAdmin) "SUPER_ADMIN" else user.role,
                name = if (user.name.isBlank() || user.name == "المستخدم") name else user.name,
                lastActiveMillis = System.currentTimeMillis()
            )
            db.userAccountDao().insertUserAccount(updatedUser)
            return Result.success(updatedUser)
        }

        val userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else "usr_" + UUID.randomUUID().toString().take(8)
        val newAccount = UserAccountEntity(
            userId = userId,
            name = name.ifBlank { "مستخدم Google" },
            email = cleanEmail,
            hasEmailAuth = false,
            hasGoogleAuth = true,
            googleId = googleId,
            role = if (isSuperAdmin) "SUPER_ADMIN" else "USER",
            lastActiveMillis = System.currentTimeMillis()
        )
        db.userAccountDao().insertUserAccount(newAccount)
        return Result.success(newAccount)
    }

    suspend fun authenticateWithFacebook(email: String, name: String, facebookId: String): Result<UserAccountEntity> {
        val cleanEmail = email.lowercase().trim()
        val isSuperAdmin = SuperAdminConfig.isAdminEmail(cleanEmail)
        var user = db.userAccountDao().getUserByFacebookId(facebookId)
        if (user != null) {
            if (user.role != "SUPER_ADMIN" && user.isBanned && !checkIfBanExpired(user)) {
                return Result.failure(UserBannedException(user.banType, user.banReason, user.banEndMillis))
            }
            val updated = user.copy(
                userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else user.userId,
                role = if (isSuperAdmin) "SUPER_ADMIN" else user.role,
                lastActiveMillis = System.currentTimeMillis()
            )
            db.userAccountDao().insertUserAccount(updated)
            return Result.success(updated)
        }

        // Account linking by email
        if (cleanEmail.isNotBlank()) {
            user = db.userAccountDao().getUserByEmail(cleanEmail)
            if (user != null) {
                if (user.role != "SUPER_ADMIN" && user.isBanned && !checkIfBanExpired(user)) {
                    return Result.failure(UserBannedException(user.banType, user.banReason, user.banEndMillis))
                }
                val updatedUser = user.copy(
                    userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else user.userId,
                    hasFacebookAuth = true,
                    facebookId = facebookId,
                    role = if (isSuperAdmin) "SUPER_ADMIN" else user.role,
                    name = if (user.name.isBlank() || user.name == "المستخدم") name else user.name,
                    lastActiveMillis = System.currentTimeMillis()
                )
                db.userAccountDao().insertUserAccount(updatedUser)
                return Result.success(updatedUser)
            }
        }

        val userId = if (isSuperAdmin) SuperAdminConfig.ADMIN_ID else "usr_" + UUID.randomUUID().toString().take(8)
        val newAccount = UserAccountEntity(
            userId = userId,
            name = name.ifBlank { "مستخدم Facebook" },
            email = cleanEmail,
            hasEmailAuth = false,
            hasFacebookAuth = true,
            facebookId = facebookId,
            role = if (isSuperAdmin) "SUPER_ADMIN" else "USER",
            lastActiveMillis = System.currentTimeMillis()
        )
        db.userAccountDao().insertUserAccount(newAccount)
        return Result.success(newAccount)
    }

    suspend fun toggleLinkGoogle(userId: String, googleId: String, email: String): Result<UserAccountEntity> {
        val user = db.userAccountDao().getUserById(userId) ?: return Result.failure(Exception("الحساب غير موجود"))
        val isLinked = user.hasGoogleAuth
        val updated = user.copy(
            hasGoogleAuth = !isLinked,
            googleId = if (!isLinked) googleId else null
        )
        db.userAccountDao().insertUserAccount(updated)
        return Result.success(updated)
    }

    suspend fun toggleLinkFacebook(userId: String, facebookId: String, email: String): Result<UserAccountEntity> {
        val user = db.userAccountDao().getUserById(userId) ?: return Result.failure(Exception("الحساب غير موجود"))
        val isLinked = user.hasFacebookAuth
        val updated = user.copy(
            hasFacebookAuth = !isLinked,
            facebookId = if (!isLinked) facebookId else null
        )
        db.userAccountDao().insertUserAccount(updated)
        return Result.success(updated)
    }

    suspend fun getUserAccount(userId: String): UserAccountEntity? {
        return db.userAccountDao().getUserById(userId)
    }

    suspend fun deleteUserAccount(userId: String) {
        db.userAccountDao().deleteUserAccount(userId)
        db.medicationDao().deleteAllMedicationsForUser(userId)
        db.doseLogDao().deleteAllLogsForUser(userId)
        db.doctorDao().deleteAllDoctorsForUser(userId)
        db.appointmentDao().deleteAllAppointmentsForUser(userId)
        db.allergyDao().deleteAllAllergiesForUser(userId)
        db.familyDao().deleteAllFamilyMembersForUser(userId)
    }

    private suspend fun checkIfBanExpired(user: UserAccountEntity): Boolean {
        if (user.banType == "TEMPORARY" && user.banEndMillis != null && System.currentTimeMillis() > user.banEndMillis) {
            // Unban automatically if expired
            db.userAccountDao().updateUserBanState(user.userId, false, null, null, null)
            return true
        }
        return false
    }

    // --- SUPER ADMIN MANAGEMENT METHODS ---
    fun getAllUsersFlow(): Flow<List<UserAccountEntity>> = db.userAccountDao().getAllUsersFlow()
    fun getBannedUsersFlow(): Flow<List<UserAccountEntity>> = db.userAccountDao().getBannedUsersFlow()
    fun getAdminLogsFlow(): Flow<List<AdminLogEntity>> = db.adminLogDao().getAllAdminLogs()
    fun getAnnouncementsFlow(): Flow<List<SystemAnnouncementEntity>> = db.systemAnnouncementDao().getAllAnnouncements()
    fun getReportsFlow(): Flow<List<UserReportEntity>> = db.userReportDao().getAllReports()
    fun getKnowledgeFlow(): Flow<List<MedicationKnowledgeEntity>> = db.medicationKnowledgeDao().getAllKnowledge()
    fun getFeatureFlagsFlow(): Flow<List<FeatureFlagEntity>> = db.featureFlagDao().getAllFlags()
    fun getOnlineUsersCountFlow(cutoffMillis: Long): Flow<Int> = db.userAccountDao().getActiveOnlineUsersCountFlow(cutoffMillis)
    suspend fun updateHeartbeat(userId: String) = db.userAccountDao().updateLastActive(userId, System.currentTimeMillis())
    suspend fun setOffline(userId: String) = db.userAccountDao().updateLastActive(userId, 0L)

    suspend fun banUser(
        targetUserId: String,
        banType: String, // "TEMPORARY" or "PERMANENT"
        reason: String,
        durationDays: Int? = null,
        adminId: String = "777"
    ): Result<Unit> {
        val targetUser = db.userAccountDao().getUserById(targetUserId)
            ?: return Result.failure(Exception("المستخدم غير موجود"))

        if (targetUser.role == "SUPER_ADMIN" || targetUser.userId == SuperAdminConfig.ADMIN_ID || targetUser.userId == "777" || SuperAdminConfig.isAdminEmail(targetUser.email)) {
            return Result.failure(Exception("🚫 لا يمكن حظر حساب Super Admin الأصلي!"))
        }

        val endMillis = if (banType == "TEMPORARY" && durationDays != null) {
            System.currentTimeMillis() + (durationDays * 24 * 60 * 60 * 1000L)
        } else null

        db.userAccountDao().updateUserBanState(targetUserId, true, banType, reason, endMillis)

        // Log action
        val log = AdminLogEntity(
            adminId = adminId,
            action = "BAN_USER",
            affectedUserId = targetUserId,
            affectedUserName = targetUser.name,
            details = "نوع الحظر: $banType | السبب: $reason | المادة/الأيام: ${durationDays ?: "دائم"}"
        )
        db.adminLogDao().insertAdminLog(log)

        return Result.success(Unit)
    }

    suspend fun unbanUser(targetUserId: String, adminId: String = "777"): Result<Unit> {
        val targetUser = db.userAccountDao().getUserById(targetUserId)
            ?: return Result.failure(Exception("المستخدم غير موجود"))

        db.userAccountDao().updateUserBanState(targetUserId, false, null, null, null)

        val log = AdminLogEntity(
            adminId = adminId,
            action = "UNBAN_USER",
            affectedUserId = targetUserId,
            affectedUserName = targetUser.name,
            details = "تم فك الحظر عن المستخدم وتنشيط حسابك مجدداً"
        )
        db.adminLogDao().insertAdminLog(log)

        return Result.success(Unit)
    }

    suspend fun addAnnouncement(title: String, message: String, icon: String = "📢", audience: String = "ALL"): Long {
        val announcement = SystemAnnouncementEntity(
            title = title,
            message = message,
            icon = icon,
            targetAudience = audience
        )
        val id = db.systemAnnouncementDao().insertAnnouncement(announcement)
        db.adminLogDao().insertAdminLog(
            AdminLogEntity(action = "CREATE_ANNOUNCEMENT", details = "عنوان الإعلان: $title")
        )
        return id
    }

    suspend fun toggleAnnouncementStatus(id: Long, isActive: Boolean) {
        db.systemAnnouncementDao().updateAnnouncementStatus(id, isActive)
    }

    suspend fun submitUserReport(userId: String, userName: String, email: String, title: String, description: String): Long {
        return db.userReportDao().insertReport(
            UserReportEntity(userId = userId, userName = userName, userEmail = email, title = title, description = description)
        )
    }

    suspend fun updateReportStatus(id: Long, status: String) {
        db.userReportDao().updateReportStatus(id, status)
        db.adminLogDao().insertAdminLog(
            AdminLogEntity(action = "UPDATE_REPORT_STATUS", details = "تقرير #$id -> حالة $status")
        )
    }

    suspend fun addMedicationKnowledge(name: String, category: String, desc: String, sideEffects: String, dosage: String): Long {
        return db.medicationKnowledgeDao().insertKnowledge(
            MedicationKnowledgeEntity(officialName = name, category = category, description = desc, sideEffects = sideEffects, defaultDosage = dosage)
        )
    }

    suspend fun deleteMedicationKnowledge(item: MedicationKnowledgeEntity) {
        db.medicationKnowledgeDao().deleteKnowledge(item)
    }

    suspend fun setFeatureFlag(key: String, name: String, isEnabled: Boolean, category: String = "SYSTEM") {
        db.featureFlagDao().insertFlag(FeatureFlagEntity(key = key, name = name, isEnabled = isEnabled, category = category))
        db.adminLogDao().insertAdminLog(
            AdminLogEntity(action = "TOGGLE_FEATURE_FLAG", details = "ميزة $name ($key) -> ${if (isEnabled) "🟢 مفعلة" else "🔴 معطلة"}")
        )
    }

    // Scoped Data Queries
    fun getActiveMedications(userId: String): Flow<List<MedicationEntity>> = db.medicationDao().getActiveMedications(userId)
    fun getArchivedMedications(userId: String): Flow<List<MedicationEntity>> = db.medicationDao().getArchivedMedications(userId)
    fun getAllMedications(userId: String): Flow<List<MedicationEntity>> = db.medicationDao().getAllMedications(userId)
    fun getAllDoctors(userId: String): Flow<List<DoctorEntity>> = db.doctorDao().getAllDoctors(userId)
    fun getUpcomingAppointments(userId: String): Flow<List<AppointmentEntity>> = db.appointmentDao().getUpcomingAppointments(userId)
    fun getAllAppointments(userId: String): Flow<List<AppointmentEntity>> = db.appointmentDao().getAllAppointments(userId)
    fun getAllAllergies(userId: String): Flow<List<AllergyEntity>> = db.allergyDao().getAllAllergies(userId)
    fun getAllFamilyMembers(userId: String): Flow<List<FamilyMemberEntity>> = db.familyDao().getAllFamilyMembers(userId)

    fun getTodayDoseLogs(userId: String): Flow<List<DoseLogEntity>> {
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
        return db.doseLogDao().getDoseLogsForDate(userId, todayStr)
    }

    suspend fun getMedicationById(id: Long, userId: String): MedicationEntity? {
        return db.medicationDao().getMedicationById(id, userId)
    }

    suspend fun insertMedication(med: MedicationEntity): Long {
        return db.medicationDao().insertMedication(med)
    }

    suspend fun updateMedication(med: MedicationEntity) {
        db.medicationDao().updateMedication(med)
    }

    suspend fun updateStock(id: Long, newStock: Int, userId: String) {
        db.medicationDao().updateStock(id, newStock, userId)
    }

    suspend fun setArchived(id: Long, archived: Boolean, userId: String) {
        db.medicationDao().setArchived(id, archived, userId)
    }

    suspend fun deleteMedication(med: MedicationEntity, userId: String) {
        db.medicationDao().deleteMedication(med)
        db.doseLogDao().deleteLogsForMedication(med.id, userId)
    }

    suspend fun updateDoseStatus(id: Long, status: String, userId: String) {
        db.doseLogDao().updateDoseStatus(id, status, userId = userId)
        if (status == "CONFIRMED") {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())
            val logs = db.doseLogDao().getDoseLogsForDate(userId, todayStr).first()
            val log = logs.find { it.id == id }
            if (log != null) {
                val med = db.medicationDao().getMedicationById(log.medicationId, userId)
                if (med != null && med.stockCount > 0) {
                    db.medicationDao().updateStock(med.id, med.stockCount - 1, userId)
                }
            }
        }
    }

    suspend fun insertDoseLog(log: DoseLogEntity): Long = db.doseLogDao().insertDoseLog(log)

    suspend fun insertDoctor(doc: DoctorEntity): Long = db.doctorDao().insertDoctor(doc)
    suspend fun deleteDoctor(doc: DoctorEntity) = db.doctorDao().deleteDoctor(doc)

    suspend fun insertAppointment(app: AppointmentEntity): Long = db.appointmentDao().insertAppointment(app)
    suspend fun setAppointmentCompleted(id: Long, completed: Boolean, userId: String) = db.appointmentDao().setCompleted(id, completed, userId)
    suspend fun deleteAppointment(app: AppointmentEntity) = db.appointmentDao().deleteAppointment(app)

    suspend fun insertAllergy(allergy: AllergyEntity): Long = db.allergyDao().insertAllergy(allergy)
    suspend fun deleteAllergy(allergy: AllergyEntity) = db.allergyDao().deleteAllergy(allergy)

    suspend fun insertFamilyMember(member: FamilyMemberEntity): Long = db.familyDao().insertFamilyMember(member)
    suspend fun updateFamilyMember(member: FamilyMemberEntity) = db.familyDao().updateFamilyMember(member)
    suspend fun deleteFamilyMember(member: FamilyMemberEntity) = db.familyDao().deleteFamilyMember(member)
}
