package com.example.data

/**
 * 👑 MR7 Super Admin Configuration & Security Specifications
 *
 * Primary Identity & Access Control specifications:
 * - Admin Email: Primary & Alternate Admin Emails
 * - Admin ID: Internal unique immutable identifier (NOT shown on login input screen)
 * - Admin Login Password: Password for logging in via Email credentials ("MR7 ON TOP 111")
 * - Admin Dashboard Password: Secondary security PIN/password for opening the Admin Dashboard ("MR7 ADMIN 2013")
 */
object SuperAdminConfig {
    const val ADMIN_EMAIL_PRIMARY = "admin@mr7nursing.com"
    const val ADMIN_EMAIL_ALT1 = "jffhyfvg@gmail.com"
    const val ADMIN_EMAIL_ALT2 = "mr7.mr.mor3eb@gmail.com"

    val ADMIN_EMAILS: Set<String> = setOf(
        ADMIN_EMAIL_PRIMARY.lowercase(),
        ADMIN_EMAIL_ALT1.lowercase(),
        ADMIN_EMAIL_ALT2.lowercase()
    )

    // Internal Admin ID - Immutable backend/repo identifier
    const val ADMIN_ID = "ADMIN-MR7-777-SUPER"

    // Authentication Passwords
    const val ADMIN_LOGIN_PASSWORD = "MR7 ON TOP 111"
    const val ADMIN_DASHBOARD_PASSWORD = "MR7 ADMIN 2013"

    fun isAdminEmail(email: String): Boolean {
        return ADMIN_EMAILS.contains(email.lowercase().trim())
    }

    fun isSuperAdminUser(email: String, userId: String?): Boolean {
        val cleanEmail = email.lowercase().trim()
        val uid = userId ?: ""
        return isAdminEmail(cleanEmail) || uid == ADMIN_ID || uid == "777" || uid.startsWith("ADMIN-")
    }
}
