package com.example.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.ui.theme.AppThemeMode

class UserPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("mr7_user_prefs", Context.MODE_PRIVATE)

    var currentTheme: AppThemeMode by mutableStateOf(
        try {
            AppThemeMode.valueOf(prefs.getString("theme_mode", AppThemeMode.MEDICAL_BLUE.name) ?: AppThemeMode.MEDICAL_BLUE.name)
        } catch (e: Exception) {
            AppThemeMode.MEDICAL_BLUE
        }
    )
        private set

    var isSeniorMode: Boolean by mutableStateOf(prefs.getBoolean("senior_mode", false))
        private set

    var activeUserId: String? by mutableStateOf(prefs.getString("active_user_id", null))
        private set

    var activeUserEmail: String by mutableStateOf(prefs.getString("active_user_email", "") ?: "")
        private set

    var userName: String by mutableStateOf(prefs.getString("user_name", "المستخدم") ?: "المستخدم")
        private set

    var pinLock: String by mutableStateOf(prefs.getString("pin_lock", "") ?: "")
        private set

    var isAppLocked: Boolean by mutableStateOf(pinLock.isNotEmpty())

    var hasSeenPermissionsWelcome: Boolean by mutableStateOf(prefs.getBoolean("seen_permissions_welcome", false))
        private set

    var hasSeenOnboarding: Boolean by mutableStateOf(prefs.getBoolean("seen_onboarding", false))
        private set

    var userBirthDate: String by mutableStateOf(prefs.getString("user_birth_date", "") ?: "")
        private set

    var hasRegularMeds: Boolean by mutableStateOf(prefs.getBoolean("has_regular_meds", false))
        private set

    var hasRegularAppointments: Boolean by mutableStateOf(prefs.getBoolean("has_regular_appointments", false))
        private set

    var isProfileSetupCompleted: Boolean by mutableStateOf(prefs.getBoolean("profile_setup_completed", false))
        private set

    var routineMedsTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_meds_tracked", true))
        private set

    var routineVitalsTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_vitals_tracked", true))
        private set

    var routineActivitiesTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_activities_tracked", true))
        private set

    var routineMoodAndSymptomsTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_mood_symptoms_tracked", true))
        private set

    var medFirstTime: String by mutableStateOf(prefs.getString("med_first_time", "8:00 ص") ?: "8:00 ص")
        private set

    var selectedVitalsCsv: String by mutableStateOf(prefs.getString("selected_vitals_csv", "ضغط الدم,سكر الدم قبل الوجبة,الوزن") ?: "ضغط الدم,سكر الدم قبل الوجبة,الوزن")
        private set

    var selectedActivitiesCsv: String by mutableStateOf(prefs.getString("selected_activities_csv", "كمية الماء,المشي,تنظيف الأسنان") ?: "كمية الماء,المشي,تنظيف الأسنان")
        private set

    var isRoutineSetupCompleted: Boolean by mutableStateOf(prefs.getBoolean("routine_setup_completed", false))
        private set

    var careRecipientName: String by mutableStateOf(prefs.getString("care_recipient_name", "") ?: "")
        private set

    var careRecipientRelation: String by mutableStateOf(prefs.getString("care_recipient_relation", "") ?: "")
        private set

    var careRecipientAge: String by mutableStateOf(prefs.getString("care_recipient_age", "") ?: "")
        private set

    var careRecipientPhone: String by mutableStateOf(prefs.getString("care_recipient_phone", "") ?: "")
        private set

    var careRecipientAvatar: String by mutableStateOf(prefs.getString("care_recipient_avatar", "👴🏻") ?: "👴🏻")
        private set

    var isCareRecipientSetupCompleted: Boolean by mutableStateOf(prefs.getBoolean("care_recipient_setup_completed", false))
        private set

    val isLoggedIn: Boolean
        get() = !activeUserId.isNullOrEmpty()

    fun loginSession(userId: String, name: String, email: String) {
        activeUserId = userId
        userName = name
        activeUserEmail = email
        prefs.edit()
            .putString("active_user_id", userId)
            .putString("user_name", name)
            .putString("active_user_email", email)
            .apply()
    }

    fun logoutSession() {
        activeUserId = null
        userName = "المستخدم"
        activeUserEmail = ""
        prefs.edit()
            .remove("active_user_id")
            .remove("active_user_email")
            .putString("user_name", "المستخدم")
            .apply()
    }

    fun markPermissionsWelcomeSeen() {
        hasSeenPermissionsWelcome = true
        prefs.edit().putBoolean("seen_permissions_welcome", true).apply()
    }

    fun markOnboardingSeen() {
        hasSeenOnboarding = true
        prefs.edit().putBoolean("seen_onboarding", true).apply()
    }

    fun resetOnboardingSeen() {
        hasSeenOnboarding = false
        isProfileSetupCompleted = false
        isRoutineSetupCompleted = false
        isCareRecipientSetupCompleted = false
        prefs.edit()
            .putBoolean("seen_onboarding", false)
            .putBoolean("profile_setup_completed", false)
            .putBoolean("routine_setup_completed", false)
            .putBoolean("care_recipient_setup_completed", false)
            .apply()
    }

    fun completeProfileSetup(name: String, birthDate: String, hasMeds: Boolean, hasAppointments: Boolean) {
        userName = name.trim().ifEmpty { "المستخدم" }
        userBirthDate = birthDate
        hasRegularMeds = hasMeds
        hasRegularAppointments = hasAppointments
        isProfileSetupCompleted = true

        prefs.edit()
            .putString("user_name", userName)
            .putString("user_birth_date", userBirthDate)
            .putBoolean("has_regular_meds", hasRegularMeds)
            .putBoolean("has_regular_appointments", hasRegularAppointments)
            .putBoolean("profile_setup_completed", true)
            .apply()
    }

    fun completeRoutineSetup(
        medsTracked: Boolean,
        vitalsTracked: Boolean,
        activitiesTracked: Boolean,
        moodAndSymptomsTracked: Boolean,
        firstMedTime: String = "8:00 ص",
        vitalsCsv: String = "",
        activitiesCsv: String = ""
    ) {
        routineMedsTracked = medsTracked
        routineVitalsTracked = vitalsTracked
        routineActivitiesTracked = activitiesTracked
        routineMoodAndSymptomsTracked = moodAndSymptomsTracked
        medFirstTime = firstMedTime
        if (vitalsCsv.isNotBlank()) selectedVitalsCsv = vitalsCsv
        if (activitiesCsv.isNotBlank()) selectedActivitiesCsv = activitiesCsv
        isRoutineSetupCompleted = true

        prefs.edit()
            .putBoolean("routine_meds_tracked", medsTracked)
            .putBoolean("routine_vitals_tracked", vitalsTracked)
            .putBoolean("routine_activities_tracked", activitiesTracked)
            .putBoolean("routine_mood_symptoms_tracked", moodAndSymptomsTracked)
            .putString("med_first_time", medFirstTime)
            .putString("selected_vitals_csv", selectedVitalsCsv)
            .putString("selected_activities_csv", selectedActivitiesCsv)
            .putBoolean("routine_setup_completed", true)
            .apply()
    }

    fun completeCareRecipientSetup(
        name: String = "",
        relation: String = "",
        age: String = "",
        phone: String = "",
        avatar: String = "👴🏻"
    ) {
        careRecipientName = name.trim()
        careRecipientRelation = relation.trim()
        careRecipientAge = age.trim()
        careRecipientPhone = phone.trim()
        careRecipientAvatar = avatar
        isCareRecipientSetupCompleted = true

        prefs.edit()
            .putString("care_recipient_name", careRecipientName)
            .putString("care_recipient_relation", careRecipientRelation)
            .putString("care_recipient_age", careRecipientAge)
            .putString("care_recipient_phone", careRecipientPhone)
            .putString("care_recipient_avatar", careRecipientAvatar)
            .putBoolean("care_recipient_setup_completed", true)
            .apply()
    }

    fun updateTheme(mode: AppThemeMode) {
        currentTheme = mode
        prefs.edit().putString("theme_mode", mode.name).apply()
    }

    fun toggleSeniorMode(enabled: Boolean) {
        isSeniorMode = enabled
        prefs.edit().putBoolean("senior_mode", enabled).apply()
    }

    fun updateUserName(name: String) {
        userName = name
        prefs.edit().putString("user_name", name).apply()
    }

    fun setPinLockCode(pin: String) {
        pinLock = pin
        isAppLocked = pin.isNotEmpty()
        prefs.edit().putString("pin_lock", pin).apply()
    }

    fun unlockApp(enteredPin: String): Boolean {
        return if (pinLock.isEmpty() || enteredPin == pinLock) {
            isAppLocked = false
            true
        } else {
            false
        }
    }

    fun lockApp() {
        if (pinLock.isNotEmpty()) {
            isAppLocked = true
        }
    }
}
