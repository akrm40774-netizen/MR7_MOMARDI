package com.example.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.ui.theme.AppThemeMode

class UserPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("mr7_user_prefs", Context.MODE_PRIVATE)

    var currentTheme: AppThemeMode by mutableStateOf(
        try {
            AppThemeMode.valueOf(prefs.getString("theme_mode", AppThemeMode.MEDICAL_BLUE.name) ?: AppThemeMode.MEDICAL_BLUE.name)
        } catch (e: Exception) {
            AppThemeMode.MEDICAL_BLUE
        }
    )
        private set

    var isSeniorMode: Boolean by mutableStateOf(prefs.getBoolean("senior_mode", false))
        private set

    var activeUserId: String? by mutableStateOf(prefs.getString("active_user_id", null))
        private set

    var activeUserEmail: String by mutableStateOf(prefs.getString("active_user_email", "") ?: "")
        private set

    var userName: String by mutableStateOf(prefs.getString("user_name", "المستخدم") ?: "المستخدم")
        private set

    var pinLock: String by mutableStateOf(prefs.getString("pin_lock", "") ?: "")
        private set

    var isAppLocked: Boolean by mutableStateOf(pinLock.isNotEmpty())

    var hasSeenPermissionsWelcome: Boolean by mutableStateOf(prefs.getBoolean("seen_permissions_welcome", false))
        private set

    var hasSeenOnboarding: Boolean by mutableStateOf(prefs.getBoolean("seen_onboarding", false))
        private set

    var userBirthDate: String by mutableStateOf(prefs.getString("user_birth_date", "") ?: "")
        private set

    var hasRegularMeds: Boolean by mutableStateOf(prefs.getBoolean("has_regular_meds", false))
        private set

    var hasRegularAppointments: Boolean by mutableStateOf(prefs.getBoolean("has_regular_appointments", false))
        private set

    var isProfileSetupCompleted: Boolean by mutableStateOf(prefs.getBoolean("profile_setup_completed", false))
        private set

    var routineMedsTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_meds_tracked", true))
        private set

    var routineVitalsTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_vitals_tracked", true))
        private set

    var routineActivitiesTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_activities_tracked", true))
        private set

    var routineMoodAndSymptomsTracked: Boolean by mutableStateOf(prefs.getBoolean("routine_mood_symptoms_tracked", true))
        private set

    var medFirstTime: String by mutableStateOf(prefs.getString("med_first_time", "8:00 ص") ?: "8:00 ص")
        private set

    var selectedVitalsCsv: String by mutableStateOf(prefs.getString("selected_vitals_csv", "ضغط الدم,سكر الدم قبل الوجبة,الوزن") ?: "ضغط الدم,سكر الدم قبل الوجبة,الوزن")
        private set

    var selectedActivitiesCsv: String by mutableStateOf(prefs.getString("selected_activities_csv", "كمية الماء,المشي,تنظيف الأسنان") ?: "كمية الماء,المشي,تنظيف الأسنان")
        private set

    var isRoutineSetupCompleted: Boolean by mutableStateOf(prefs.getBoolean("routine_setup_completed", false))
        private set

    var careRecipientName: String by mutableStateOf(prefs.getString("care_recipient_name", "") ?: "")
        private set

    var careRecipientRelation: String by mutableStateOf(prefs.getString("care_recipient_relation", "") ?: "")
        private set

    var careRecipientAge: String by mutableStateOf(prefs.getString("care_recipient_age", "") ?: "")
        private set

    var careRecipientPhone: String by mutableStateOf(prefs.getString("care_recipient_phone", "") ?: "")
        private set

    var careRecipientAvatar: String by mutableStateOf(prefs.getString("care_recipient_avatar", "👴🏻") ?: "👴🏻")
        private set

    var isCareRecipientSetupCompleted: Boolean by mutableStateOf(prefs.getBoolean("care_recipient_setup_completed", false))
        private set

    var authProvider: String by mutableStateOf(prefs.getString("auth_provider", "EMAIL") ?: "EMAIL")
        private set

    var persistentPairCode: String by mutableStateOf(prefs.getString("persistent_pair_code", "") ?: "")
        private set

    val isLoggedIn: Boolean
        get() = !activeUserId.isNullOrEmpty()

    fun loginSession(userId: String, name: String, email: String, provider: String = "EMAIL") {
        activeUserId = userId
        userName = name
        activeUserEmail = email
        authProvider = provider
        if (persistentPairCode.isBlank()) {
            val shortPart = userId.takeLast(4).uppercase().ifBlank { "7777" }
            val randPart = (1000..9999).random()
            persistentPairCode = "MR7-$shortPart-$randPart"
        }
        prefs.edit()
            .putString("active_user_id", userId)
            .putString("user_name", name)
            .putString("active_user_email", email)
            .putString("auth_provider", provider)
            .putString("persistent_pair_code", persistentPairCode)
            .apply()
    }

    fun refreshPairCode(userId: String): String {
        val shortPart = userId.takeLast(4).uppercase().ifBlank { "7777" }
        val randPart = (1000..9999).random()
        val newCode = "MR7-$shortPart-$randPart"
        persistentPairCode = newCode
        prefs.edit().putString("persistent_pair_code", newCode).apply()
        return newCode
    }

    fun logoutSession() {
        activeUserId = null
        userName = "المستخدم"
        activeUserEmail = ""
        pinLock = ""
        isAppLocked = false
        careRecipientName = ""
        careRecipientRelation = ""
        careRecipientAge = ""
        careRecipientPhone = ""
        isCareRecipientSetupCompleted = false
        prefs.edit()
            .remove("active_user_id")
            .remove("active_user_email")
            .remove("pin_lock")
            .remove("care_recipient_name")
            .remove("care_recipient_relation")
            .remove("care_recipient_age")
            .remove("care_recipient_phone")
            .putBoolean("care_recipient_setup_completed", false)
            .putString("user_name", "المستخدم")
            .apply()
    }

    fun markPermissionsWelcomeSeen() {
        hasSeenPermissionsWelcome = true
        prefs.edit().putBoolean("seen_permissions_welcome", true).apply()
    }

    fun markOnboardingSeen() {
        hasSeenOnboarding = true
        prefs.edit().putBoolean("seen_onboarding", true).apply()
    }

    fun resetOnboardingSeen() {
        hasSeenOnboarding = false
        isProfileSetupCompleted = false
        isRoutineSetupCompleted = false
        isCareRecipientSetupCompleted = false
        prefs.edit()
            .putBoolean("seen_onboarding", false)
            .putBoolean("profile_setup_completed", false)
            .putBoolean("routine_setup_completed", false)
            .putBoolean("care_recipient_setup_completed", false)
            .apply()
    }

    fun completeProfileSetup(name: String, birthDate: String, hasMeds: Boolean, hasAppointments: Boolean) {
        userName = name.trim().ifEmpty { "المستخدم" }
        userBirthDate = birthDate
        hasRegularMeds = hasMeds
        hasRegularAppointments = hasAppointments
        isProfileSetupCompleted = true

        prefs.edit()
            .putString("user_name", userName)
            .putString("user_birth_date", userBirthDate)
            .putBoolean("has_regular_meds", hasRegularMeds)
            .putBoolean("has_regular_appointments", hasRegularAppointments)
            .putBoolean("profile_setup_completed", true)
            .apply()
    }

    fun completeRoutineSetup(
        medsTracked: Boolean,
        vitalsTracked: Boolean,
        activitiesTracked: Boolean,
        moodAndSymptomsTracked: Boolean,
        firstMedTime: String = "8:00 ص",
        vitalsCsv: String = "",
        activitiesCsv: String = ""
    ) {
        routineMedsTracked = medsTracked
        routineVitalsTracked = vitalsTracked
        routineActivitiesTracked = activitiesTracked
        routineMoodAndSymptomsTracked = moodAndSymptomsTracked
        medFirstTime = firstMedTime
        if (vitalsCsv.isNotBlank()) selectedVitalsCsv = vitalsCsv
        if (activitiesCsv.isNotBlank()) selectedActivitiesCsv = activitiesCsv
        isRoutineSetupCompleted = true

        prefs.edit()
            .putBoolean("routine_meds_tracked", medsTracked)
            .putBoolean("routine_vitals_tracked", vitalsTracked)
            .putBoolean("routine_activities_tracked", activitiesTracked)
            .putBoolean("routine_mood_symptoms_tracked", moodAndSymptomsTracked)
            .putString("med_first_time", medFirstTime)
            .putString("selected_vitals_csv", selectedVitalsCsv)
            .putString("selected_activities_csv", selectedActivitiesCsv)
            .putBoolean("routine_setup_completed", true)
            .apply()
    }

    fun completeCareRecipientSetup(
        name: String = "",
        relation: String = "",
        age: String = "",
        phone: String = "",
        avatar: String = "👴🏻"
    ) {
        careRecipientName = name.trim()
        careRecipientRelation = relation.trim()
        careRecipientAge = age.trim()
        careRecipientPhone = phone.trim()
        careRecipientAvatar = avatar
        isCareRecipientSetupCompleted = true

        prefs.edit()
            .putString("care_recipient_name", careRecipientName)
            .putString("care_recipient_relation", careRecipientRelation)
            .putString("care_recipient_age", careRecipientAge)
            .putString("care_recipient_phone", careRecipientPhone)
            .putString("care_recipient_avatar", careRecipientAvatar)
            .putBoolean("care_recipient_setup_completed", true)
            .apply()
    }

    fun updateTheme(mode: AppThemeMode) {
        currentTheme = mode
        prefs.edit().putString("theme_mode", mode.name).apply()
    }

    fun toggleSeniorMode(enabled: Boolean) {
        isSeniorMode = enabled
        prefs.edit().putBoolean("senior_mode", enabled).apply()
    }

    fun updateUserName(name: String) {
        userName = name
        prefs.edit().putString("user_name", name).apply()
    }

    fun setPinLockCode(pin: String) {
        pinLock = pin
        isAppLocked = pin.isNotEmpty()
        prefs.edit().putString("pin_lock", pin).apply()
    }

    fun unlockApp(enteredPin: String): Boolean {
        return if (pinLock.isEmpty() || enteredPin == pinLock) {
            isAppLocked = false
            true
        } else {
            false
        }
    }

    fun lockApp() {
        if (pinLock.isNotEmpty()) {
            isAppLocked = true
        }
    }

    // 𝐌𝐑𝟕 𝐑𝐈𝐕𝐎 & Regional Preferences
    var rivoLanguage: String by mutableStateOf(prefs.getString("rivo_language", "ar") ?: "ar")
        private set

    var rivoDialect: String by mutableStateOf(prefs.getString("rivo_dialect", "EG") ?: "EG")
        private set

    var rivoSuggestedDialect: String by mutableStateOf(prefs.getString("rivo_suggested_dialect", "EG") ?: "EG")
        private set

    var rivoVoiceId: String by mutableStateOf(prefs.getString("rivo_voice_id", "rivo_warm_male") ?: "rivo_warm_male")
        private set

    var rivoSpeechRate: Float by mutableStateOf(prefs.getFloat("rivo_speech_rate", 0.95f))
        private set

    var rivoVolume: Float by mutableStateOf(prefs.getFloat("rivo_volume", 1.0f))
        private set

    var userCountryCode: String by mutableStateOf(prefs.getString("user_country_code", "") ?: "")
        private set

    var userCountryName: String by mutableStateOf(prefs.getString("user_country_name", "") ?: "")
        private set

    var userTimezoneId: String by mutableStateOf(
        prefs.getString("user_timezone_id", java.util.TimeZone.getDefault().id) ?: java.util.TimeZone.getDefault().id
    )
        private set

    var use24HourFormat: Boolean by mutableStateOf(prefs.getBoolean("use_24h_format", false))
        private set

    var dateFormatPattern: String by mutableStateOf(prefs.getString("date_format_pattern", "dd/MM/yyyy") ?: "dd/MM/yyyy")
        private set

    fun updateRivoSettings(
        language: String = rivoLanguage,
        dialect: String = rivoDialect,
        voiceId: String = rivoVoiceId,
        speechRate: Float = rivoSpeechRate,
        volume: Float = rivoVolume
    ) {
        rivoLanguage = language
        rivoDialect = dialect
        rivoVoiceId = voiceId
        rivoSpeechRate = speechRate.coerceIn(0.6f, 1.4f)
        rivoVolume = volume.coerceIn(0.2f, 1.0f)
        prefs.edit()
            .putString("rivo_language", rivoLanguage)
            .putString("rivo_dialect", rivoDialect)
            .putString("rivo_voice_id", rivoVoiceId)
            .putFloat("rivo_speech_rate", rivoSpeechRate)
            .putFloat("rivo_volume", rivoVolume)
            .apply()
    }

    fun updateSuggestedDialect(suggested: String) {
        rivoSuggestedDialect = suggested
        prefs.edit().putString("rivo_suggested_dialect", suggested).apply()
    }

    fun updateRegionalSettings(
        countryCode: String = userCountryCode,
        countryName: String = userCountryName,
        timezoneId: String = userTimezoneId,
        is24Hour: Boolean = use24HourFormat,
        datePattern: String = dateFormatPattern
    ) {
        userCountryCode = countryCode
        userCountryName = countryName
        userTimezoneId = timezoneId
        use24HourFormat = is24Hour
        dateFormatPattern = datePattern
        prefs.edit()
            .putString("user_country_code", countryCode)
            .putString("user_country_name", countryName)
            .putString("user_timezone_id", timezoneId)
            .putBoolean("use_24h_format", is24Hour)
            .putString("date_format_pattern", datePattern)
            .apply()
    }

    var breakfastTime: String by mutableStateOf(prefs.getString("meal_breakfast_time", "") ?: "")
        private set
    var lunchTime: String by mutableStateOf(prefs.getString("meal_lunch_time", "") ?: "")
        private set
    var dinnerTime: String by mutableStateOf(prefs.getString("meal_dinner_time", "") ?: "")
        private set

    fun updateMealTimes(
        breakfast: String = breakfastTime,
        lunch: String = lunchTime,
        dinner: String = dinnerTime
    ) {
        breakfastTime = breakfast.trim()
        lunchTime = lunch.trim()
        dinnerTime = dinner.trim()
        prefs.edit()
            .putString("meal_breakfast_time", breakfastTime)
            .putString("meal_lunch_time", lunchTime)
            .putString("meal_dinner_time", dinnerTime)
            .apply()
    }

    companion object {
        fun getActiveUserId(context: Context): String? {
            val prefs = context.getSharedPreferences("mr7_user_prefs", Context.MODE_PRIVATE)
            return prefs.getString("active_user_id", null)
        }
    }
}
