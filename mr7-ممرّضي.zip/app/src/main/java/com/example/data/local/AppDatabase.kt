package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserAccountEntity::class,
        AdminLogEntity::class,
        SystemAnnouncementEntity::class,
        UserReportEntity::class,
        MedicationKnowledgeEntity::class,
        FeatureFlagEntity::class,
        MedicationEntity::class,
        DoseLogEntity::class,
        DoctorEntity::class,
        AppointmentEntity::class,
        AllergyEntity::class,
        FamilyMemberEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userAccountDao(): UserAccountDao
    abstract fun adminLogDao(): AdminLogDao
    abstract fun systemAnnouncementDao(): SystemAnnouncementDao
    abstract fun userReportDao(): UserReportDao
    abstract fun medicationKnowledgeDao(): MedicationKnowledgeDao
    abstract fun featureFlagDao(): FeatureFlagDao
    abstract fun medicationDao(): MedicationDao
    abstract fun doseLogDao(): DoseLogDao
    abstract fun doctorDao(): DoctorDao
    abstract fun appointmentDao(): AppointmentDao
    abstract fun allergyDao(): AllergyDao
    abstract fun familyDao(): FamilyDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mr7_momaredi_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
