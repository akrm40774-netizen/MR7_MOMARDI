package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_accounts")
data class UserAccountEntity(
    @PrimaryKey val userId: String, // e.g. "usr_123456"
    val name: String,
    val email: String,
    val passwordHash: String = "",
    val hasEmailAuth: Boolean = true,
    val hasGoogleAuth: Boolean = false,
    val googleId: String? = null,
    val hasFacebookAuth: Boolean = false,
    val facebookId: String? = null,
    val avatarUrl: String? = null,
    val isBanned: Boolean = false,
    val banType: String? = null, // "TEMPORARY" or "PERMANENT"
    val banReason: String? = null,
    val banEndMillis: Long? = null,
    val role: String = "USER", // "SUPER_ADMIN", "ADMIN", "USER"
    val lastActiveMillis: Long = System.currentTimeMillis(),
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "admin_logs")
data class AdminLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val adminId: String = "777",
    val adminEmail: String = "mr7.mr.mor3eb@gmail.com",
    val action: String, // "BAN_USER", "UNBAN_USER", "CREATE_ANNOUNCEMENT", "TOGGLE_FEATURE_FLAG"
    val affectedUserId: String? = null,
    val affectedUserName: String? = null,
    val details: String,
    val timestampMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "system_announcements")
data class SystemAnnouncementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val icon: String = "📢",
    val targetAudience: String = "ALL",
    val isActive: Boolean = true,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_reports")
data class UserReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val userName: String,
    val userEmail: String = "",
    val title: String,
    val description: String,
    val status: String = "NEW", // "NEW", "UNDER_REVIEW", "FIXING", "RESOLVED"
    val appVersion: String = "1.0",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "medication_knowledge")
data class MedicationKnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val officialName: String,
    val category: String,
    val description: String,
    val sideEffects: String = "",
    val defaultDosage: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "feature_flags")
data class FeatureFlagEntity(
    @PrimaryKey val key: String,
    val name: String,
    val isEnabled: Boolean = true,
    val category: String = "SYSTEM"
)

@Entity(tableName = "medications")
data class MedicationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "",
    val officialName: String,
    val userNickname: String,
    val concentration: String,
    val form: String, // "حبة", "شراب", "حقنة", "مرهم", "قطرة"
    val instructions: String,
    val timesOfDay: String, // comma separated times e.g. "08:00, 20:00"
    val stockCount: Int,
    val refillThreshold: Int = 5,
    val startDateMillis: Long = System.currentTimeMillis(),
    val endDateMillis: Long? = null,
    val isArchived: Boolean = false,
    val imageUri: String? = null,
    val notes: String = ""
)

@Entity(tableName = "dose_logs")
data class DoseLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "",
    val medicationId: Long,
    val medicationName: String,
    val scheduledTime: String, // e.g. "08:00 ص"
    val scheduledDate: String, // YYYY-MM-DD
    val timestampMillis: Long,
    val status: String, // "CONFIRMED", "SNOOZED", "PENDING", "MISSED"
    val confirmedTimeMillis: Long? = null
)

@Entity(tableName = "doctors")
data class DoctorEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "",
    val name: String,
    val specialty: String,
    val clinicAddress: String,
    val phone: String,
    val mapUrl: String = "",
    val notes: String = ""
)

@Entity(tableName = "appointments")
data class AppointmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "",
    val doctorId: Long = 0,
    val doctorName: String,
    val specialty: String = "",
    val clinicAddress: String = "",
    val appointmentTimeMillis: Long,
    val dateDisplay: String,
    val timeDisplay: String,
    val notes: String = "",
    val reminderOffsetHours: Int = 2,
    val isCompleted: Boolean = false
)

@Entity(tableName = "allergies")
data class AllergyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "",
    val allergyName: String,
    val severity: String, // "عالية", "متوسطة", "طفيفة"
    val notes: String = ""
)

@Entity(tableName = "family_members")
data class FamilyMemberEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String = "",
    val name: String,
    val relation: String, // "أبي", "أمي", "ابني", "ابنتي", "زوجتي"
    val pairCode: String,
    val status: String, // "REGULAR", "WARNING", "UNCONFIRMED"
    val lastActive: String,
    val allowMeds: Boolean = true,
    val allowAppointments: Boolean = true,
    val allowHistory: Boolean = true,
    val allowAllergies: Boolean = false,
    val unconfirmedCount: Int = 0
)
