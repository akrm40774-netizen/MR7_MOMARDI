package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

object Mr7AlarmScheduler {
    private const val TAG = "Mr7AlarmScheduler"

    const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
    const val EXTRA_REMINDER_TITLE = "extra_reminder_title"
    const val EXTRA_REMINDER_MESSAGE = "extra_reminder_message"
    const val EXTRA_REMINDER_TYPE = "extra_reminder_type"
    const val EXTRA_ITEM_ID = "extra_item_id"

    const val TYPE_MEDICATION = "MEDICATION"
    const val TYPE_APPOINTMENT = "APPOINTMENT"

    /**
     * Check if exact alarms can be scheduled on Android 12+ (API 31+)
     */
    fun canScheduleExactAlarms(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            alarmManager?.canScheduleExactAlarms() ?: false
        } else {
            true
        }
    }

    /**
     * Schedule a real Android exact alarm for a medication dose
     */
    fun scheduleMedicationReminder(
        context: Context,
        doseId: Long,
        medicationName: String,
        instructions: String,
        triggerAtMillis: Long
    ) {
        if (triggerAtMillis <= System.currentTimeMillis()) {
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, Mr7ReminderReceiver::class.java).apply {
            putExtra(EXTRA_NOTIFICATION_ID, (10000 + doseId).toInt())
            putExtra(EXTRA_REMINDER_TITLE, "💊 موعد دواء: $medicationName")
            putExtra(EXTRA_REMINDER_MESSAGE, instructions.ifBlank { "حان موعد تناول جرعتك المقررة الآن للحفاظ على صحتك." })
            putExtra(EXTRA_REMINDER_TYPE, TYPE_MEDICATION)
            putExtra(EXTRA_ITEM_ID, doseId)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (10000 + doseId).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (canScheduleExactAlarms(context)) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                }
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
            Log.d(TAG, "Scheduled medication alarm for $medicationName at $triggerAtMillis")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException scheduling exact alarm: ${e.message}")
            try {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            } catch (ignored: Exception) {}
        }
    }

    /**
     * Schedule an exact alarm for a doctor appointment (e.g. 1 hour or 15 mins before)
     */
    fun scheduleAppointmentReminder(
        context: Context,
        appointmentId: Long,
        doctorName: String,
        clinicLocation: String,
        triggerAtMillis: Long
    ) {
        if (triggerAtMillis <= System.currentTimeMillis()) {
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, Mr7ReminderReceiver::class.java).apply {
            putExtra(EXTRA_NOTIFICATION_ID, (20000 + appointmentId).toInt())
            putExtra(EXTRA_REMINDER_TITLE, "👨‍⚕️ تذكير موعد طبيب: $doctorName")
            putExtra(EXTRA_REMINDER_MESSAGE, "موعدك في $clinicLocation اقترب. يرجى الاستعداد والتحرك في الموعد.")
            putExtra(EXTRA_REMINDER_TYPE, TYPE_APPOINTMENT)
            putExtra(EXTRA_ITEM_ID, appointmentId)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            (20000 + appointmentId).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (canScheduleExactAlarms(context)) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                }
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule appointment reminder: ${e.message}")
        }
    }

    /**
     * Cancel an existing alarm
     */
    fun cancelReminder(context: Context, notificationId: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, Mr7ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
