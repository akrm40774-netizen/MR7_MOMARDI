package com.example.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

class Mr7ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val CHANNEL_ID_MEDS = "mr7_medication_channel"
        const val CHANNEL_NAME_MEDS = "تنبيهات مواعيد الأدوية"
        const val CHANNEL_DESC_MEDS = "إشعارات دقيقة لتذكيرك بمواعيد تناول الأدوية بانتظام"

        const val CHANNEL_ID_APPS = "mr7_appointment_channel"
        const val CHANNEL_NAME_APPS = "تنبيهات مواعيد الأطباء"
        const val CHANNEL_DESC_APPS = "إشعارات مواعيد العيادات والاستشارات الطبية القادمة"

        fun ensureChannels(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

                val medsChannel = NotificationChannel(
                    CHANNEL_ID_MEDS,
                    CHANNEL_NAME_MEDS,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = CHANNEL_DESC_MEDS
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 200, 500)
                    setSound(soundUri, null)
                }

                val appsChannel = NotificationChannel(
                    CHANNEL_ID_APPS,
                    CHANNEL_NAME_APPS,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = CHANNEL_DESC_APPS
                    enableVibration(true)
                    setSound(soundUri, null)
                }

                notificationManager.createNotificationChannel(medsChannel)
                notificationManager.createNotificationChannel(appsChannel)
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        ensureChannels(context)

        val notificationId = intent.getIntExtra(Mr7AlarmScheduler.EXTRA_NOTIFICATION_ID, 1001)
        val title = intent.getStringExtra(Mr7AlarmScheduler.EXTRA_REMINDER_TITLE) ?: "تذكير صحي — 𝐌𝐑𝟕 ممرّضي"
        val message = intent.getStringExtra(Mr7AlarmScheduler.EXTRA_REMINDER_MESSAGE) ?: "حان موعد تناول الدواء المقرر لك."
        val type = intent.getStringExtra(Mr7AlarmScheduler.EXTRA_REMINDER_TYPE) ?: Mr7AlarmScheduler.TYPE_MEDICATION

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("NAVIGATE_TO", if (type == Mr7AlarmScheduler.TYPE_APPOINTMENT) "APPOINTMENTS" else "MEDICATIONS")
        }

        val contentPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = if (type == Mr7AlarmScheduler.TYPE_APPOINTMENT) CHANNEL_ID_APPS else CHANNEL_ID_MEDS

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .setVibrate(longArrayOf(0, 500, 200, 500))

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            if (notificationManager.areNotificationsEnabled()) {
                notificationManager.notify(notificationId, builder.build())
            }
        } catch (e: SecurityException) {
            // Missing POST_NOTIFICATIONS permission on Android 13+
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
