package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.UserPreferences
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Reschedules all pending medication and appointment alarms upon device reboot
 */
class Mr7BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON" || action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val prefs = UserPreferences(context)
                    val uid = prefs.activeUserId ?: ""
                    if (uid.isNotBlank()) {
                        val db = AppDatabase.getDatabase(context)
                        val now = System.currentTimeMillis()

                        // Reschedule pending doses
                        val pendingDoses = db.doseLogDao().getPendingDosesListForWidget(uid)
                        pendingDoses.forEach { log ->
                            if (log.timestampMillis > now) {
                                Mr7AlarmScheduler.scheduleMedicationReminder(
                                    context = context,
                                    doseId = log.id,
                                    medicationName = log.medicationName,
                                    instructions = "حان موعد تناول جرعتك المقررة الآن.",
                                    triggerAtMillis = log.timestampMillis
                                )
                            }
                        }

                        // Reschedule upcoming appointments
                        val appointments = db.appointmentDao().getUpcomingAppointmentsListForWidget(uid)
                        appointments.forEach { app ->
                            if (app.appointmentTimeMillis > now) {
                                val triggerTime = if (app.appointmentTimeMillis - (60 * 60 * 1000L) > now) {
                                    app.appointmentTimeMillis - (60 * 60 * 1000L)
                                } else {
                                    app.appointmentTimeMillis
                                }
                                Mr7AlarmScheduler.scheduleAppointmentReminder(
                                    context = context,
                                    appointmentId = app.id,
                                    doctorName = app.doctorName,
                                    clinicLocation = app.clinicAddress,
                                    triggerAtMillis = triggerTime
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
