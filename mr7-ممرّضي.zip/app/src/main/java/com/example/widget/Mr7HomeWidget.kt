package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class Mr7HomeWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (ACTION_REFRESH_WIDGET == intent.action || AppWidgetManager.ACTION_APPWIDGET_UPDATE == intent.action) {
            updateAllWidgets(context)
        }
    }

    companion object {
        const val ACTION_REFRESH_WIDGET = "com.example.ACTION_WIDGET_REFRESH"

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, Mr7HomeWidget::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)

            for (appWidgetId in appWidgetIds) {
                updateWidget(context, appWidgetManager, appWidgetId)
            }
        }

        private fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.mr7_widget_layout)

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val uid = com.example.data.UserPreferences.getActiveUserId(context) ?: ""
                    val db = AppDatabase.getDatabase(context)
                    val appointments = if (uid.isNotBlank()) db.appointmentDao().getUpcomingAppointmentsListForWidget(uid) else emptyList()
                    val pendingDoses = if (uid.isNotBlank()) db.doseLogDao().getPendingDosesListForWidget(uid) else emptyList()

                    val now = System.currentTimeMillis()
                    val upcomingAppointment = appointments.firstOrNull { it.appointmentTimeMillis >= now - (2 * 60 * 60 * 1000) }
                    val upcomingDose = pendingDoses.firstOrNull()

                    val intent = Intent(context, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }

                    if (upcomingAppointment != null) {
                        // Priority 1: Doctor Appointment
                        intent.putExtra("navigate_to", "APPOINTMENTS")
                        views.setTextViewText(R.id.widget_event_type, "🩺 موعد الطبيب القادم")
                        views.setTextViewText(R.id.widget_event_title, upcomingAppointment.doctorName)
                        views.setTextViewText(
                            R.id.widget_event_subtitle,
                            if (upcomingAppointment.clinicAddress.isNotBlank()) "📍 ${upcomingAppointment.clinicAddress}" else if (upcomingAppointment.specialty.isNotBlank()) "تخصص: ${upcomingAppointment.specialty}" else "موعد عيادة محدد"
                        )

                        val timeStr = formatMillisToTime(upcomingAppointment.appointmentTimeMillis)
                        views.setTextViewText(R.id.widget_event_time, "🕐 $timeStr")
                        views.setTextViewText(
                            R.id.widget_time_remaining,
                            "⏳ " + calculateRemainingTime(upcomingAppointment.appointmentTimeMillis)
                        )
                    } else if (upcomingDose != null) {
                        // Priority 2: Next Dose
                        intent.putExtra("navigate_to", "HOME")
                        views.setTextViewText(R.id.widget_event_type, "💊 الجرعة القادمة")
                        views.setTextViewText(R.id.widget_event_title, upcomingDose.medicationName)
                        views.setTextViewText(
                            R.id.widget_event_subtitle,
                            "جرعة دواء مسجلة في جدول اليوم"
                        )
                        views.setTextViewText(R.id.widget_event_time, "🕐 ${upcomingDose.scheduledTime}")
                        views.setTextViewText(
                            R.id.widget_time_remaining,
                            "⏳ " + calculateRemainingTime(upcomingDose.timestampMillis)
                        )
                    } else {
                        // Priority 3: All Quiet
                        intent.putExtra("navigate_to", "HOME")
                        views.setTextViewText(R.id.widget_event_type, "💚 كل شيء هادئ الآن")
                        views.setTextViewText(R.id.widget_event_title, "لا توجد جرعات قادمة")
                        views.setTextViewText(R.id.widget_event_subtitle, "صحتك بألف خير، استمتع بليلتك")
                        views.setTextViewText(R.id.widget_event_time, "الوضع مستقر ✨")
                        views.setTextViewText(R.id.widget_time_remaining, "منتظم 🟢")
                    }

                    val pendingIntent = PendingIntent.getActivity(
                        context,
                        0,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

                    appWidgetManager.updateAppWidget(appWidgetId, views)
                } catch (e: Exception) {
                    // Fallback visual UI on exception
                    val fallbackViews = RemoteViews(context.packageName, R.layout.mr7_widget_layout).apply {
                        setTextViewText(R.id.widget_event_type, "💚 𝐌𝐑𝟕 ممرضي")
                        setTextViewText(R.id.widget_event_title, "ممرضك الذكي جاهز")
                        setTextViewText(R.id.widget_event_subtitle, "اضغط لفتح التطبيق")
                    }
                    appWidgetManager.updateAppWidget(appWidgetId, fallbackViews)
                }
            }
        }

        private fun formatMillisToTime(millis: Long): String {
            val sdf = SimpleDateFormat("EEEE hh:mm a", Locale("ar", "EG"))
            return sdf.format(Date(millis))
        }

        private fun calculateRemainingTime(targetMillis: Long): String {
            val diff = targetMillis - System.currentTimeMillis()
            if (diff <= 0) return "الآن أو متأخرة"
            val minutes = diff / (1000 * 60)
            val hours = minutes / 60
            val days = hours / 24

            return when {
                days > 0 -> "خلال $days يوم"
                hours > 0 -> "خلال $hours ساعة"
                else -> "خلال $minutes دقيقة"
            }
        }
    }
}
