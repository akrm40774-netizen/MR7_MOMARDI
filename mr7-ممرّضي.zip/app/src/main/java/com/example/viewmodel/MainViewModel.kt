package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiService
import com.example.ai.TtsHelper
import com.example.ai.VisionScanResult
import com.example.data.SuperAdminConfig
import com.example.data.UserPreferences
import com.example.data.local.*
import com.example.data.repository.Mr7Repository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = Mr7Repository(db)
    val userPreferences = UserPreferences(application)
    val ttsHelper = TtsHelper(application)
    val geminiService = GeminiService()

    // Active User ID flow
    private val _currentUserId = MutableStateFlow(userPreferences.activeUserId ?: "")
    val currentUserId: StateFlow<String> = _currentUserId.asStateFlow()

    // Auth & Account State
    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _syncSuccessMessage = MutableStateFlow<String?>(null)
    val syncSuccessMessage: StateFlow<String?> = _syncSuccessMessage.asStateFlow()

    // User-Scoped Data Flows
    val currentUserAccount: StateFlow<UserAccountEntity?> = _currentUserId
        .flatMapLatest { uid ->
            if (uid.isBlank()) flowOf<UserAccountEntity?>(null)
            else flow { emit(repository.getUserAccount(uid)) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeMedications: StateFlow<List<MedicationEntity>> = _currentUserId
        .flatMapLatest { uid -> if (uid.isBlank()) flowOf(emptyList()) else repository.getActiveMedications(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedMedications: StateFlow<List<MedicationEntity>> = _currentUserId
        .flatMapLatest { uid -> if (uid.isBlank()) flowOf(emptyList()) else repository.getArchivedMedications(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayDoseLogs: StateFlow<List<DoseLogEntity>> = _currentUserId
        .flatMapLatest { uid -> if (uid.isBlank()) flowOf(emptyList()) else repository.getTodayDoseLogs(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDoctors: StateFlow<List<DoctorEntity>> = _currentUserId
        .flatMapLatest { uid -> if (uid.isBlank()) flowOf(emptyList()) else repository.getAllDoctors(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val upcomingAppointments: StateFlow<List<AppointmentEntity>> = _currentUserId
        .flatMapLatest { uid -> if (uid.isBlank()) flowOf(emptyList()) else repository.getUpcomingAppointments(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAllergies: StateFlow<List<AllergyEntity>> = _currentUserId
        .flatMapLatest { uid -> if (uid.isBlank()) flowOf(emptyList()) else repository.getAllAllergies(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val familyMembers: StateFlow<List<FamilyMemberEntity>> = _currentUserId
        .flatMapLatest { uid -> if (uid.isBlank()) flowOf(emptyList()) else repository.getAllFamilyMembers(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Super Admin Data Flows
    val allUsersList: StateFlow<List<UserAccountEntity>> = repository.getAllUsersFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bannedUsersList: StateFlow<List<UserAccountEntity>> = repository.getBannedUsersFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminLogs: StateFlow<List<AdminLogEntity>> = repository.getAdminLogsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<SystemAnnouncementEntity>> = repository.getAnnouncementsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userReports: StateFlow<List<UserReportEntity>> = repository.getReportsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val medicationKnowledge: StateFlow<List<MedicationKnowledgeEntity>> = repository.getKnowledgeFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val featureFlags: StateFlow<List<FeatureFlagEntity>> = repository.getFeatureFlagsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isSuperAdmin: Boolean
        get() = SuperAdminConfig.isSuperAdminUser(userPreferences.activeUserEmail, userPreferences.activeUserId)

    // Voice Assistant State
    private val _voiceMessages = MutableStateFlow<List<Pair<String, String>>>(
        listOf("MR7" to "أهلاً بك! أنا ممرّضي، مساعدك الصحي الشخصي. كيف يمكنني مساعدتك اليوم؟")
    )
    val voiceMessages: StateFlow<List<Pair<String, String>>> = _voiceMessages.asStateFlow()

    private val _isVoiceProcessing = MutableStateFlow(false)
    val isVoiceProcessing: StateFlow<Boolean> = _isVoiceProcessing.asStateFlow()

    private val _isVoiceBottomSheetOpen = MutableStateFlow(false)
    val isVoiceBottomSheetOpen: StateFlow<Boolean> = _isVoiceBottomSheetOpen.asStateFlow()

    // Vision OCR State
    private val _visionScanResult = MutableStateFlow<VisionScanResult?>(null)
    val visionScanResult: StateFlow<VisionScanResult?> = _visionScanResult.asStateFlow()

    private val _isVisionAnalyzing = MutableStateFlow(false)
    val isVisionAnalyzing: StateFlow<Boolean> = _isVisionAnalyzing.asStateFlow()

    // "What should I do now?" summary
    private val _whatShouldIDoNowSummary = MutableStateFlow<String?>(null)
    val whatShouldIDoNowSummary: StateFlow<String?> = _whatShouldIDoNowSummary.asStateFlow()

    // 15-Minute Doctor Appointment In-App Popup Reminder State
    private val _dismissedAppointmentReminderIds = MutableStateFlow<Set<Long>>(emptySet())
    val activeAppointmentReminder: StateFlow<AppointmentEntity?> = combine(
        upcomingAppointments,
        _dismissedAppointmentReminderIds
    ) { appointments, dismissedIds ->
        val now = System.currentTimeMillis()
        val fifteenMinutesMs = 15 * 60 * 1000L
        val marginMs = 2 * 60 * 1000L

        appointments.find { app ->
            if (app.isCompleted || dismissedIds.contains(app.id)) return@find false
            val diff = app.appointmentTimeMillis - now
            val isWithin15Min = diff in 0..(fifteenMinutesMs + marginMs)
            val isTodayAndClose = app.dateDisplay == "اليوم" && diff > 0 && diff <= (fifteenMinutesMs + marginMs)
            isWithin15Min || isTodayAndClose
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun dismissAppointmentReminder(appId: Long) {
        val updated = _dismissedAppointmentReminderIds.value.toMutableSet()
        updated.add(appId)
        _dismissedAppointmentReminderIds.value = updated
    }

    // AUTHENTICATION METHODS
    fun signInUser(emailInput: String, passwordInput: String) {
        if (emailInput.isBlank() || passwordInput.isBlank()) {
            _authError.value = "يرجى إدخال اسم المستخدم/البريد وكلمة المرور"
            return
        }
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            val result = repository.authenticateUser(emailInput, passwordInput)
            _isAuthLoading.value = false
            result.onSuccess { account ->
                userPreferences.loginSession(account.userId, account.name, account.email)
                _currentUserId.value = account.userId
                _voiceMessages.value = listOf("MR7" to "أهلاً يا ${account.name}! أنا ممرّضي، مساعدك الشخصي.")
            }.onFailure { err ->
                _authError.value = err.message ?: "فشل تسجيل الدخول"
            }
        }
    }

    fun signUpUser(nameInput: String, emailInput: String, passwordInput: String) {
        if (nameInput.isBlank() || emailInput.isBlank() || passwordInput.isBlank()) {
            _authError.value = "جميع الحقول مطلوبة لإنشاء الحساب"
            return
        }
        if (passwordInput.length < 4) {
            _authError.value = "كلمة المرور يجب أن تكون 4 خانات على الأقل"
            return
        }
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            val result = repository.createAccount(nameInput, emailInput, passwordInput)
            _isAuthLoading.value = false
            result.onSuccess { account ->
                userPreferences.loginSession(account.userId, account.name, account.email)
                _currentUserId.value = account.userId
                _voiceMessages.value = listOf("MR7" to "أهلاً يا ${account.name}! تم إنشاء حسابك بنجاح.")
            }.onFailure { err ->
                _authError.value = err.message ?: "فشل إنشاء الحساب"
            }
        }
    }

    fun signInWithGoogle(email: String, name: String, googleId: String) {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            val result = repository.authenticateWithGoogle(email, name, googleId)
            _isAuthLoading.value = false
            result.onSuccess { account ->
                userPreferences.loginSession(account.userId, account.name, account.email)
                _currentUserId.value = account.userId
                _voiceMessages.value = listOf("MR7" to "مرحباً يا ${account.name}! تم الدخول بواسطة Google بنجاح.")
            }.onFailure { err ->
                _authError.value = err.message ?: "فشل تسجيل الدخول بواسطة Google"
            }
        }
    }

    fun signInWithFacebook(email: String, name: String, facebookId: String) {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            val result = repository.authenticateWithFacebook(email, name, facebookId)
            _isAuthLoading.value = false
            result.onSuccess { account ->
                userPreferences.loginSession(account.userId, account.name, account.email)
                _currentUserId.value = account.userId
                _voiceMessages.value = listOf("MR7" to "مرحباً يا ${account.name}! تم الدخول بواسطة Facebook بنجاح.")
            }.onFailure { err ->
                _authError.value = err.message ?: "فشل تسجيل الدخول بواسطة Facebook"
            }
        }
    }

    fun toggleLinkGoogle(googleId: String, email: String) {
        val uid = _currentUserId.value
        if (uid.isBlank()) return
        viewModelScope.launch {
            val result = repository.toggleLinkGoogle(uid, googleId, email)
            result.onSuccess {
                _syncSuccessMessage.value = "تم تحديث ربط حساب Google بنجاح 🔵"
                kotlinx.coroutines.delay(3000)
                _syncSuccessMessage.value = null
            }
        }
    }

    fun toggleLinkFacebook(facebookId: String, email: String) {
        val uid = _currentUserId.value
        if (uid.isBlank()) return
        viewModelScope.launch {
            val result = repository.toggleLinkFacebook(uid, facebookId, email)
            result.onSuccess {
                _syncSuccessMessage.value = "تم تحديث ربط حساب Facebook بنجاح 🔷"
                kotlinx.coroutines.delay(3000)
                _syncSuccessMessage.value = null
            }
        }
    }

    fun quickDemoLogin() {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            val demoEmail = "demo_user@mr7.app"
            val demoPass = "demo123"
            var result = repository.authenticateUser(demoEmail, demoPass)
            if (result.isFailure) {
                result = repository.createAccount("مستخدم تجريبي", demoEmail, demoPass)
            }
            _isAuthLoading.value = false
            result.onSuccess { account ->
                userPreferences.loginSession(account.userId, account.name, account.email)
                _currentUserId.value = account.userId
                _voiceMessages.value = listOf("MR7" to "أهلاً يا ${account.name}! مرحباً بك في ممرّضي.")
            }.onFailure { err ->
                _authError.value = err.message ?: "تعذر الدخول التجريبي"
            }
        }
    }

    fun signOutUser() {
        userPreferences.logoutSession()
        _currentUserId.value = ""
        _authError.value = null
    }

    fun deleteAccount() {
        val uid = _currentUserId.value
        if (uid.isNotBlank()) {
            viewModelScope.launch {
                repository.deleteUserAccount(uid)
                signOutUser()
            }
        }
    }

    fun syncDataNow() {
        viewModelScope.launch {
            _isSyncing.value = true
            kotlinx.coroutines.delay(1200) // Simulate secure cloud sync
            _isSyncing.value = false
            _syncSuccessMessage.value = "تمت مزامنة بيانات حسابك وحفظها بنجاح ☁️"
            kotlinx.coroutines.delay(3000)
            _syncSuccessMessage.value = null
        }
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun openVoiceBottomSheet() {
        _isVoiceBottomSheetOpen.value = true
    }

    fun closeVoiceBottomSheet() {
        _isVoiceBottomSheetOpen.value = false
        ttsHelper.stop()
    }

    fun sendVoiceQuery(userInput: String) {
        if (userInput.isBlank()) return
        val current = _voiceMessages.value.toMutableList()
        current.add("USER" to userInput)
        _voiceMessages.value = current

        viewModelScope.launch {
            _isVoiceProcessing.value = true
            val meds = activeMedications.value
            val history = current.map { it.first to it.second }
            val reply = geminiService.processVoiceChat(userInput, meds, history, userPreferences.isSeniorMode)
            _isVoiceProcessing.value = false

            val updated = _voiceMessages.value.toMutableList()
            updated.add("MR7" to reply)
            _voiceMessages.value = updated

            ttsHelper.speak(reply)
        }
    }

    fun analyzeImageWithVision(bitmap: Bitmap, scanType: String) {
        viewModelScope.launch {
            _isVisionAnalyzing.value = true
            _visionScanResult.value = null
            val result = geminiService.analyzePrescriptionOrPackage(bitmap, scanType)
            _isVisionAnalyzing.value = false
            _visionScanResult.value = result
        }
    }

    fun clearVisionResult() {
        _visionScanResult.value = null
    }

    fun confirmDose(logId: Long) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.updateDoseStatus(logId, "CONFIRMED", uid)
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun snoozeDose(logId: Long) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.updateDoseStatus(logId, "SNOOZED", uid)
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun addMedication(med: MedicationEntity) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.insertMedication(med.copy(userId = uid))
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun archiveMedication(medId: Long) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.setArchived(medId, true, uid)
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun unarchiveMedication(medId: Long) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.setArchived(medId, false, uid)
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun updateStock(medId: Long, newStock: Int) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.updateStock(medId, newStock, uid)
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun addDoctor(doc: DoctorEntity) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.insertDoctor(doc.copy(userId = uid))
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun addAppointment(app: AppointmentEntity) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.insertAppointment(app.copy(userId = uid))
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun completeAppointment(appId: Long) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.setAppointmentCompleted(appId, true, uid)
            com.example.widget.Mr7HomeWidget.updateAllWidgets(getApplication())
        }
    }

    fun addAllergy(allergy: AllergyEntity) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.insertAllergy(allergy.copy(userId = uid))
        }
    }

    fun deleteAllergy(allergy: AllergyEntity) {
        viewModelScope.launch {
            repository.deleteAllergy(allergy)
        }
    }

    fun addFamilyMember(member: FamilyMemberEntity) {
        val uid = _currentUserId.value
        viewModelScope.launch {
            repository.insertFamilyMember(member.copy(userId = uid))
        }
    }

    fun updateFamilyMember(member: FamilyMemberEntity) {
        viewModelScope.launch {
            repository.updateFamilyMember(member)
        }
    }

    fun computeWhatShouldIDoNow() {
        val pendingDoses = todayDoseLogs.value.filter { it.status == "PENDING" || it.status == "SNOOZED" }
        val upcomingApps = upcomingAppointments.value.filter { !it.isCompleted }

        val summary = when {
            pendingDoses.isNotEmpty() -> {
                val nextDose = pendingDoses.first()
                "💊 لديك جرعة مسجلة حاليًا لدواء: ${nextDose.medicationName} (${nextDose.scheduledTime}). اضغط لتأكيد الجرعة أو تأجيلها."
            }
            upcomingApps.isNotEmpty() -> {
                val nextApp = upcomingApps.first()
                "🩺 لديك موعد طبي قادم: ${nextApp.doctorName} (${nextApp.timeDisplay} - ${nextApp.dateDisplay})."
            }
            else -> {
                "✅ ممتاز! لقد أكملت جميع الجرعات والمواعيد المسجلة لهذا الوقت من اليوم."
            }
        }
        _whatShouldIDoNowSummary.value = summary
    }

    fun dismissWhatShouldIDoNow() {
        _whatShouldIDoNowSummary.value = null
    }

    // Admin Action Methods
    fun banUser(targetUserId: String, banType: String, reason: String, durationDays: Int? = null) {
        viewModelScope.launch {
            val result = repository.banUser(targetUserId, banType, reason, durationDays, adminId = userPreferences.activeUserId ?: SuperAdminConfig.ADMIN_ID)
            result.onSuccess {
                _syncSuccessMessage.value = "تم حظر المستخدم بنجاح 🚫"
                delay(3000)
                _syncSuccessMessage.value = null
            }.onFailure { err ->
                _authError.value = err.message
            }
        }
    }

    fun unbanUser(targetUserId: String) {
        viewModelScope.launch {
            val result = repository.unbanUser(targetUserId, adminId = userPreferences.activeUserId ?: SuperAdminConfig.ADMIN_ID)
            result.onSuccess {
                _syncSuccessMessage.value = "تم فك الحظر عن المستخدم بنجاح ✅"
                delay(3000)
                _syncSuccessMessage.value = null
            }.onFailure { err ->
                _authError.value = err.message
            }
        }
    }

    fun createAnnouncement(title: String, message: String, icon: String = "📢", audience: String = "ALL") {
        viewModelScope.launch {
            repository.addAnnouncement(title, message, icon, audience)
            _syncSuccessMessage.value = "تم نشر الإعلان للجميع بنجاح 📢"
            delay(3000)
            _syncSuccessMessage.value = null
        }
    }

    fun toggleAnnouncement(id: Long, isActive: Boolean) {
        viewModelScope.launch {
            repository.toggleAnnouncementStatus(id, isActive)
        }
    }

    fun submitReport(title: String, description: String) {
        viewModelScope.launch {
            repository.submitUserReport(
                userId = userPreferences.activeUserId ?: "guest",
                userName = userPreferences.userName,
                email = userPreferences.activeUserEmail,
                title = title,
                description = description
            )
            _syncSuccessMessage.value = "تم تقديم البلاغ بنجاح! سيتم مراجعته بواسطة الإدارة."
            delay(3000)
            _syncSuccessMessage.value = null
        }
    }

    fun updateReportStatus(id: Long, status: String) {
        viewModelScope.launch {
            repository.updateReportStatus(id, status)
        }
    }

    fun addKnowledge(name: String, category: String, desc: String, sideEffects: String, dosage: String) {
        viewModelScope.launch {
            repository.addMedicationKnowledge(name, category, desc, sideEffects, dosage)
        }
    }

    fun deleteKnowledge(item: MedicationKnowledgeEntity) {
        viewModelScope.launch {
            repository.deleteMedicationKnowledge(item)
        }
    }

    fun setFeatureFlag(key: String, name: String, isEnabled: Boolean, category: String = "SYSTEM") {
        viewModelScope.launch {
            repository.setFeatureFlag(key, name, isEnabled, category)
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsHelper.shutdown()
    }
}
