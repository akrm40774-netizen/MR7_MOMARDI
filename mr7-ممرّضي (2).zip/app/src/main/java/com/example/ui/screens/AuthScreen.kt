package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.example.ui.theme.LocalThemeTokens
import com.example.viewmodel.MainViewModel
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch

private enum class AuthFormMode {
    CHOOSE_METHOD,
    EMAIL_FORM
}

@Composable
fun AuthScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val tokens = LocalThemeTokens.current
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isSenior = viewModel.userPreferences.isSeniorMode
    val authError by viewModel.authError.collectAsState()
    val isLoading by viewModel.isAuthLoading.collectAsState()

    var isSignUpTab by remember { mutableStateOf(false) }
    var activeFormMode by remember { mutableStateOf(AuthFormMode.EMAIL_FORM) }

    // Email Input fields
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    // Dialogs
    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var showGoogleNoticeDialog by remember { mutableStateOf(false) }
    var showFacebookDialog by remember { mutableStateOf(false) }
    var fbEmailInput by remember { mutableStateOf("") }

    // Function to launch native Google Identity Credential Manager
    fun launchNativeGoogleSignIn() {
        coroutineScope.launch {
            val webClientId = try {
                com.example.BuildConfig.GOOGLE_WEB_CLIENT_ID
            } catch (e: Throwable) {
                ""
            }

            if (webClientId.isNullOrBlank() || !webClientId.contains(".apps.googleusercontent.com") || webClientId.contains("dummy")) {
                showGoogleNoticeDialog = true
                return@launch
            }

            try {
                val credentialManager = CredentialManager.create(context)
                val googleIdOption = GetSignInWithGoogleOption.Builder(webClientId)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(context = context, request = request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val email = googleIdTokenCredential.id
                    val name = googleIdTokenCredential.displayName ?: email.substringBefore("@")
                    val googleId = googleIdTokenCredential.idToken.take(32)
                    viewModel.signInWithGoogle(email = email, name = name, googleId = googleId)
                }
            } catch (e: GetCredentialCancellationException) {
                // User cancelled the prompt; no error message needed
            } catch (e: NoCredentialException) {
                showGoogleNoticeDialog = true
            } catch (e: Throwable) {
                showGoogleNoticeDialog = true
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(tokens.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // App Brand Header
            Surface(
                shape = CircleShape,
                color = tokens.primary.copy(alpha = 0.15f),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = null,
                        tint = tokens.primary,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "𝐌𝐑𝟕 ممرّضي",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = tokens.textPrimary,
                    fontSize = if (isSenior) 32.sp else 26.sp
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "نظام الحسابات الآمنة وحفظ البيانات المستقلة",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = tokens.textSecondary,
                    fontSize = if (isSenior) 16.sp else 14.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Main Auth Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = tokens.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Auth Tab Switcher (Sign In vs Sign Up)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(tokens.surfaceElevated)
                            .padding(4.dp)
                    ) {
                        Button(
                            onClick = {
                                isSignUpTab = false
                                viewModel.clearAuthError()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isSignUpTab) tokens.primary else Color.Transparent,
                                contentColor = if (!isSignUpTab) Color.White else tokens.textSecondary
                            ),
                            elevation = null
                        ) {
                            Text(
                                "تسجيل الدخول",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 17.sp else 14.sp
                            )
                        }

                        Button(
                            onClick = {
                                isSignUpTab = true
                                viewModel.clearAuthError()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSignUpTab) tokens.primary else Color.Transparent,
                                contentColor = if (isSignUpTab) Color.White else tokens.textSecondary
                            ),
                            elevation = null
                        ) {
                            Text(
                                "إنشاء حساب جديد",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 17.sp else 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = if (!isSignUpTab) "👤 تسجيل الدخول إلى 𝐌𝐑𝟕 ممرّضي" else "🆕 إنشاء حساب في 𝐌𝐑𝟕 ممرّضي",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = tokens.textPrimary,
                            fontSize = if (isSenior) 20.sp else 17.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Error Banner if present
                    authError?.let { err ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = tokens.error.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, tokens.error.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = tokens.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = err,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = tokens.error,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }
                    }

                    // 1. Google Official Native Button
                    OutlinedButton(
                        onClick = { launchNativeGoogleSignIn() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.White,
                            contentColor = Color(0xFF1F1F1F)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDADCE0)),
                        enabled = !isLoading
                    ) {
                        GoogleLogoIcon(modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (!isSignUpTab) "متابعة بحساب Google" else "إنشاء حساب بواسطة Google",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 15.sp,
                            color = Color(0xFF3C4043)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. Facebook Official Button
                    Button(
                        onClick = { showFacebookDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1877F2),
                            contentColor = Color.White
                        ),
                        enabled = !isLoading
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "f",
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1877F2),
                                    fontSize = 17.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (!isSignUpTab) "متابعة بحساب Facebook" else "إنشاء حساب بواسطة Facebook",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 15.sp,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Divider with "أو عبر البريد الإلكتروني"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HorizontalDivider(modifier = Modifier.weight(1f), color = tokens.cardBorder)
                        Text(
                            text = "  أو عبر البريد الإلكتروني  ",
                            style = MaterialTheme.typography.bodySmall.copy(color = tokens.textSecondary)
                        )
                        HorizontalDivider(modifier = Modifier.weight(1f), color = tokens.cardBorder)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Direct Email Form (Clean, Secure, Validated)
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isSignUpTab) {
                            OutlinedTextField(
                                value = nameInput,
                                onValueChange = { nameInput = it },
                                label = { Text("الاسم بالكامل") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = tokens.primary) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("auth_name_input"),
                                shape = RoundedCornerShape(14.dp),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("البريد الإلكتروني") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = tokens.primary) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_email_input"),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("كلمة المرور") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = tokens.primary) },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_password_input"),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )

                        if (isSignUpTab) {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = confirmPasswordInput,
                                onValueChange = { confirmPasswordInput = it },
                                label = { Text("تأكيد كلمة المرور") },
                                leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null, tint = tokens.primary) },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("auth_confirm_password_input"),
                                shape = RoundedCornerShape(14.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )
                        }

                        if (!isSignUpTab) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { showForgotPasswordDialog = true }) {
                                    Text(
                                        "نسيت كلمة المرور؟",
                                        style = MaterialTheme.typography.bodySmall.copy(color = tokens.primary)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Button for Email Auth
                        Button(
                            onClick = {
                                if (isSignUpTab) {
                                    if (nameInput.isBlank() || emailInput.isBlank() || passwordInput.isBlank()) {
                                        viewModel.showAuthError("يرجى ملء جميع الحقول")
                                        return@Button
                                    }
                                    if (passwordInput != confirmPasswordInput) {
                                        viewModel.showAuthError("كلمات المرور غير متطابقة")
                                        return@Button
                                    }
                                    viewModel.signUpUser(nameInput, emailInput, passwordInput)
                                } else {
                                    if (emailInput.isBlank() || passwordInput.isBlank()) {
                                        viewModel.showAuthError("يرجى إدخال البريد الإلكتروني وكلمة المرور")
                                        return@Button
                                    }
                                    viewModel.signInUser(emailInput, passwordInput)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("auth_submit_btn"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = tokens.primary),
                            enabled = !isLoading
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = if (isSignUpTab) Icons.Default.PersonAdd else Icons.Default.Login,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSignUpTab) "إنشاء الحساب والمتابعة" else "تسجيل الدخول",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = if (isSenior) 17.sp else 15.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Security Note Badge
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = tokens.surfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.cardBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = tokens.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "🔒 عزل كامل للبيانات: يمتلك كل مستخدم قاعدة بيانات وسجلات خاصة به تمامًا ولا يمكن لأي مستخدم آخر الاطلاع عليها.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = tokens.textSecondary,
                            fontSize = if (isSenior) 13.sp else 11.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // --- DIALOG 1: Google Notice / Alternative Dialog ---
        if (showGoogleNoticeDialog) {
            AlertDialog(
                onDismissRequest = { showGoogleNoticeDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GoogleLogoIcon(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تسجيل الدخول بحساب Google")
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "للمتابعة عبر تسجيل الدخول المباشر بحساب Google الرسمي، يتطلب ذلك تسجيل Web Client ID من Google Cloud Console في ملف الإعدادات. يمكنك المتابعة بتسجيل الدخول أو إنشاء حسابك فوراً بالبريد الإلكتروني وكلمة المرور المشفرة بأمان:",
                            style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textPrimary)
                        )
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("بريد Google الإلكتروني") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showGoogleNoticeDialog = false
                            if (emailInput.isNotBlank()) {
                                // Focus on email form with that email
                                activeFormMode = AuthFormMode.EMAIL_FORM
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                    ) {
                        Text("المتابعة بالبريد")
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { showGoogleNoticeDialog = false }) {
                        Text("إغلاق")
                    }
                }
            )
        }

        // --- DIALOG 2: Facebook Sign In Dialog ---
        if (showFacebookDialog) {
            AlertDialog(
                onDismissRequest = { showFacebookDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = Color(0xFF1877F2), modifier = Modifier.size(24.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("f", fontWeight = FontWeight.Black, color = Color.White, fontSize = 16.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("المتابعة بحساب Facebook")
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "أدخل البريد الإلكتروني المرتبط بحسابك على Facebook للربط الآمن:",
                            style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textPrimary)
                        )
                        OutlinedTextField(
                            value = fbEmailInput,
                            onValueChange = { fbEmailInput = it },
                            label = { Text("البريد الإلكتروني لـ Facebook") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (fbEmailInput.isNotBlank()) {
                                showFacebookDialog = false
                                viewModel.signInWithFacebook(
                                    email = fbEmailInput.trim(),
                                    name = fbEmailInput.substringBefore("@").replace(".", " "),
                                    facebookId = "fb_" + fbEmailInput.trim().hashCode()
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1877F2))
                    ) {
                        Text("متابعة", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { showFacebookDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // --- DIALOG 3: Forgot Password ---
        if (showForgotPasswordDialog) {
            AlertDialog(
                onDismissRequest = { showForgotPasswordDialog = false },
                title = { Text("🔑 استعادة كلمة المرور") },
                text = {
                    Text(
                        "في تطبيق MR7 ممرّضي، يمكنك استعادة الوصول إلى حسابك عبر تسجيل الدخول ببريدك الإلكتروني، أو من خلال حساب Google المرتبط بحسابك.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = tokens.textPrimary)
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { showForgotPasswordDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = tokens.primary)
                    ) {
                        Text("حسناً")
                    }
                }
            )
        }
    }
}

@Composable
fun GoogleLogoIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Simple official 4-color Google G icon vector representation
        // Top Red segment
        drawCircle(color = Color(0xFFEA4335), radius = w / 2f)
        // Right Blue segment
        drawPath(
            path = Path().apply {
                moveTo(w / 2f, h / 2f)
                lineTo(w, h / 2f)
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(0f, 0f, w, h),
                    startAngleDegrees = 0f,
                    sweepAngleDegrees = 90f,
                    forceMoveTo = false
                )
                close()
            },
            color = Color(0xFF4285F4)
        )
        // Bottom Green segment
        drawPath(
            path = Path().apply {
                moveTo(w / 2f, h / 2f)
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(0f, 0f, w, h),
                    startAngleDegrees = 90f,
                    sweepAngleDegrees = 90f,
                    forceMoveTo = false
                )
                close()
            },
            color = Color(0xFF34A853)
        )
        // Left Yellow segment
        drawPath(
            path = Path().apply {
                moveTo(w / 2f, h / 2f)
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(0f, 0f, w, h),
                    startAngleDegrees = 180f,
                    sweepAngleDegrees = 90f,
                    forceMoveTo = false
                )
                close()
            },
            color = Color(0xFFFBBC05)
        )
        // Center cutout white
        drawCircle(color = Color.White, radius = w * 0.28f)
    }
}
