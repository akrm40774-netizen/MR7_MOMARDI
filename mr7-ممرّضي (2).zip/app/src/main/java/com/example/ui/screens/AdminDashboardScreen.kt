package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SuperAdminConfig
import com.example.data.local.*
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val isSuperAdmin = viewModel.isSuperAdmin
    var isDashboardUnlocked by remember { mutableStateOf(false) }

    // Dashboard Lock Password Input State
    var adminDashboardPasswordInput by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var passwordVisible by remember { mutableStateOf(false) }

    val activeUserEmail = viewModel.userPreferences.activeUserEmail.ifBlank { SuperAdminConfig.ADMIN_EMAIL_PRIMARY }

    // 1. NON-SUPER ADMIN SECURITY BLOCK
    if (!isSuperAdmin) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "🚫 وصول غير مصرح به!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "عذراً، هذا الحساب ليس لديه صلاحيات Super Admin الوصول إلى لوحة الإدارة.\nيتم التحقق من الصلاحيات والـ Admin ID على مستوى الـ Backend فقط.",
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onErrorContainer, contentColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("العودة إلى التطبيق", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        return
    }

    // 2. DASHBOARD PASSWORD LOCK MODAL / SCREEN
    if (!isDashboardUnlocked) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(42.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "🔑 كلمة سر لوحة الإدارة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "👑 ${SuperAdminConfig.ADMIN_ID}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "مرحباً بالحساب الإداري ($activeUserEmail).\nيرجى إدخال كلمة سر لوحة الإدارة لفتح التحكم الإداري.",
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    passwordError?.let { err ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 14.dp)
                        ) {
                            Text(
                                text = err,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = adminDashboardPasswordInput,
                        onValueChange = {
                            adminDashboardPasswordInput = it
                            passwordError = null
                        },
                        label = { Text("كلمة سر لوحة الإدارة") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = null
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onBack,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("رجوع")
                        }

                        Button(
                            onClick = {
                                if (SuperAdminConfig.verifyDashboardPassword(adminDashboardPasswordInput)) {
                                    isDashboardUnlocked = true
                                    passwordError = null
                                } else {
                                    passwordError = "❌ كلمة سر لوحة الإدارة غير صحيحة!"
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("👑 فتح اللوحة", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    val allUsers by viewModel.allUsersList.collectAsState()
    val bannedUsers by viewModel.bannedUsersList.collectAsState()
    val adminLogs by viewModel.adminLogs.collectAsState()
    val announcements by viewModel.announcements.collectAsState()
    val userReports by viewModel.userReports.collectAsState()
    val knowledgeBase by viewModel.medicationKnowledge.collectAsState()
    val featureFlags by viewModel.featureFlags.collectAsState()
    val syncMessage by viewModel.syncSuccessMessage.collectAsState()
    val authError by viewModel.authError.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedUserFilter by remember { mutableStateOf("ALL") } // ALL, ACTIVE, BANNED

    // Modals state
    var userForDetails by remember { mutableStateOf<UserAccountEntity?>(null) }
    var userForBan by remember { mutableStateOf<UserAccountEntity?>(null) }
    var showCreateAnnouncementDialog by remember { mutableStateOf(false) }
    var showAddKnowledgeDialog by remember { mutableStateOf(false) }

    val tabs = listOf(
        "📊 نظرة عامة",
        "👥 إدارة المستخدمين",
        "📜 سجل الأدمين",
        "📢 الإعلانات",
        "🤖 التحكم بالذكاء الاصطناعي",
        "💊 قاعدة الأدوية",
        "🛠️ البلاغات",
        "⚡ مركز القيادة"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "👑 لوحة الإدارة الرئيسية MR7",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = SuperAdminConfig.ADMIN_ID,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = activeUserEmail,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_btn")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Notification Snackbars
            syncMessage?.let { msg ->
                Surface(
                    color = Color(0xFF2E7D32),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = msg,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            authError?.let { err ->
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = err,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            // Tabs Bar
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            // Main Content Area
            Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                when (selectedTab) {
                    0 -> OverviewTab(
                        allUsersCount = allUsers.size,
                        bannedCount = bannedUsers.size,
                        reportsCount = userReports.size,
                        logsCount = adminLogs.size,
                        announcementsCount = announcements.size
                    )
                    1 -> UserManagementTab(
                        allUsers = allUsers,
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        selectedFilter = selectedUserFilter,
                        onFilterChange = { selectedUserFilter = it },
                        onViewDetails = { userForDetails = it },
                        onBanUser = { userForBan = it },
                        onUnbanUser = { viewModel.unbanUser(it.userId) }
                    )
                    2 -> AdminLogsTab(adminLogs = adminLogs)
                    3 -> AnnouncementsTab(
                        announcements = announcements,
                        onCreateNew = { showCreateAnnouncementDialog = true },
                        onToggleActive = { id, active -> viewModel.toggleAnnouncement(id, active) }
                    )
                    4 -> AiControlCenterTab(
                        featureFlags = featureFlags,
                        onToggleFlag = { key, name, current ->
                            viewModel.setFeatureFlag(key, name, !current)
                        }
                    )
                    5 -> MedicationKnowledgeTab(
                        knowledgeList = knowledgeBase,
                        onAdd = { showAddKnowledgeDialog = true },
                        onDelete = { viewModel.deleteKnowledge(it) }
                    )
                    6 -> ReportsTab(
                        reports = userReports,
                        onUpdateStatus = { id, status -> viewModel.updateReportStatus(id, status) }
                    )
                    7 -> CommandCenterTab()
                }
            }
        }
    }

    // Dialogs
    userForDetails?.let { user ->
        UserDetailsModal(user = user, onDismiss = { userForDetails = null })
    }

    userForBan?.let { user ->
        BanUserModal(
            user = user,
            onDismiss = { userForBan = null },
            onConfirmBan = { type, reason, days ->
                viewModel.banUser(user.userId, type, reason, days)
                userForBan = null
            }
        )
    }

    if (showCreateAnnouncementDialog) {
        CreateAnnouncementModal(
            onDismiss = { showCreateAnnouncementDialog = false },
            onConfirm = { title, msg, icon ->
                viewModel.createAnnouncement(title, msg, icon)
                showCreateAnnouncementDialog = false
            }
        )
    }

    if (showAddKnowledgeDialog) {
        AddKnowledgeModal(
            onDismiss = { showAddKnowledgeDialog = false },
            onConfirm = { name, cat, desc, side, dose ->
                viewModel.addKnowledge(name, cat, desc, side, dose)
                showAddKnowledgeDialog = false
            }
        )
    }
}

// -----------------------------------------------------------------------------
// TAB 1: OVERVIEW & STATS
// -----------------------------------------------------------------------------
@Composable
private fun OverviewTab(
    allUsersCount: Int,
    bannedCount: Int,
    reportsCount: Int,
    logsCount: Int,
    announcementsCount: Int
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "نظام الإدارة المركزي - MR7 ممرّضي",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "التحكم الكامل بالحسابات، الصلاحيات، الأمان، والخدمات التشغيلية",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Text(
                "📈 الإحصائيات والمؤشرات الحية",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatBox(
                        title = "إجمالي المستخدمين",
                        value = "$allUsersCount",
                        icon = Icons.Default.Group,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        title = "الحسابات النشطة",
                        value = "${(allUsersCount - bannedCount).coerceAtLeast(0)}",
                        icon = Icons.Default.CheckCircle,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatBox(
                        title = "الحسابات المحظورة",
                        value = "$bannedCount",
                        icon = Icons.Default.Block,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        title = "البلاغات والتذاكر",
                        value = "$reportsCount",
                        icon = Icons.Default.ReportProblem,
                        color = Color(0xFFED6C02),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatBox(
                        title = "سجل إجراءات الإدارة",
                        value = "$logsCount",
                        icon = Icons.Default.History,
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        title = "الإعلانات النشطة",
                        value = "$announcementsCount",
                        icon = Icons.Default.Campaign,
                        color = Color(0xFF0288D1),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "🔒 معايير الأمان والخصوصية الطبية",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "• يتم التحقق من الصلاحيات الإدارية عبر قاعدة البيانات ولا توجد أي كلمات مرور مخزنة.\n" +
                                "• نظام الخصوصية يحمي الروشتات والسجلات الطبية الخاصة بكل مستخدم ويمنع استعراضها بشكل افتراضي.\n" +
                                "• عند حظر أي حساب، تُحظر إمكانية الدخول ولا تُحذف أي من بيانات المستخدم الطبية.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatBox(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
                Text(
                    value,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
            Text(
                title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// -----------------------------------------------------------------------------
// TAB 2: USER MANAGEMENT & BANNING
// -----------------------------------------------------------------------------
@Composable
private fun UserManagementTab(
    allUsers: List<UserAccountEntity>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedFilter: String,
    onFilterChange: (String) -> Unit,
    onViewDetails: (UserAccountEntity) -> Unit,
    onBanUser: (UserAccountEntity) -> Unit,
    onUnbanUser: (UserAccountEntity) -> Unit
) {
    val filteredUsers = remember(allUsers, searchQuery, selectedFilter) {
        allUsers.filter { user ->
            val matchesSearch = user.name.contains(searchQuery, ignoreCase = true) ||
                    user.email.contains(searchQuery, ignoreCase = true) ||
                    user.userId.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                "ACTIVE" -> !user.isBanned
                "BANNED" -> user.isBanned
                else -> true
            }
            matchesSearch && matchesFilter
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("بحث باسم المستخدم، البريد، أو ID...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "مسح")
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("user_search_input"),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        // Filter Chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = selectedFilter == "ALL",
                onClick = { onFilterChange("ALL") },
                label = { Text("الكل (${allUsers.size})") }
            )
            FilterChip(
                selected = selectedFilter == "ACTIVE",
                onClick = { onFilterChange("ACTIVE") },
                label = { Text("🟢 النشطاء (${allUsers.count { !it.isBanned }})") }
            )
            FilterChip(
                selected = selectedFilter == "BANNED",
                onClick = { onFilterChange("BANNED") },
                label = { Text("🚫 المحظورون (${allUsers.count { it.isBanned }})") }
            )
        }

        if (filteredUsers.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "لا توجد نتائج مطابقة للبحث",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredUsers, key = { it.userId }) { user ->
                    UserCardItem(
                        user = user,
                        onViewDetails = { onViewDetails(user) },
                        onBanUser = { onBanUser(user) },
                        onUnbanUser = { onUnbanUser(user) }
                    )
                }
            }
        }
    }
}

@Composable
private fun UserCardItem(
    user: UserAccountEntity,
    onViewDetails: () -> Unit,
    onBanUser: () -> Unit,
    onUnbanUser: () -> Unit
) {
    val isSuperAdmin = user.role == "SUPER_ADMIN" || user.userId == "777" || user.email == "mr7.mr.mor3eb@gmail.com"

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (user.isBanned) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
            else MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSuperAdmin) MaterialTheme.colorScheme.primary
                                else if (user.isBanned) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.secondary
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isSuperAdmin) "👑" else user.name.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (isSuperAdmin) {
                                Spacer(Modifier.width(6.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "SUPER ADMIN",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = user.email.ifBlank { "بدون بريد" },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // ID badge
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "ID: ${user.userId}",
                        fontSize = 11.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Auth Methods & Status Tags
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (user.hasEmailAuth) AuthTag("✉️ بريد")
                    if (user.hasGoogleAuth) AuthTag("🔵 Google")
                    if (user.hasFacebookAuth) AuthTag("🔷 Facebook")
                }

                if (user.isBanned) {
                    Surface(
                        color = MaterialTheme.colorScheme.error,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (user.banType == "PERMANENT") "🔒 حظر دائم" else "⏱️ حظر مؤقت",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                } else {
                    Surface(
                        color = Color(0xFF2E7D32),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "🟢 نشط",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Action Buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onViewDetails,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("التفاصيل", fontSize = 12.sp)
                }

                if (!isSuperAdmin) {
                    if (user.isBanned) {
                        Button(
                            onClick = onUnbanUser,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("إلغاء الحظر", fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = onBanUser,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("حظر الحساب", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthTag(label: String) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp),
        shape = RoundedCornerShape(4.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

// -----------------------------------------------------------------------------
// TAB 3: ADMIN LOGS
// -----------------------------------------------------------------------------
@Composable
private fun AdminLogsTab(adminLogs: List<AdminLogEntity>) {
    if (adminLogs.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "لا توجد سجلات إدارية مسجلة بعد",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(adminLogs, key = { it.id }) { log ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "الإجراء: ${log.action}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            val timeStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                                .format(Date(log.timestampMillis))
                            Text(
                                text = timeStr,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = log.details,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        log.affectedUserName?.let { name ->
                            Text(
                                text = "المستخدم المتأثر: $name (${log.affectedUserId})",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// TAB 4: ANNOUNCEMENTS
// -----------------------------------------------------------------------------
@Composable
private fun AnnouncementsTab(
    announcements: List<SystemAnnouncementEntity>,
    onCreateNew: () -> Unit,
    onToggleActive: (Long, Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = onCreateNew,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.AddAlert, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("نشر إعلان جديد لجميع المستخدمين")
        }

        if (announcements.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "لم يتم نشر أي إعلانات حتى الآن",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(announcements, key = { it.id }) { ann ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(ann.icon, fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ann.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(ann.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = ann.isActive,
                                onCheckedChange = { onToggleActive(ann.id, it) }
                            )
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// TAB 5: AI CONTROL CENTER
// -----------------------------------------------------------------------------
@Composable
private fun AiControlCenterTab(
    featureFlags: List<FeatureFlagEntity>,
    onToggleFlag: (String, String, Boolean) -> Unit
) {
    val defaultFlags = listOf(
        Triple("mr7_voice", "🎙️ المساعد الصوتي MR7 Voice", true),
        Triple("mr7_vision", "📷 الماسح الضوئي للروشتات MR7 Vision", true),
        Triple("mr7_ocr", "🔍 قارئ علب الأدوية OCR", true),
        Triple("cloud_sync", "☁️ المزمنة والنسخ الاحتياطي السحابي", true)
    )

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "🤖 مركز التحكم بالذكاء الاصطناعي والميزات",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "يمكنك تفعيل أو تعطيل خدمات MR7 Vision و MR7 Voice والميزات الذكية مباشرة من هنا.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(defaultFlags) { (key, title, defaultState) ->
            val flag = featureFlags.find { it.key == key }
            val isEnabled = flag?.isEnabled ?: defaultState

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = if (isEnabled) "🟢 الخدمة مفعلة وتعمل بكفاءة" else "🔴 الخدمة معطلة مؤقتاً من الأدمن",
                            fontSize = 12.sp,
                            color = if (isEnabled) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                        )
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { onToggleFlag(key, title, isEnabled) }
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// TAB 6: MEDICATION KNOWLEDGE BASE
// -----------------------------------------------------------------------------
@Composable
private fun MedicationKnowledgeTab(
    knowledgeList: List<MedicationKnowledgeEntity>,
    onAdd: () -> Unit,
    onDelete: (MedicationKnowledgeEntity) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = onAdd,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("إضافة دواء جديد لقاعدة المعرفة العامة")
        }

        if (knowledgeList.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "قاعدة المعرفة العامة فارغة",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(knowledgeList, key = { it.id }) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.officialName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("التصنيف: ${item.category}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                Text(item.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { onDelete(item) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// TAB 7: REPORTS
// -----------------------------------------------------------------------------
@Composable
private fun ReportsTab(
    reports: List<UserReportEntity>,
    onUpdateStatus: (Long, String) -> Unit
) {
    if (reports.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("لا توجد بلاغات أو مشاكل فنية مرسلة من المستخدمين", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(reports, key = { it.id }) { report ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(report.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Surface(
                                color = when (report.status) {
                                    "NEW" -> MaterialTheme.colorScheme.error
                                    "UNDER_REVIEW" -> Color(0xFFED6C02)
                                    "FIXING" -> Color(0xFF0288D1)
                                    else -> Color(0xFF2E7D32)
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = report.status,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(report.description, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("المرسل: ${report.userName} (${report.userEmail})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { onUpdateStatus(report.id, "UNDER_REVIEW") }) { Text("قيد المراجعة", fontSize = 11.sp) }
                            OutlinedButton(onClick = { onUpdateStatus(report.id, "FIXING") }) { Text("جاري الإصلاح", fontSize = 11.sp) }
                            Button(onClick = { onUpdateStatus(report.id, "RESOLVED") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))) { Text("تم الحل ✅", fontSize = 11.sp) }
                        }
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// TAB 8: COMMAND CENTER
// -----------------------------------------------------------------------------
@Composable
private fun CommandCenterTab() {
    val healthChecks = listOf(
        "🔐 نظام الحسابات والتسجيل" to "🟢 يعمل بكفاءة 100%",
        "🗄️ قاعدة البيانات المحلية Room DB" to "🟢 متصل ومحفوظ",
        "🔔 نظام الإشعارات والمنبهات" to "🟢 نشط",
        "📷 محرك الروشتات MR7 Vision" to "🟢 جاهز",
        "🎙️ المساعد الصوتي MR7 Voice" to "🟢 جاهز",
        "🌐 المزامنة وتأمين البيانات" to "🟢 آمن ومشفّر"
    )

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            // Admin Identity & Access Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("👑 هوية ومعرّف مدير النظام (Admin ID)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("معرّف الأدمن الفريد:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(2.dp)
                        ) {
                            Text(
                                text = SuperAdminConfig.ADMIN_ID,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Text("• البريد المعتمد: ${SuperAdminConfig.ADMIN_EMAIL_OWNER}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("• الصلاحية: Super Admin (التحكم الكامل بالإدارة)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(
                        "🔒 هذا المعرف يُعرض داخل إعدادات الإدارة فقط ومحمي بكلمات مرور مشفرة بـ Salted SHA-256 ولا يمكن تسجيل الدخول بمعرفة هذا المعرف فقط.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }
        item {
            Spacer(Modifier.height(4.dp))
            Text("⚡ صحة النظام والخدمات التشغيلية", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        items(healthChecks) { (service, status) ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(service, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    Text(status, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// MODALS & DIALOGS
// -----------------------------------------------------------------------------
@Composable
private fun UserDetailsModal(
    user: UserAccountEntity,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ℹ️ التفاصيل الإدارية للحساب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("• الاسم: ${user.name}", fontWeight = FontWeight.Bold)
                Text("• البريد: ${user.email}")
                Text("• Unique User ID: ${user.userId}")
                Text("• رتبة الحساب: ${user.role}")
                Text("• حالة الحظر: ${if (user.isBanned) "🚫 محظور (${user.banType})" else "🟢 نشط"}")
                user.banReason?.let { Text("• سبب الحظر: $it", color = MaterialTheme.colorScheme.error) }
                val regDate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(user.createdAtMillis))
                Text("• تاريخ التسجيل: $regDate")
                val lastActive = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(user.lastActiveMillis))
                Text("• آخر ظهور: $lastActive")
                Spacer(Modifier.height(8.dp))
                Text(
                    "🔒 الخصوصية الطبية: البيانات الدوائية والسجلات الطبية الخاصة بالمستخدم محمية بحسب الشروط والأنظمة.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
private fun BanUserModal(
    user: UserAccountEntity,
    onDismiss: () -> Unit,
    onConfirmBan: (String, String, Int?) -> Unit
) {
    var selectedType by remember { mutableStateOf("TEMPORARY") } // TEMPORARY, PERMANENT
    var banReason by remember { mutableStateOf("مخالفة الشروط والأحكام") }
    var selectedDays by remember { mutableStateOf(7) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🚫 حظر حساب المستخدم: ${user.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("اختر نوع الحظر:")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedType == "TEMPORARY",
                        onClick = { selectedType = "TEMPORARY" },
                        label = { Text("⏱️ حظر مؤقت") }
                    )
                    FilterChip(
                        selected = selectedType == "PERMANENT",
                        onClick = { selectedType = "PERMANENT" },
                        label = { Text("🔒 حظر دائم") }
                    )
                }

                if (selectedType == "TEMPORARY") {
                    Text("مدة الحظر (بالأيام):")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1, 3, 7, 30).forEach { days ->
                            FilterChip(
                                selected = selectedDays == days,
                                onClick = { selectedDays = days },
                                label = { Text("$days أيام") }
                            )
                        }
                    }
                }

                Text("سبب الحظر:")
                OutlinedTextField(
                    value = banReason,
                    onValueChange = { banReason = it },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmBan(selectedType, banReason, if (selectedType == "TEMPORARY") selectedDays else null)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("تأكيد الحظر")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
private fun CreateAnnouncementModal(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var icon by remember { mutableStateOf("📢") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("📢 نشر إعلان عام جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الإعلان") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("نص الإعلان") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )
                Text("الرمز:")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("📢", "⚠️", "🩺", "🎁", "🚀").forEach { emoji ->
                        FilterChip(
                            selected = icon == emoji,
                            onClick = { icon = emoji },
                            label = { Text(emoji) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && message.isNotBlank()) {
                        onConfirm(title, message, icon)
                    }
                }
            ) {
                Text("نشر الإعلان")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
private fun AddKnowledgeModal(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("مسكنات") }
    var desc by remember { mutableStateOf("") }
    var sideEffects by remember { mutableStateOf("") }
    var dosage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("💊 إضافة دواء لقاعدة المعرفة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الدواء العلمية/التجارية") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("التصنيف الطبي") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("الوصف دواعي الاستعمال") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = dosage, onValueChange = { dosage = it }, label = { Text("الجرعة الإرشادية") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = sideEffects, onValueChange = { sideEffects = it }, label = { Text("الآثار الجانبية والتنبيهات") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(name, category, desc, sideEffects, dosage)
                    }
                }
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
