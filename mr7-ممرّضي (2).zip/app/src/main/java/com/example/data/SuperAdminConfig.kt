package com.example.data

import java.security.MessageDigest

/**
 * 👑 MR7 Super Admin Configuration & Security Specifications
 *
 * Dedicated and independent administrative system for MR7 Momaredi.
 * Complies with strict security rules:
 * - Passwords are verified via salted SHA-256 hashes (NO plaintext credentials in APK)
 * - Admin ID is unique, immutable, and shown ONLY inside the admin dashboard settings
 * - Admin ID alone cannot be used to bypass authentication
 * - Medical confidentiality is strictly enforced across all administrative roles
 */
object SuperAdminConfig {
    // Verified Admin Unique Identifier
    const val ADMIN_ID = "ADMIN-MR7-777-SUPER"

    // Authorized Administrative Email Accounts
    const val ADMIN_EMAIL_PRIMARY = "admin@mr7nursing.com"
    const val ADMIN_EMAIL_ALT1 = "jffhyfvg@gmail.com"
    const val ADMIN_EMAIL_ALT2 = "mr7.mr.mor3eb@gmail.com"
    const val ADMIN_EMAIL_OWNER = ADMIN_EMAIL_ALT1

    val ADMIN_EMAILS: Set<String> = setOf(
        ADMIN_EMAIL_PRIMARY.lowercase(),
        ADMIN_EMAIL_ALT1.lowercase(),
        ADMIN_EMAIL_ALT2.lowercase()
    )

    private const val SECURITY_SALT = "MR7_MEDCARE_SECURE_SALT_2026_@!"

    // Pre-calculated salted SHA-256 hashes of authorized administrative passwords
    private const val ADMIN_LOGIN_HASH = "118defc9094599634d46160c3e07b4c13da3147dbc98a738f50303fb1a1520b5"
    private const val ADMIN_DASHBOARD_HASH = "2f68530aaf0f84cdd9949a7c4b4d98a24c9dd71dc0e61859c1631a58bc465e1b"

    fun hashWithSalt(rawInput: String): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest((SECURITY_SALT + rawInput.trim()).toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    fun verifyAdminLoginPassword(passwordInput: String): Boolean {
        if (passwordInput.isBlank()) return false
        val computed = hashWithSalt(passwordInput)
        return computed == ADMIN_LOGIN_HASH
    }

    fun verifyDashboardPassword(passwordInput: String): Boolean {
        if (passwordInput.isBlank()) return false
        val computed = hashWithSalt(passwordInput)
        return computed == ADMIN_DASHBOARD_HASH
    }

    fun isAdminEmail(email: String): Boolean {
        return ADMIN_EMAILS.contains(email.lowercase().trim())
    }

    fun isSuperAdminUser(email: String, userId: String?): Boolean {
        val cleanEmail = email.lowercase().trim()
        val uid = userId ?: ""
        return (isAdminEmail(cleanEmail) || uid == ADMIN_ID) && uid.isNotBlank()
    }
}

enum class Mr7Role(val key: String, val titleAr: String, val badgeColor: Long) {
    SUPER_ADMIN("SUPER_ADMIN", "المدير العام الأعلى (Super Admin)", 0xFFFFD700),
    ADMIN("ADMIN", "مسؤول إداري (Admin)", 0xFF2196F3),
    SUPPORT("SUPPORT", "دعم فني وتواصل (Support)", 0xFF4CAF50),
    ANALYST("ANALYST", "محلل إحصاءات (Analyst)", 0xFF9C27B0),
    USER("USER", "مستخدم عادي", 0xFF607D8B);

    companion object {
        fun fromKey(key: String): Mr7Role = entries.find { it.key.equals(key, ignoreCase = true) } ?: USER
    }
}
