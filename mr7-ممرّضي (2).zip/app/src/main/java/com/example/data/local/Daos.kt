package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserAccountDao {
    @Query("SELECT * FROM user_accounts WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserAccountEntity?

    @Query("SELECT * FROM user_accounts WHERE googleId = :googleId LIMIT 1")
    suspend fun getUserByGoogleId(googleId: String): UserAccountEntity?

    @Query("SELECT * FROM user_accounts WHERE facebookId = :facebookId LIMIT 1")
    suspend fun getUserByFacebookId(facebookId: String): UserAccountEntity?

    @Query("SELECT * FROM user_accounts WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserAccountEntity?

    @Query("SELECT * FROM user_accounts ORDER BY createdAtMillis DESC")
    fun getAllUsersFlow(): Flow<List<UserAccountEntity>>

    @Query("SELECT * FROM user_accounts ORDER BY createdAtMillis DESC")
    suspend fun getAllUsersList(): List<UserAccountEntity>

    @Query("SELECT * FROM user_accounts WHERE isBanned = 1 ORDER BY createdAtMillis DESC")
    fun getBannedUsersFlow(): Flow<List<UserAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserAccount(user: UserAccountEntity)

    @Query("UPDATE user_accounts SET isBanned = :isBanned, banType = :banType, banReason = :banReason, banEndMillis = :banEndMillis WHERE userId = :userId")
    suspend fun updateUserBanState(userId: String, isBanned: Boolean, banType: String?, banReason: String?, banEndMillis: Long?)

    @Query("DELETE FROM user_accounts WHERE userId = :userId")
    suspend fun deleteUserAccount(userId: String)

    @Query("SELECT COUNT(*) FROM user_accounts")
    fun getTotalUsersCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM user_accounts WHERE isBanned = 1")
    fun getBannedUsersCountFlow(): Flow<Int>
}

@Dao
interface AdminLogDao {
    @Query("SELECT * FROM admin_logs ORDER BY timestampMillis DESC LIMIT 200")
    fun getAllAdminLogs(): Flow<List<AdminLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdminLog(log: AdminLogEntity): Long
}

@Dao
interface SystemAnnouncementDao {
    @Query("SELECT * FROM system_announcements ORDER BY createdAtMillis DESC")
    fun getAllAnnouncements(): Flow<List<SystemAnnouncementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: SystemAnnouncementEntity): Long

    @Query("UPDATE system_announcements SET isActive = :isActive WHERE id = :id")
    suspend fun updateAnnouncementStatus(id: Long, isActive: Boolean)

    @Delete
    suspend fun deleteAnnouncement(announcement: SystemAnnouncementEntity)
}

@Dao
interface UserReportDao {
    @Query("SELECT * FROM user_reports ORDER BY createdAtMillis DESC")
    fun getAllReports(): Flow<List<UserReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: UserReportEntity): Long

    @Query("UPDATE user_reports SET status = :status WHERE id = :id")
    suspend fun updateReportStatus(id: Long, status: String)
}

@Dao
interface MedicationKnowledgeDao {
    @Query("SELECT * FROM medication_knowledge ORDER BY officialName ASC")
    fun getAllKnowledge(): Flow<List<MedicationKnowledgeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKnowledge(item: MedicationKnowledgeEntity): Long

    @Delete
    suspend fun deleteKnowledge(item: MedicationKnowledgeEntity)
}

@Dao
interface FeatureFlagDao {
    @Query("SELECT * FROM feature_flags")
    fun getAllFlags(): Flow<List<FeatureFlagEntity>>

    @Query("SELECT * FROM feature_flags WHERE `key` = :key LIMIT 1")
    suspend fun getFlag(key: String): FeatureFlagEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlag(flag: FeatureFlagEntity)
}

@Dao
interface MedicationDao {
    @Query("SELECT * FROM medications WHERE userId = :userId AND isArchived = 0 ORDER BY id DESC")
    fun getActiveMedications(userId: String): Flow<List<MedicationEntity>>

    @Query("SELECT * FROM medications WHERE userId = :userId AND isArchived = 1 ORDER BY id DESC")
    fun getArchivedMedications(userId: String): Flow<List<MedicationEntity>>

    @Query("SELECT * FROM medications WHERE userId = :userId ORDER BY id DESC")
    fun getAllMedications(userId: String): Flow<List<MedicationEntity>>

    @Query("SELECT * FROM medications WHERE id = :id AND userId = :userId")
    suspend fun getMedicationById(id: Long, userId: String): MedicationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedication(medication: MedicationEntity): Long

    @Update
    suspend fun updateMedication(medication: MedicationEntity)

    @Query("UPDATE medications SET stockCount = :newStock WHERE id = :id AND userId = :userId")
    suspend fun updateStock(id: Long, newStock: Int, userId: String)

    @Query("UPDATE medications SET isArchived = :archived WHERE id = :id AND userId = :userId")
    suspend fun setArchived(id: Long, archived: Boolean, userId: String)

    @Delete
    suspend fun deleteMedication(medication: MedicationEntity)

    @Query("DELETE FROM medications WHERE userId = :userId")
    suspend fun deleteAllMedicationsForUser(userId: String)
}

@Dao
interface DoseLogDao {
    @Query("SELECT * FROM dose_logs WHERE userId = :userId AND scheduledDate = :dateString ORDER BY timestampMillis ASC")
    fun getDoseLogsForDate(userId: String, dateString: String): Flow<List<DoseLogEntity>>

    @Query("SELECT * FROM dose_logs WHERE userId = :userId ORDER BY timestampMillis DESC LIMIT 50")
    fun getAllDoseLogs(userId: String): Flow<List<DoseLogEntity>>

    @Query("SELECT * FROM dose_logs WHERE userId = :userId AND status = 'PENDING' ORDER BY timestampMillis ASC")
    fun getPendingDoses(userId: String): Flow<List<DoseLogEntity>>

    @Query("SELECT * FROM dose_logs WHERE userId = :userId AND (status = 'PENDING' OR status = 'SNOOZED') ORDER BY timestampMillis ASC LIMIT 5")
    suspend fun getPendingDosesListForWidget(userId: String): List<DoseLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDoseLog(doseLog: DoseLogEntity): Long

    @Update
    suspend fun updateDoseLog(doseLog: DoseLogEntity)

    @Query("UPDATE dose_logs SET status = :status, confirmedTimeMillis = :confirmedTime WHERE id = :id AND userId = :userId")
    suspend fun updateDoseStatus(id: Long, status: String, confirmedTime: Long? = System.currentTimeMillis(), userId: String)

    @Query("DELETE FROM dose_logs WHERE medicationId = :medId AND userId = :userId")
    suspend fun deleteLogsForMedication(medId: Long, userId: String)

    @Query("DELETE FROM dose_logs WHERE userId = :userId")
    suspend fun deleteAllLogsForUser(userId: String)
}

@Dao
interface DoctorDao {
    @Query("SELECT * FROM doctors WHERE userId = :userId ORDER BY name ASC")
    fun getAllDoctors(userId: String): Flow<List<DoctorEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDoctor(doctor: DoctorEntity): Long

    @Delete
    suspend fun deleteDoctor(doctor: DoctorEntity)

    @Query("DELETE FROM doctors WHERE userId = :userId")
    suspend fun deleteAllDoctorsForUser(userId: String)
}

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments WHERE userId = :userId AND isCompleted = 0 ORDER BY appointmentTimeMillis ASC")
    fun getUpcomingAppointments(userId: String): Flow<List<AppointmentEntity>>

    @Query("SELECT * FROM appointments WHERE userId = :userId AND isCompleted = 0 ORDER BY appointmentTimeMillis ASC LIMIT 5")
    suspend fun getUpcomingAppointmentsListForWidget(userId: String): List<AppointmentEntity>

    @Query("SELECT * FROM appointments WHERE userId = :userId ORDER BY appointmentTimeMillis DESC")
    fun getAllAppointments(userId: String): Flow<List<AppointmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppointment(appointment: AppointmentEntity): Long

    @Query("UPDATE appointments SET isCompleted = :completed WHERE id = :id AND userId = :userId")
    suspend fun setCompleted(id: Long, completed: Boolean, userId: String)

    @Delete
    suspend fun deleteAppointment(appointment: AppointmentEntity)

    @Query("DELETE FROM appointments WHERE userId = :userId")
    suspend fun deleteAllAppointmentsForUser(userId: String)
}

@Dao
interface AllergyDao {
    @Query("SELECT * FROM allergies WHERE userId = :userId ORDER BY id DESC")
    fun getAllAllergies(userId: String): Flow<List<AllergyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllergy(allergy: AllergyEntity): Long

    @Delete
    suspend fun deleteAllergy(allergy: AllergyEntity)

    @Query("DELETE FROM allergies WHERE userId = :userId")
    suspend fun deleteAllAllergiesForUser(userId: String)
}

@Dao
interface FamilyDao {
    @Query("SELECT * FROM family_members WHERE userId = :userId ORDER BY id DESC")
    fun getAllFamilyMembers(userId: String): Flow<List<FamilyMemberEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFamilyMember(member: FamilyMemberEntity): Long

    @Update
    suspend fun updateFamilyMember(member: FamilyMemberEntity)

    @Delete
    suspend fun deleteFamilyMember(member: FamilyMemberEntity)

    @Query("DELETE FROM family_members WHERE userId = :userId")
    suspend fun deleteAllFamilyMembersForUser(userId: String)
}
